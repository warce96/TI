"""
server.py — ETL Governance Portal (Unificado)
Banco Continental — Gobierno de Datos

Integra:
  - Pentaho Explorer (KTR / KJB / PY)
  - Power BI Validator (.pbix) con historial SQLite
  - Historial de validaciones consultable por fecha / nombre

python server.py → http://localhost:5000
"""

import io, json, os, re, ast as pyast, shutil, sqlite3, tempfile
import traceback, xml.etree.ElementTree as ET, time, zipfile
import subprocess, threading, uuid, textwrap, hashlib, posixpath, tarfile
from datetime import datetime, timedelta
from functools import wraps
from collections import defaultdict
from pathlib import Path
from flask import (Flask, render_template, request, jsonify, abort, send_file,
                    session, redirect, url_for)
from werkzeug.security import generate_password_hash, check_password_hash
import paramiko
import requests
from dotenv import load_dotenv
load_dotenv()  # lee el archivo .env que está junto a server.py, si existe

app  = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024
app.secret_key = os.environ.get("PORTAL_SECRET_KEY", "banco-continental-gobierno-datos-CAMBIAR-EN-PRODUCCION")
BASE = Path(__file__).parent

# ════════════════════════════════════════════════════════
#  AUTENTICACIÓN — login con base de datos (SQLite)
# ════════════════════════════════════════════════════════

def init_auth_db():
    """Crea la tabla de usuarios y siembra un usuario admin si no existe ninguno."""
    with _db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario       TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                nombre        TEXT,
                rol           TEXT DEFAULT 'usuario',
                activo        INTEGER DEFAULT 1,
                creado        TEXT,
                ultimo_login  TEXT
            )
        """)
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(usuarios)").fetchall()}
        if "activo" not in cols:
            conn.execute("ALTER TABLE usuarios ADD COLUMN activo INTEGER DEFAULT 1")
        if "debe_cambiar_password" not in cols:
            conn.execute("ALTER TABLE usuarios ADD COLUMN debe_cambiar_password INTEGER DEFAULT 0")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS usuario_permisos (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
                pagina      TEXT NOT NULL,
                permitido   INTEGER DEFAULT 0,
                UNIQUE(usuario_id, pagina)
            )
        """)

        total = conn.execute("SELECT COUNT(*) c FROM usuarios").fetchone()["c"]
        if total == 0:
            conn.execute("""
                INSERT INTO usuarios (usuario, password_hash, nombre, rol, activo, creado)
                VALUES (?,?,?,?,1,?)
            """, ("admin", generate_password_hash("CambiarPassword123"),
                  "Administrador", "admin",
                  datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()


# Pantallas disponibles para asignar permisos granulares.
# clave -> (etiqueta visible, prefijos de ruta que cubre)
PAGINAS = {
    "pentaho":   ("Pentaho ETL",        ["/", "/api/tree", "/search", "/open", "/catalog",
                                          "/api/descargar_remoto", "/api/descargar_local"]),
    "powerbi":   ("Power BI",           ["/powerbi", "/api/powerbi"]),
    "etl":       ("Tareas",             ["/etl", "/api/etl"]),
    "crontab":   ("Programación",       ["/crontab", "/api/crontab"]),
    "reporte":   ("Reporte de estados", ["/reporte", "/api/reporte"]),
    "compare":   ("Comparar",           ["/compare"]),
    "python":    ("Python & ML",        ["/python", "/api/python"]),
    "azure":     ("Azure HUs",          ["/azure", "/api/azure"]),
    "deploy":    ("Deploy",             ["/deploy", "/api/deploy"]),
    "auditoria": ("Auditoría",          ["/auditoria", "/api/auditoria"]),
    "usuarios":  ("Usuarios",           ["/usuarios", "/api/usuarios"]),
}

def _resolver_pagina(path):
    """Devuelve la clave de PAGINAS a la que pertenece un path, o None si no está mapeado."""
    mejor, mejor_len = None, -1
    for clave, (_etq, prefijos) in PAGINAS.items():
        for pre in prefijos:
            if path == pre or path.startswith(pre.rstrip("/") + "/") or (pre == "/" and path == "/"):
                if len(pre) > mejor_len:
                    mejor, mejor_len = clave, len(pre)
    return mejor

def _tiene_permiso(usuario_id, pagina):
    with _db() as conn:
        row = conn.execute("""
            SELECT permitido FROM usuario_permisos WHERE usuario_id=? AND pagina=?
        """, (usuario_id, pagina)).fetchone()
    return bool(row and row["permitido"])

def _paginas_permitidas(usuario_id, rol):
    """Set de claves de páginas visibles para un usuario, para armar el menú."""
    if rol == "admin":
        return set(PAGINAS.keys())
    with _db() as conn:
        rows = conn.execute("""
            SELECT pagina FROM usuario_permisos WHERE usuario_id=? AND permitido=1
        """, (usuario_id,)).fetchall()
    return {r["pagina"] for r in rows}

def login_required(f):
    """Decorador: exige sesión iniciada. Redirige a /login si no hay usuario."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("usuario"):
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    """Decorador: exige rol admin. Devuelve 403 si no lo es."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("usuario"):
            return redirect(url_for("login", next=request.path))
        if session.get("rol") != "admin":
            abort(403)
        return f(*args, **kwargs)
    return wrapper

_RUTAS_SIN_CHEQUEO = ("/login", "/logout", "/static", "/usuarios", "/api/usuarios")

@app.before_request
def _chequear_sesion_y_permisos():
    if any(request.path == r or request.path.startswith(r + "/") for r in _RUTAS_SIN_CHEQUEO):
        return None
    if not session.get("usuario"):
        return None  # login_required de cada ruta se encarga de redirigir

    # Si el usuario fue desactivado mientras tenía la sesión abierta, se lo saca.
    with _db() as conn:
        row = conn.execute("SELECT activo FROM usuarios WHERE id=?",
                            (session.get("usuario_id"),)).fetchone()
    if row is not None and not row["activo"]:
        session.clear()
        return redirect(url_for("login"))

    # Contraseña temporal sin cambiar: no se deja avanzar a ninguna otra pantalla
    # hasta que la cambie desde /usuarios (que ya está exceptuada arriba).
    if session.get("debe_cambiar_password"):
        return redirect(url_for("usuarios_home"))

    if session.get("rol") == "admin":
        return None  # el admin ve todo, sin restricciones de pantalla

    pagina = _resolver_pagina(request.path)
    if pagina is None:
        return None  # ruta no mapeada a ninguna pantalla (ej. asset genérico): se permite
    if not _tiene_permiso(session.get("usuario_id"), pagina):
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "error": "No tenés permiso para acceder a esta sección."}), 403
        return render_template("sin_permiso.html", pagina=PAGINAS.get(pagina, (pagina,))[0]), 403

@app.context_processor
def inject_usuario_actual():
    paginas = set()
    if session.get("usuario"):
        paginas = _paginas_permitidas(session.get("usuario_id"), session.get("rol"))
    return dict(usuario_actual=session.get("usuario"),
                nombre_actual=session.get("nombre"),
                rol_actual=session.get("rol"),
                paginas_permitidas=paginas)

@app.template_filter("fromjson")
def fromjson_filter(s):
    try: return json.loads(s) if s else []
    except: return []

@app.context_processor
def inject_visual_maps():
    return dict(visual_types=VISUAL_TYPES, visual_colors=VISUAL_COLORS)

# ── Config SSH / Pentaho ─────────────────────────────
_H        = "10.1.1.3"
_U        = "sysadmin"
_P        = "a.123456"
_LOG      = "/var/pentaho/logs/REGISTRO_CARGA.log"
_CRONTAB  = "/etc/crontab"
_PROOT    = "/pentaho/project"
LOG_TAIL_LINES = 60000   # límite de líneas al leer el log ETL, para que el portal cargue rápido

LOCAL_PATH        = r"C:\Users\willian.arce\Desktop\pentaho viejo\exe\proceso restante"
ALLOWED_EXT       = (".ktr", ".kjb", ".xml", ".py")
IGNORE_DIRS       = {"logs","backup",".git","__pycache__",".venv","venv"}
MAX_RESULTS       = 200
PREVIEW_MAX_CHARS = 250_000

# ── Config Versionado / Implementar / Bajar (Pentaho PROD) ──────────
# Mismo servidor que ya usás para Hadoop (10.1.1.3). Estas son las carpetas
# RAÍZ dentro de las cuales vas a poder elegir visualmente, desde el portal,
# la subcarpeta exacta donde implementar (no hace falta escribir el path completo acá).
PROD_KTR_PATH = os.environ.get("PENTAHO_PROD_KTR_PATH", "/pentaho/project/")
PROD_JOB_PATH = os.environ.get("PENTAHO_PROD_JOB_PATH", "/pentaho/project/")
PROD_PY_PATH  = os.environ.get("PENTAHO_PROD_PY_PATH",  os.environ.get("PENTAHO_PROD_KTR_PATH", "/pentaho/project/"))

PROD_ROOTS = {"KTR": PROD_KTR_PATH, "JOB": PROD_JOB_PATH, "PY": PROD_PY_PATH}

# Carpeta remota donde se guarda una copia del archivo ORIGINAL que había en
# PROD antes de que "Implementar" lo reemplace, espejando la misma estructura
# de carpetas y con el nombre + tag de la versión que lo reemplazó.
# Ej: /pentaho/project/OGD/Oracle/PROCESOS_1/JOB_PROCESOS_1.kjb ya existente
# se respalda como:
# /pentaho/project/Versionado/OGD/Oracle/PROCESOS_1/JOB_PROCESOS_1_v2.kjb
VERSIONADO_ROOT = os.environ.get("PENTAHO_VERSIONADO_PATH", "/pentaho/project/Versionado")

# Carpeta local donde se guarda cada versión subida desde el portal
# (una copia por versión, para poder diffear contra PROD antes de implementar)
DEPLOY_DIR = BASE / "deploy_versiones"
DEPLOY_DIR.mkdir(exist_ok=True)

# Carpeta local donde caen los archivos "bajados" (descargados) desde PROD
DESCARGAS_DIR = BASE / "descargas_prod"
DESCARGAS_DIR.mkdir(exist_ok=True)

# Carpeta SEPARADA para la documentación (.md) de cada versión — no vive
# junto al .zip/archivo que se implementa, pero se organiza espejando la
# misma estructura tipo/nombre_proceso/version, para encontrarla fácil.
DOCUMENTACION_DIR = BASE / "documentacion_md"
DOCUMENTACION_DIR.mkdir(exist_ok=True)

# Checklist de criterios de aceptación por tipo — deben marcarse 100% antes
# de habilitar "Implementar". Coincide con los criterios de aceptación de la HU.
CHECKLIST_ITEMS = {
    "JOB": [
        ("configurado_probado",   "El job fue configurado y probado en el ambiente correspondiente."),
        ("dia_hora_dependencias", "Se verificó día, hora y dependencias con otros procesos antes de la puesta en marcha."),
        ("alertas_configuradas",  "Se configuraron alertas ante fallo de ejecución."),
        ("catalogo_registrado",   "El job quedó registrado en el catálogo o listado de jobs vigentes."),
        ("md_creado",             "Se creó un .md del job, explicando la necesidad que cubre y el responsable a cargo."),
        ("zip_adjuntado",         "Se adjuntó el entregable en .zip, con carpeta nombrada según el estándar, con script, dependencias y documentación."),
    ],
    "KTR": [
        ("versionado_repo",       "El archivo KTR está versionado en el repositorio correspondiente."),
        ("no_duplicado",          "Se verificó que no existiera ya un KTR equivalente con otro responsable asignado."),
        ("carga_completa_incremental", "Se probó con carga completa y con carga incremental."),
        ("logs_sin_errores",      "Se revisaron los logs de ejecución sin errores pendientes."),
        ("mapeo_columnas",        "El mapeo de columnas entre origen y destino está documentado."),
        ("md_creado",             "Se creó un .md del KTR, explicando la necesidad que cubre y el responsable a cargo."),
        ("zip_adjuntado",         "Se adjuntó el entregable en .zip, con carpeta nombrada según el estándar, con script, dependencias y documentación."),
    ],
    # Alineado con "Pase a Producción — Ciencia de Datos" (estructura mínima +
    # buenas prácticas obligatorias + testeo previo con gate de puntaje).
    "PY": [
        ("estructura_minima",       "El entregable tiene la estructura mínima: script.py, requirements.txt, .md, modelo serializado (si aplica) y tests/."),
        ("sin_credenciales",        "Sin credenciales hardcodeadas: usuario/contraseña/tokens van por variable de entorno."),
        ("manejo_excepciones",      "Manejo de excepciones específico (sin except genérico sin registrar el motivo)."),
        ("logging_no_print",       "Usa logging en vez de print() suelto, para trazabilidad en producción."),
        ("variables_entorno",      "Configuración (rutas, hosts, tablas) por variable de entorno, no hardcodeada."),
        ("testeo_previo",          "Se probó en desarrollo/staging con datos reales, con reproducibilidad verificada."),
        ("puntaje_minimo",         "Alcanzó el puntaje mínimo de 70/100 en el análisis automático del portal (Python & ML)."),
        ("cero_errores",           "Cero errores no controlados en la corrida de prueba."),
        ("md_creado",              "Se creó un .md explicando la necesidad que cubre y el responsable a cargo."),
        ("zip_adjuntado",          "Se adjuntó el entregable en .zip, con carpeta nombrada según el estándar, con script, dependencias y documentación."),
    ],
}

# ── Config Azure DevOps (gate de aprobación Scrum Master / Product Owner) ──
# El PAT se pasa por variable de entorno, NUNCA hardcodeado en el archivo.
#   export AZURE_DEVOPS_ORG="tuorganizacion"
#   export AZURE_DEVOPS_PROJECT="tuproyecto"
#   export AZURE_DEVOPS_PAT="xxxxxxxxxxxxxxxxxxxxx"
AZURE_ORG     = os.environ.get("AZURE_DEVOPS_ORG", "")
AZURE_PROJECT = os.environ.get("AZURE_DEVOPS_PROJECT", "")
AZURE_PAT     = os.environ.get("AZURE_DEVOPS_PAT", "")

# Reference names de los campos personalizados. Los nombres visibles son:
#   "Comentario de Aprobación del Scrum Master"  (grupo/área: Datos)
#   "Autorización del Product Owner"             (grupo/área: Datos)
# El referenceName real (algo tipo "Custom.XXXX") depende de cómo se creó el
# campo en tu proceso de Azure DevOps. Se puede fijar acá una vez identificado
# con /api/azure/discover_fields, o dejarlo en variable de entorno.
AZURE_FIELD_SCRUM = os.environ.get("AZURE_FIELD_SCRUM", "")  # ej: "Custom.ComentarioDeAprobacionDelScrumMasterDatos"
AZURE_FIELD_PO    = os.environ.get("AZURE_FIELD_PO", "")     # ej: "Custom.AutorizacionDelProductOwnerDatos"

# Campos ya identificados en el proceso de Azure DevOps de Gobierno de Datos
# (confirmados directamente desde el volcado de campos de una HU real).
AZURE_FIELD_LIDER_PROYECTO = "Custom.887c504b-751f-4b5d-81cc-42d2d67d446e"
AZURE_FIELD_DESARROLLADOR_HU = "Custom.DesarrolladorHU"          # cuando WorkItemType == "User Story Desarrollo"
AZURE_FIELD_DESARROLLADOR_BUG = "Custom.DesarrolladorAsignado"   # cuando WorkItemType == "Bug"
AZURE_FIELD_ANALISTA_DATOS = "Custom.AnalistaAsignadoDatos"      # cuando WorkItemType == "User Story Datos"
AZURE_FIELD_DESARROLLADOR_OTRO = "Custom.8378a712-6ec9-4f34-aed6-c05b8b09079d"  # Tareas y otros tipos

# ── Reglas Power BI ──────────────────────────────────
REGLAS_DEFAULT = {
    "fuentes_prohibidas":  ["LocalFile","Excel","CSV","Folder","Text/Csv","Csv","Json","Xml","Pdf"],
    "fuentes_permitidas":  ["Oracle","SQL Server","OData","SharePoint","Web","ODBC","AnalysisServices"],
    "tablas_criticas_rls": ["CLIENTES","CREDITOS","OPERACIONES","SCORING","ALERTAS_PLD","TRANSACCIONES"],
    "columnas_sensibles":  ["CEDULA","CI","RUC","TELEFONO","EMAIL","CORREO","SALARIO","SUELDO","INGRESO","PASSWORD"],
    "limite_tablas": 40, "limite_columnas": 400,
    "limite_medidas": 150, "limite_paginas": 20, "max_mb": 200,
}
REGLAS = dict(REGLAS_DEFAULT)
_rp = BASE / "reglas_banco.json"
if _rp.exists():
    try: REGLAS.update(json.loads(_rp.read_text("utf-8")))
    except: pass

VISUAL_TYPES = {
    "barChart":"Barras","clusteredBarChart":"Barras agrupadas",
    "columnChart":"Columnas","clusteredColumnChart":"Columnas agrupadas",
    "stackedBarChart":"Barras apiladas","stackedColumnChart":"Columnas apiladas",
    "hundredPercentStackedBarChart":"Barras 100%","hundredPercentStackedColumnChart":"Columnas 100%",
    "lineChart":"Líneas","areaChart":"Área","stackedAreaChart":"Área apilada",
    "lineClusteredColumnComboChart":"Líneas+Col","ribbonChart":"Ribbon",
    "waterfallChart":"Cascada","scatterChart":"Dispersión",
    "pieChart":"Torta","donutChart":"Dona","treemap":"Mapa árbol",
    "card":"Tarjeta","multiRowCard":"Tarjetas múltiples",
    "tableEx":"Tabla","pivotTable":"Tabla dinámica","matrix":"Matriz",
    "map":"Mapa","filledMap":"Mapa relleno","azureMap":"Azure Map",
    "slicer":"Segmentación","textbox":"Texto","image":"Imagen",
    "shape":"Forma","basicShape":"Forma","actionButton":"Botón",
    "kpi":"KPI","gauge":"Medidor","decompositionTree":"Árbol",
    "group":"Grupo","smartNarrativeVisual":"Narración IA",
}
VISUAL_COLORS = {
    "barChart":"#2563EB","clusteredBarChart":"#2563EB","columnChart":"#2563EB","clusteredColumnChart":"#2563EB",
    "stackedBarChart":"#3B82F6","stackedColumnChart":"#3B82F6",
    "lineChart":"#059669","areaChart":"#059669","stackedAreaChart":"#10B981",
    "lineClusteredColumnComboChart":"#7C3AED","ribbonChart":"#6D28D9",
    "scatterChart":"#EA580C","waterfallChart":"#B45309",
    "pieChart":"#DC2626","donutChart":"#B91C1C","treemap":"#0F766E",
    "card":"#1D4ED8","multiRowCard":"#1D4ED8",
    "tableEx":"#475569","pivotTable":"#475569","matrix":"#334155",
    "map":"#0369A1","filledMap":"#0369A1","azureMap":"#0078D4",
    "slicer":"#7C3AED","textbox":"#94A3B8","image":"#D97706",
    "shape":"#CBD5E1","basicShape":"#CBD5E1","actionButton":"#1E293B",
    "kpi":"#DC2626","gauge":"#D97706","decompositionTree":"#0891B2",
    "group":"#6B7280","smartNarrativeVisual":"#7C3AED",
}
THEME_STD = ["#118DFF","#12239E","#E66C37","#6B007B","#E044A7",
             "#744EC2","#D9B300","#D64550","#197278","#1AAB40"]


# ════════════════════════════════════════════════════════
#  SQLITE — Historial de validaciones
# ════════════════════════════════════════════════════════

DB_PATH = BASE / "historial_pbix.db"

def _db():
    """Conexión SQLite con row_factory para dicts."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Crea las tablas si no existen."""
    with _db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS validaciones (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            archivo     TEXT    NOT NULL,
            fecha       TEXT    NOT NULL,
            timestamp   TEXT    NOT NULL,
            aprobado    INTEGER NOT NULL,
            errores     INTEGER NOT NULL,
            avisos      INTEGER NOT NULL,
            pasaron     INTEGER NOT NULL,
            total       INTEGER NOT NULL,
            mb          REAL,
            n_paginas   INTEGER,
            n_medidas   INTEGER,
            n_tablas    INTEGER,
            n_columnas  INTEGER,
            tema_nombre TEXT,
            tema_colores TEXT,
            tiene_rls   INTEGER,
            detalle_json TEXT
        );

        CREATE TABLE IF NOT EXISTS validacion_reglas (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            validacion_id   INTEGER NOT NULL REFERENCES validaciones(id) ON DELETE CASCADE,
            categoria       TEXT,
            regla           TEXT,
            estado          TEXT,
            mensaje         TEXT,
            detalle         TEXT,
            severidad       TEXT
        );

        CREATE TABLE IF NOT EXISTS validacion_paginas (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            validacion_id   INTEGER NOT NULL REFERENCES validaciones(id) ON DELETE CASCADE,
            nombre          TEXT,
            oculta          INTEGER,
            n_visuales      INTEGER,
            canvas_w        INTEGER,
            canvas_h        INTEGER,
            tipos_visuales  TEXT
        );

        CREATE TABLE IF NOT EXISTS validacion_medidas (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            validacion_id   INTEGER NOT NULL REFERENCES validaciones(id) ON DELETE CASCADE,
            tabla           TEXT,
            nombre          TEXT,
            expresion       TEXT,
            tiene_var       INTEGER,
            tiene_divide    INTEGER,
            expr_larga      INTEGER
        );

        CREATE TABLE IF NOT EXISTS deploy_versiones (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo            TEXT NOT NULL,               -- 'KTR', 'JOB' o 'PY'
            nombre_proceso  TEXT NOT NULL,
            id_hu           TEXT,
            version         INTEGER NOT NULL,
            version_tag     TEXT,                        -- etiqueta visible: 'v3' por defecto, o la que edite el usuario
            archivo_nombre  TEXT NOT NULL,
            ruta_local      TEXT NOT NULL,
            destino_dir     TEXT,                         -- carpeta PROD elegida visualmente (absoluta)
            hash_sha256     TEXT,
            responsable     TEXT,
            fecha           TEXT NOT NULL,
            timestamp       TEXT NOT NULL,
            estado          TEXT DEFAULT 'borrador',     -- borrador | listo_prod | en_prod
            ruta_prod       TEXT,
            ruta_respaldo_original TEXT,                 -- dónde quedó el archivo que había ANTES en PROD, si había
            ruta_documentacion TEXT,                     -- ruta local del .md, aparte del entregable
            lider_proyecto  TEXT,                        -- guardado al momento de crear la version, desde Azure DevOps
            analista_asignado TEXT,
            fecha_implementacion TEXT
        );

        CREATE TABLE IF NOT EXISTS deploy_checklist (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            version_id      INTEGER NOT NULL REFERENCES deploy_versiones(id) ON DELETE CASCADE,
            criterio        TEXT NOT NULL,
            cumplido        INTEGER DEFAULT 0,
            marcado_por     TEXT,
            fecha           TEXT
        );

        CREATE TABLE IF NOT EXISTS deploy_historial_acciones (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            version_id      INTEGER NOT NULL REFERENCES deploy_versiones(id) ON DELETE CASCADE,
            accion          TEXT NOT NULL,   -- implementar | bajar
            usuario         TEXT,
            fecha           TEXT NOT NULL,
            resultado       TEXT,            -- ok | error
            detalle         TEXT,
            nota_manual     TEXT             -- comentario editable a mano, aparte del detalle automático
        );

        CREATE TABLE IF NOT EXISTS analizador_reglas (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo              TEXT UNIQUE NOT NULL,   -- ej. 'BP-12', 'EP-09', o 'CUSTOM-01' para reglas propias
            tipo                TEXT NOT NULL,          -- 'builtin' | 'custom' | 'estructura'
            nombre              TEXT,
            activa              INTEGER DEFAULT 1,
            severidad_override  TEXT,                   -- NULL = sin cambios; 'OK'|'AVISO'|'ERROR' para builtin
            patron_regex        TEXT,                   -- solo 'custom': regex a buscar en el código
            mensaje             TEXT,                   -- mensaje a mostrar cuando matchea (custom) o nota admin
            severidad_custom    TEXT DEFAULT 'AVISO',    -- severidad cuando matchea una regla custom
            valor_config        TEXT,                   -- JSON libre (ej. lista de carpetas esperadas en 'estructura')
            creado_por          TEXT,
            fecha               TEXT
        );
        """)

def _seed_reglas_estructura_default():
    """Siembra la regla EP-09 (estructura MLOps) con la estructura del README, si no existe todavia."""
    with _db() as conn:
        existe = conn.execute("SELECT 1 FROM analizador_reglas WHERE codigo='EP-09'").fetchone()
        if not existe:
            estructura_default = {
                "carpetas": ["config", "src", "scripts", "data", "models"],
                "archivos": ["requirements.txt", "README.md"]
            }
            conn.execute("""
                INSERT INTO analizador_reglas
                (codigo, tipo, nombre, activa, mensaje, valor_config, creado_por, fecha)
                VALUES ('EP-09', 'estructura', 'Estructura de proyecto MLOps', 1,
                        'Estructura esperada según la convención MLOps del equipo (editable).',
                        ?, 'sistema', ?)
            """, (json.dumps(estructura_default, ensure_ascii=False),
                  datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            conn.commit()

def _migrar_columnas_deploy():
    """Agrega columnas nuevas a deploy_versiones si el .db ya existía sin ellas."""
    with _db() as conn:
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(deploy_versiones)").fetchall()}
        if "destino_dir" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN destino_dir TEXT")
        if "version_tag" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN version_tag TEXT")
        if "ruta_respaldo_original" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN ruta_respaldo_original TEXT")
        if "ruta_documentacion" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN ruta_documentacion TEXT")
        if "lider_proyecto" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN lider_proyecto TEXT")
        if "analista_asignado" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN analista_asignado TEXT")

        cols_acciones = {r["name"] for r in conn.execute("PRAGMA table_info(deploy_historial_acciones)").fetchall()}
        if "nota_manual" not in cols_acciones:
            conn.execute("ALTER TABLE deploy_historial_acciones ADD COLUMN nota_manual TEXT")
        conn.commit()

init_db()
_migrar_columnas_deploy()
_seed_reglas_estructura_default()
init_auth_db()


def guardar_validacion(data: dict) -> int:
    """
    Persiste el resultado completo de una validación en SQLite.
    Retorna el id insertado.
    """
    ts   = data.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    fecha = ts[:10]

    # Métricas resumidas desde detalle_json
    colors = data.get("colors", {})
    pages  = data.get("pages",  [])

    # Detectar métricas desde categorías de resultados
    n_paginas  = len(pages)
    n_medidas  = 0
    n_tablas   = 0
    n_columnas = 0
    mb_val     = 0.0
    tiene_rls  = 0

    for r in data.get("resultados", []):
        msg = r.get("msg", "")
        if "Medidas:" in msg:
            try: n_medidas  = int(re.search(r"Medidas:\s*(\d+)", msg).group(1))
            except: pass
        if "Tablas:" in msg:
            try: n_tablas   = int(re.search(r"Tablas:\s*(\d+)",   msg).group(1))
            except: pass
        if "Columnas:" in msg:
            try: n_columnas = int(re.search(r"Columnas:\s*(\d+)", msg).group(1))
            except: pass
        if "Tamaño:" in msg:
            try: mb_val     = float(re.search(r"Tamaño:\s*([\d.]+)", msg).group(1))
            except: pass
        if "RLS configurado" in msg:
            tiene_rls = 1

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO validaciones
            (archivo, fecha, timestamp, aprobado, errores, avisos, pasaron, total,
             mb, n_paginas, n_medidas, n_tablas, n_columnas,
             tema_nombre, tema_colores, tiene_rls, detalle_json)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            data.get("archivo",""),
            fecha, ts,
            int(data.get("aprobado", False)),
            data.get("errores", 0),
            data.get("avisos",  0),
            data.get("pasaron", 0),
            data.get("total",   0),
            mb_val, n_paginas, n_medidas, n_tablas, n_columnas,
            colors.get("nombre",""),
            json.dumps(colors.get("colores", [])),
            tiene_rls,
            json.dumps(data, ensure_ascii=False),
        ))
        vid = cur.lastrowid

        # Guardar reglas detalle
        for r in data.get("resultados", []):
            conn.execute("""
                INSERT INTO validacion_reglas
                (validacion_id, categoria, regla, estado, mensaje, detalle, severidad)
                VALUES (?,?,?,?,?,?,?)
            """, (vid, r.get("cat",""), r.get("regla",""), r.get("estado",""),
                  r.get("msg",""), r.get("det",""), r.get("sev","")))

        # Guardar páginas
        for p in pages:
            tipos = json.dumps([v["type"] for v in p.get("visuals",[])])
            conn.execute("""
                INSERT INTO validacion_paginas
                (validacion_id, nombre, oculta, n_visuales, canvas_w, canvas_h, tipos_visuales)
                VALUES (?,?,?,?,?,?,?)
            """, (vid, p.get("name",""), int(p.get("hidden",False)),
                  p.get("n",0), p.get("cw",1280), p.get("ch",720), tipos))

        conn.commit()
    return vid


# ════════════════════════════════════════════════════════
#  SSH — Pentaho helpers
# ════════════════════════════════════════════════════════

def _ssh():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(_H, username=_U, password=_P, timeout=10)
    return c

def _run(cmd):
    try:
        ssh    = _ssh()
        escaped = cmd.replace('"', '\\"')
        full    = f'sudo -S -p "" bash -c "{escaped}"'
        stdin, stdout, stderr = ssh.exec_command(full, timeout=30)
        stdin.write(_P + "\n"); stdin.flush()
        out = stdout.read().decode("utf-8", errors="replace")
        ssh.close()
        lines = [l for l in out.splitlines()
                 if not l.startswith("[sudo]") and "password for" not in l.lower()]
        return "\n".join(lines), True
    except Exception as e:
        app.logger.error("SSH error: %s", e)
        return "", False

def _read_file(path, tail=None):
    cmd = f"tail -n {tail} {path}" if tail else f"cat {path}"
    return _run(cmd)

def _read_content(path):
    out, ok = _run(f"cat {path}")
    return out[:PREVIEW_MAX_CHARS] if (ok and out) else ""

def _sftp_put(local_path, remote_path):
    """
    Sube un archivo local al servidor Pentaho (para 'Implementar').
    El usuario SFTP (sysadmin) puede no tener permiso de escritura directo en
    la carpeta final de PROD (por eso el resto del portal usa sudo vía _run()).
    Como SFTP no pasa por sudo, subimos primero a un staging en /tmp (donde sí
    se puede escribir sin privilegios) y de ahí lo movemos con sudo.
    """
    staging = f"/tmp/deploy_stage_{uuid.uuid4().hex}"
    ssh = _ssh()
    try:
        sftp = ssh.open_sftp()
        sftp.put(str(local_path), staging)
        sftp.close()
    except Exception as e:
        app.logger.error("SFTP put (staging) error: %s", e)
        return False, f"No se pudo subir a la carpeta temporal: {e}"
    finally:
        ssh.close()

    remote_dir = posixpath.dirname(remote_path)
    cmd = f'mkdir -p "{remote_dir}" && mv "{staging}" "{remote_path}" && chmod 664 "{remote_path}"'
    out, ok = _run(cmd)
    if not ok:
        return False, f"Fallo moviendo el archivo a destino final (sudo mv): {out or 'sin detalle'}"
    return True, ""

def _sftp_get(remote_path, local_path):
    """
    Descarga un archivo del servidor Pentaho hacia una ruta local (para 'Bajar').
    Igual que en _sftp_put: el archivo real puede no ser legible directamente
    por el usuario SFTP, así que primero lo copiamos con sudo a un staging en
    /tmp con permisos abiertos, y de ahí sí lo bajamos por SFTP normal.
    """
    staging = f"/tmp/deploy_stage_{uuid.uuid4().hex}"
    out, ok = _run(f'cp "{remote_path}" "{staging}" && chmod 644 "{staging}"')
    if not ok:
        return False, f"Fallo preparando el archivo para descarga (sudo cp): {out or 'sin detalle'}"

    ssh = _ssh()
    try:
        sftp = ssh.open_sftp()
        sftp.get(staging, str(local_path))
        sftp.close()
        return True, ""
    except Exception as e:
        app.logger.error("SFTP get error: %s", e)
        return False, str(e)
    finally:
        ssh.close()
        _run(f'rm -f "{staging}"')

def _respaldar_original_si_existe(remote_path, tipo, version_tag):
    """
    Antes de reemplazar un archivo en PROD, si ya había uno con ese mismo
    nombre (subido por este portal o no), lo copia a la carpeta 'Versionado',
    espejando la misma estructura de carpetas relativa a la raíz del tipo,
    y renombrado con el tag de la versión que lo está reemplazando.
    Ej: .../OGD/Oracle/PROCESOS_1/JOB_PROCESOS_1.kjb
        -> Versionado/OGD/Oracle/PROCESOS_1/JOB_PROCESOS_1_v2.kjb
    Devuelve (ok, ruta_respaldo_o_None, error_o_None).
    """
    out, ok = _run(f'test -f "{remote_path}" && echo EXISTE || echo NOEXISTE')
    if not ok:
        return False, None, f"No se pudo verificar si ya existía un archivo en destino: {out}"
    if "EXISTE" not in out or "NOEXISTE" in out:
        return True, None, None  # no había nada que respaldar, se puede seguir

    root = PROD_ROOTS.get(tipo, "/pentaho/project/").rstrip("/")
    carpeta_remota = posixpath.dirname(remote_path)
    rel_dir = carpeta_remota[len(root):].strip("/") if carpeta_remota.startswith(root) else carpeta_remota.strip("/")

    nombre = posixpath.basename(remote_path)
    base, ext = posixpath.splitext(nombre)
    nombre_respaldo = f"{base}_{version_tag}{ext}"

    carpeta_respaldo = posixpath.join(VERSIONADO_ROOT, rel_dir) if rel_dir else VERSIONADO_ROOT
    ruta_respaldo = posixpath.join(carpeta_respaldo, nombre_respaldo)

    out2, ok2 = _run(f'mkdir -p "{carpeta_respaldo}" && cp -p "{remote_path}" "{ruta_respaldo}"')
    if not ok2:
        return False, None, f"No se pudo respaldar el archivo original antes de reemplazarlo: {out2 or 'sin detalle'}"
    return True, ruta_respaldo, None


def _file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# ════════════════════════════════════════════════════════
#  Árbol de carpetas
# ════════════════════════════════════════════════════════

def _tree_from_paths(paths, base):
    root_node  = {"name": os.path.basename(base), "type": "folder",
                  "path": base, "children": []}
    folder_map = {base: root_node}
    for fpath in sorted(paths):
        rel   = fpath.replace(base,"").lstrip("/")
        parts = rel.split("/")
        cur   = base; node = root_node
        for part in parts[:-1]:
            nxt = cur.rstrip("/") + "/" + part
            if nxt not in folder_map:
                f = {"name":part,"type":"folder","path":nxt,"children":[]}
                node["children"].append(f); folder_map[nxt] = f
            node = folder_map[nxt]; cur = nxt
        node["children"].append({"name":parts[-1],"type":"file","path":fpath,"remote":True})
    return root_node

def get_tree():
    cmd = (f'find {_PROOT} -type f '
           r'\( -name "*.ktr" -o -name "*.kjb" -o -name "*.py" \) '
           '2>/dev/null | sort')
    out, ok = _run(cmd)
    if not ok or not out.strip():
        return {"name":"project","type":"folder","path":_PROOT,"children":[]}
    paths = [p.strip() for p in out.splitlines() if p.strip()]
    return _tree_from_paths(paths, _PROOT)


# ════════════════════════════════════════════════════════
#  Búsqueda
# ════════════════════════════════════════════════════════

def search_ssh(text, types=None):
    text  = (text or "").strip()
    if len(text) < 2: return []
    types = [t.lower().strip(".") for t in (types or ["ktr","kjb","py"]) if t]
    name_f = " -o ".join(f'-name "*.{t}"' for t in types)
    safe   = text.replace('"','').replace("'","").replace("\\","")
    cmd    = (f'find {_PROOT} -type f \\( {name_f} \\) '
              f'-exec grep -liI -- "{safe}" {{}} \\; 2>/dev/null | head -{MAX_RESULTS}')
    out, ok = _run(cmd)
    if not ok or not out.strip(): return []
    results = []
    for fp in out.splitlines():
        fp = fp.strip()
        if not fp: continue
        fname  = os.path.basename(fp)
        folder = os.path.dirname(fp).replace(_PROOT,"").lstrip("/") or "."
        ext    = fname.rsplit(".",1)[-1].lower() if "." in fname else ""
        results.append({"archivo":fname,"ruta":folder,"path":fp,"tipo":ext,"remote":True})
    return results

def search_local(text, types=None):
    text  = (text or "").lower()
    types = [t.lower().strip(".") for t in (types or []) if t]
    out   = []
    if not os.path.isdir(LOCAL_PATH): return out
    for root, dirs, files in os.walk(LOCAL_PATH):
        dirs[:] = [d for d in dirs if d.lower() not in IGNORE_DIRS]
        for f in files:
            if not f.lower().endswith(ALLOWED_EXT): continue
            ext = f.lower().rsplit(".",1)[-1]
            if types and ext not in types: continue
            full = os.path.join(root, f)
            try:
                with open(full, encoding="utf8", errors="ignore") as fh:
                    if text in f.lower() or text in fh.read(65536).lower():
                        out.append({"archivo":f,
                                    "ruta":root.replace(LOCAL_PATH,"").lstrip("\\/") or ".",
                                    "path":full,"tipo":ext,"remote":False})
                        if len(out) >= MAX_RESULTS: return out
            except: pass
    return out


# ════════════════════════════════════════════════════════
#  Parseo ETL
# ════════════════════════════════════════════════════════

def _tables(sql):
    if not sql: return []
    tables = set()
    for pat in [r'\bfrom\s+([\w\.\"]+)', r'\bjoin\s+([\w\.\"]+)',
                r'\binto\s+([\w\.\"]+)', r'\bupdate\s+([\w\.\"]+)',
                r'\btruncate\s+table\s+([\w\.\"]+)',
                r'\bdelete\s+from\s+([\w\.\"]+)',
                r'\bmerge\s+into\s+([\w\.\"]+)']:
        for t in re.findall(pat, sql, re.IGNORECASE):
            t = t.replace('"','').strip()
            if t and re.search("[a-zA-Z]", t): tables.add(t)
    return sorted(tables)

def _cat(st):
    t = (st or "").lower()
    if "input"  in t: return "SOURCE"
    if "output" in t or "insert" in t or "update" in t: return "TARGET"
    if "join"   in t or "merge"  in t: return "JOIN"
    if "sort"   in t or "select" in t: return "TRANSFORM"
    return "PROCESS"

def _parse_ktr(root):
    steps, sources, targets, sqls = [], set(), set(), []
    for i, s in enumerate(root.iter("step"), 1):
        name  = s.findtext("name","-")
        stype = s.findtext("type","-")
        sql   = (s.findtext("sql") or s.findtext("lookup/sql")
                 or s.findtext("statement") or "").strip()
        dest  = (s.findtext("table") or s.findtext("tablename")
                 or s.findtext("lookup/table") or "-")
        tbls  = _tables(sql)
        for t in tbls: sources.add(t)
        if stype.lower() in {"insertupdate","tableoutput","delete","update",
                              "synchronizeaftermerge"} and dest != "-":
            targets.add(dest)
        if sql: sqls.append({"step":name,"sql":sql})
        steps.append({"nro":i,"step":name,"tipo":stype,
                      "origen":", ".join(tbls) or "-","destino":dest,
                      "categoria":_cat(stype),"sql":sql})
    n = len(steps)
    return {"steps":steps,"sql_blocks":sqls,
            "sources":sorted(sources),"targets":sorted(targets),"dependencies":[],
            "summary":{"total_steps":n,"sources":len(sources),"targets":len(targets),
                       "joins":0,"complexity":"HIGH" if n>12 else "MEDIUM" if n>5 else "LOW"}}

def _parse_kjb(root):
    entries, deps = [], []
    for i, e in enumerate(root.iter("entry"), 1):
        fn = e.findtext("filename","-")
        entries.append({"nro":i,"step":e.findtext("name","-"),
                        "tipo":e.findtext("type","-"),"origen":fn,
                        "destino":"-","categoria":"JOB","sql":""})
        if fn != "-": deps.append(fn)
    n = len(entries)
    return {"steps":entries,"sql_blocks":[],"sources":[],"targets":[],"dependencies":deps,
            "summary":{"total_steps":n,"sources":0,"targets":0,"joins":0,
                       "complexity":"HIGH" if n>12 else "MEDIUM" if n>5 else "LOW"}}

def _parse_py(path):
    data = {"functions":[],"classes":[],"imports":[],"rows":[],
            "sql_blocks":[],"sources":[],"targets":[],"dependencies":[],
            "summary":{"total_steps":0,"sources":0,"targets":0,"joins":0,"complexity":"LOW"}}
    try:
        with open(path, encoding="utf8", errors="ignore") as f: src = f.read()
        tree = pyast.parse(src)
        imp, fn, cl = set(), set(), set()
        for node in pyast.walk(tree):
            if   isinstance(node, pyast.Import):      [imp.add(n.name) for n in node.names]
            elif isinstance(node, pyast.ImportFrom):  imp.add(node.module or "")
            elif isinstance(node, (pyast.FunctionDef, pyast.AsyncFunctionDef)): fn.add(node.name)
            elif isinstance(node, pyast.ClassDef):    cl.add(node.name)
        imp = sorted(imp); fn = sorted(fn); cl = sorted(cl)
        rows = ([{"nro":i+1,"step":c,"tipo":"Class","origen":"-","destino":"-","categoria":"PROCESS","sql":""}
                 for i,c in enumerate(cl)] +
                [{"nro":len(cl)+i+1,"step":f,"tipo":"Function","origen":"-","destino":"-","categoria":"PROCESS","sql":""}
                 for i,f in enumerate(fn)])
        n = len(rows)
        data.update({"imports":imp,"functions":fn,"classes":cl,"rows":rows,
                     "summary":{"total_steps":n,"sources":len(imp),"targets":len(fn),
                                "joins":len(cl),"complexity":"HIGH" if n>20 else "MEDIUM" if n>8 else "LOW"}})
    except Exception as e:
        app.logger.error("parse_py: %s", e)
    return data

def parse_file(path, is_remote=False):
    ext   = os.path.splitext(path)[1].lower()
    empty = {"steps":[],"rows":[],"sql_blocks":[],"sources":[],"targets":[],
             "dependencies":[],"functions":[],"classes":[],"imports":[],
             "summary":{"total_steps":0,"sources":0,"targets":0,"joins":0,"complexity":"LOW"}}
    content = ""
    if is_remote:
        content = _read_content(path)
        if not content: return empty, ""
        if ext in (".ktr",".kjb"):
            try:
                root   = ET.fromstring(content)
                parsed = _parse_ktr(root) if ext==".ktr" else _parse_kjb(root)
                parsed["rows"] = parsed["steps"]
                parsed.setdefault("functions",[]); parsed.setdefault("classes",[]); parsed.setdefault("imports",[])
                return parsed, content
            except Exception as e:
                app.logger.error("XML remote parse: %s", e); return empty, content
        elif ext == ".py":
            with tempfile.NamedTemporaryFile(mode="w",suffix=".py",delete=False,encoding="utf8") as tmp:
                tmp.write(content); tp = tmp.name
            d = _parse_py(tp); os.unlink(tp); d["rows"] = d.get("rows",[]); return d, content
    else:
        if not os.path.exists(path): return empty, ""
        with open(path, encoding="utf8", errors="ignore") as f:
            content = f.read(PREVIEW_MAX_CHARS)
        if ext in (".ktr",".kjb"):
            try:
                root   = ET.parse(path).getroot()
                parsed = _parse_ktr(root) if ext==".ktr" else _parse_kjb(root)
                parsed["rows"] = parsed["steps"]
                parsed.setdefault("functions",[]); parsed.setdefault("classes",[]); parsed.setdefault("imports",[])
                return parsed, content
            except Exception as e:
                app.logger.error("XML local parse: %s", e); return empty, content
        elif ext == ".py":
            d = _parse_py(path); d["rows"] = d.get("rows",[]); return d, content
    return empty, content


# ════════════════════════════════════════════════════════
#  Comparador
# ════════════════════════════════════════════════════════

def _ext_diff(xml_str, ext):
    base = {"steps":[],"sources":[],"targets":[],"connections":[],"sql_blocks":[]}
    if not xml_str: return base
    try:
        root = ET.fromstring(xml_str)
        if ext == ".ktr":
            p = _parse_ktr(root)
            base.update({"steps":[s["step"] for s in p["steps"]],
                         "sources":p["sources"],"targets":p["targets"],
                         "sql_blocks":p["sql_blocks"]})
        else:
            p = _parse_kjb(root); base["steps"] = [s["step"] for s in p["steps"]]
        for c in root.iter("connection"):
            n = c.findtext("name","").strip(); t = c.findtext("type","").strip()
            if n: base["connections"].append(f"{n} [{t}]" if t else n)
    except Exception as e:
        app.logger.error("ext_diff: %s", e)
    return base

def _diff(a, b):
    sa, sb = set(a), set(b)
    return {"solo_servidor":sorted(sa-sb),"solo_local":sorted(sb-sa),
            "comunes":sorted(sa&sb),"total_srv":len(sa),"total_loc":len(sb)}

def _diff_sql(sa, sb):
    ma={s["step"]:s["sql"] for s in sa}; mb={s["step"]:s["sql"] for s in sb}
    ss, sl, df, eq = [], [], [], []
    for step in sorted(set(ma)|set(mb)):
        if   step in ma and step not in mb: ss.append({"step":step,"sql":ma[step]})
        elif step in mb and step not in ma: sl.append({"step":step,"sql":mb[step]})
        else:
            if " ".join(ma[step].split()).lower() != " ".join(mb[step].split()).lower():
                df.append({"step":step,"sql_a":ma[step],"sql_b":mb[step]})
            else: eq.append(step)
    return {"solo_servidor":ss,"solo_local":sl,"diferentes":df,"iguales":eq}


# ════════════════════════════════════════════════════════
#  Crontab
# ════════════════════════════════════════════════════════

def _cron_text(s):
    p = s.split()
    if len(p) != 5: return s
    m, h, d, mo, wd = p
    dias = {"0":"Dom","1":"Lun","2":"Mar","3":"Mié","4":"Jue","5":"Vie","6":"Sáb","7":"Dom"}
    if s == "* * * * *":    return "Cada minuto"
    if m.startswith("*/"):  return f"Cada {m[2:]} minutos"
    if h.startswith("*/"):  return f"Cada {h[2:]} horas"
    if wd == "*" and m.isdigit() and h.isdigit():
        return f"Todos los días {h.zfill(2)}:{m.zfill(2)}"
    if wd.isdigit():        return f"{dias.get(wd,wd)} {h.zfill(2)}:{m.zfill(2)}"
    return s


# ════════════════════════════════════════════════════════
#  Power BI — Extracción de páginas y colores
# ════════════════════════════════════════════════════════

def _jparse(val):
    if isinstance(val, dict): return val
    if isinstance(val, str):
        s = val.strip()
        if s.startswith("{") or s.startswith("["):
            try: return json.loads(s)
            except: pass
    return {}

def _f(v, d=0.0):
    try: return float(v) if v is not None else d
    except: return d

def _read_zip_component(z, name):
    if name not in z.namelist(): return None
    try:
        raw = z.read(name)
        for enc in ("utf-8-sig","utf-16","utf-8","latin-1"):
            try: return json.loads(raw.decode(enc))
            except: pass
    except: pass
    return None

def extraer_paginas(lay):
    if not lay: return []
    pages = []
    for sec in lay.get("sections", []):
        name   = (sec.get("displayName") or sec.get("name") or "Página").strip()
        hidden = sec.get("displayOption", 0) == 1
        cfg = _jparse(sec.get("config",""))
        try:    cw = max(200, int(cfg.get("defaultViewportWidth")  or 1280))
        except: cw = 1280
        try:    ch = max(200, int(cfg.get("defaultViewportHeight") or 720))
        except: ch = 720
        visuals = []
        for vc in (sec.get("visualContainers") or []):
            x = vc.get("x"); y = vc.get("y")
            w = vc.get("width"); h = vc.get("height")
            pos = vc.get("position")
            if isinstance(pos, dict):
                if x is None: x = pos.get("x")
                if y is None: y = pos.get("y")
                if w is None: w = pos.get("width")
                if h is None: h = pos.get("height")
            x = _f(x); y = _f(y)
            w = max(8.0, _f(w,120)); h = max(8.0, _f(h,80))
            vc_cfg = _jparse(vc.get("config",""))
            vtype  = ""
            sv = vc_cfg.get("singleVisual") or {}
            if sv: vtype = sv.get("visualType","")
            if not vtype and "singleVisualGroup" in vc_cfg: vtype = "group"
            if not vtype:
                raw_cfg = vc.get("config","")
                if isinstance(raw_cfg, str):
                    m = re.search(r'"visualType"\s*:\s*"([^"]+)"', raw_cfg)
                    if m: vtype = m.group(1)
            label = VISUAL_TYPES.get(vtype, vtype or "Visual")
            color = VISUAL_COLORS.get(vtype, "#94A3B8")
            visuals.append({"x":round(x,1),"y":round(y,1),"w":round(w,1),"h":round(h,1),
                            "type":vtype,"label":label,"color":color})
        visuals.sort(key=lambda v: (v["y"], v["x"]))
        pages.append({"name":name,"hidden":hidden,"cw":cw,"ch":ch,
                      "visuals":visuals,"n":len(visuals)})
    return pages

def extraer_colores(lay, z=None):
    out = {"nombre":"Sin tema","colores":[],"es_standard":False}
    if not lay: return out
    colores = []; nombre = ""
    try:
        raw_cfg = lay.get("config",""); cfg = _jparse(raw_cfg)
        tc = cfg.get("themeCollection") or {}
        if isinstance(tc, str): tc = _jparse(tc)
        theme = tc.get("theme") or tc or {}
        if isinstance(theme, str): theme = _jparse(theme)
        nombre = theme.get("name","") or cfg.get("themeName","")
        for key in ("dataColors","colors","foregroundColors","backgroundColors","colorPalette","palette","seriesColors"):
            v = theme.get(key)
            if isinstance(v, list):
                cands = [c for c in v if isinstance(c,str) and re.match(r'^#[0-9A-Fa-f]{6}$',c.strip())]
                if cands: colores = cands; break
        if not colores:
            for key in ("theme","activeTheme","reportTheme"):
                sub = cfg.get(key)
                if isinstance(sub, str): sub = _jparse(sub)
                if isinstance(sub, dict):
                    if not nombre: nombre = sub.get("name","")
                    for ck in ("dataColors","colors","palette"):
                        v = sub.get(ck)
                        if isinstance(v, list):
                            cands = [c for c in v if isinstance(c,str) and re.match(r'^#[0-9A-Fa-f]{6}$',c.strip())]
                            if cands: colores = cands; break
                    if colores: break
        if not colores and isinstance(raw_cfg, str):
            m = re.search(r'"(?:dataColors|colors|palette)"\s*:\s*\[([^\]]+)\]', raw_cfg)
            if m:
                cands = re.findall(r'#[0-9A-Fa-f]{6}', m.group(1))
                if cands: colores = cands
        if not colores:
            vis_colors = set()
            for sec in lay.get("sections",[])[:3]:
                for vc in (sec.get("visualContainers") or [])[:20]:
                    vc_str = vc.get("config","")
                    if isinstance(vc_str, str):
                        hexs = re.findall(r'"#([0-9A-Fa-f]{6})"', vc_str)
                        for h in hexs:
                            c = "#" + h.upper()
                            if c not in ("#FFFFFF","#000000","#FFFFFFFF"): vis_colors.add(c)
            if vis_colors: colores = sorted(vis_colors)[:12]
        if not colores:
            all_hex = re.findall(r'#[0-9A-Fa-f]{6}', json.dumps(lay))
            freq = {}
            for h in all_hex:
                h = h.upper()
                if h not in ("#FFFFFF","#000000","#FAFAFA","#F8F8F8","#EEEEEE"):
                    freq[h] = freq.get(h,0)+1
            colores = [c for c,_ in sorted(freq.items(),key=lambda x:-x[1])[:12]]
    except: pass
    seen = set(); uniq = []
    for c in colores:
        cu = c.upper()
        if cu not in seen: seen.add(cu); uniq.append(cu)
    colores = uniq[:12]
    return {"nombre":nombre or "Tema del reporte","colores":colores,
            "es_standard":colores[:len(THEME_STD)]==THEME_STD if colores else False}


# ════════════════════════════════════════════════════════
#  Power BI — Validación
# ════════════════════════════════════════════════════════

def validar_pbix(ruta):
    res = []
    def ok(cat,r,m,d=""): res.append({"cat":cat,"regla":r,"estado":"OK",  "msg":m,"det":d,"sev":"INFO"})
    def wn(cat,r,m,d=""): res.append({"cat":cat,"regla":r,"estado":"AVISO","msg":m,"det":d,"sev":"AVISO"})
    def er(cat,r,m,d=""): res.append({"cat":cat,"regla":r,"estado":"ERROR","msg":m,"det":d,"sev":"ERROR"})

    mb  = os.path.getsize(ruta)/1024/1024
    lim = REGLAS["max_mb"]
    (wn if mb>lim else ok)("Estructura","ESTR-01",f"Tamaño: {mb:.1f} MB (límite {lim} MB)")

    try: z = zipfile.ZipFile(ruta,"r")
    except:
        er("Estructura","ESTR-02","Archivo corrupto o no es ZIP válido")
        return _build_pbix(res,[],{},{})

    ok("Estructura","ESTR-02","Formato ZIP válido")
    comps = z.namelist()

    for c in ["DataModel","Report/Layout","Connections"]:
        (ok if c in comps else wn)("Estructura","ESTR-03",
            f"Componente {'presente' if c in comps else 'no encontrado'}: {c}")

    cd = _read_zip_component(z,"Connections")
    if cd is None:
        wn("Conexiones","CONN-01","No se pudo leer Connections")
    else:
        conns = cd.get("Connections",[])
        proh  = [f.lower() for f in REGLAS["fuentes_prohibidas"]]
        tipos = []
        for c in conns:
            kind = c.get("ConnectionType",c.get("Kind",""))
            path = c.get("ConnectionString",c.get("Path",""))
            tipos.append(kind)
            if any(p in kind.lower() for p in proh):
                er("Conexiones","CONN-02",f"Fuente prohibida: {kind}",path[:80])
            elif path and re.search(r"^[A-Za-z]:\\|\.xlsx?$|\.csv$|\.txt$",path,re.I):
                er("Conexiones","CONN-03",f"Ruta local: {path[:80]}")
            else:
                ok("Conexiones","CONN-04",f"Conexión OK: {kind}")
        ok("Conexiones","CONN-05",f"{len(conns)} conexión(es)",", ".join(sorted(set(tipos))))

    lay = _read_zip_component(z,"Report/Layout")
    if lay is None:
        wn("Layout","LAY-01","No se pudo leer Report/Layout")
    else:
        secs = lay.get("sections",[])
        n    = len(secs); lp = REGLAS["limite_paginas"]
        (wn if n>lp else ok)("Layout","LAY-02",f"Páginas: {n} (límite {lp})")
        gen = ["page","página","sheet","hoja","tab","pestaña"]
        for s in secs:
            nm = s.get("displayName",s.get("name",""))
            if any(nm.lower().startswith(g) for g in gen):
                wn("Layout","LAY-03",f"Nombre genérico: '{nm}'")
        occ = [s.get("displayName","") for s in secs if s.get("displayOption",0)==1]
        (wn if occ else ok)("Layout","LAY-04",
            f"Páginas ocultas: {len(occ)}" if occ else "Sin páginas ocultas",", ".join(occ))
        for s in secs:
            vis = len(s.get("visualContainers",[]))
            if vis > 30:
                wn("Layout","LAY-05",f"'{s.get('displayName','')}': {vis} visuales (máx recomendado 30)")

    # DAX schema — guardamos medidas para SQLite también
    schema    = _read_zip_component(z,"DataModelSchema")
    medidas_d = []   # para guardar en SQLite

    if schema is None:
        wn("Medidas DAX","DAX-01","DataModelSchema no disponible")
    else:
        tabs = schema.get("model",{}).get("tables",[])
        nt = len(tabs); nc = sum(len(t.get("columns",[])) for t in tabs)
        nm = sum(len(t.get("measures",[])) for t in tabs)
        for obj,val,lk in [("Tablas",nt,"limite_tablas"),
                            ("Columnas",nc,"limite_columnas"),
                            ("Medidas",nm,"limite_medidas")]:
            lv = REGLAS[lk]
            (wn if val>lv else ok)("Medidas DAX","DAX-02",f"{obj}: {val} (límite {lv})")
        for t in tabs:
            for m in t.get("measures",[]):
                expr = m.get("expression",""); nm2 = m.get("name","")
                tiene_var    = "VAR " in expr.upper()
                tiene_divide = "DIVIDE(" in expr.upper()
                expr_larga   = len(expr) > 200
                medidas_d.append({
                    "tabla":t.get("name",""), "nombre":nm2, "expresion":expr,
                    "tiene_var":tiene_var, "tiene_divide":tiene_divide,
                    "expr_larga":expr_larga,
                })
                if "/" in expr and not tiene_divide:
                    wn("Medidas DAX","DAX-10",f"'{nm2}': división sin DIVIDE()")
                if expr_larga and not tiene_var:
                    wn("Medidas DAX","DAX-11",f"'{nm2}': expresión larga sin VAR")

    sec_raw = None
    if "SecurityBindings" in comps:
        try: sec_raw = z.read("SecurityBindings")
        except: pass
    has_rls = bool(sec_raw and len(sec_raw) > 10)
    (ok if has_rls else wn)("Seguridad RLS","SEC-01",
        "RLS configurado" if has_rls else "Sin SecurityBindings")
    if schema:
        tnames = [t.get("name","").upper() for t in schema.get("model",{}).get("tables",[])]
        for tc in REGLAS["tablas_criticas_rls"]:
            if any(tc in n for n in tnames):
                (ok if has_rls else er)("Seguridad RLS","SEC-02",
                    f"Tabla '{tc}': {'RLS presente' if has_rls else 'sin RLS'}",
                    "" if has_rls else "Agregar roles antes de publicar")
        for t in schema.get("model",{}).get("tables",[]):
            for c in t.get("columns",[]):
                cn = c.get("name","").upper()
                for s in REGLAS["columnas_sensibles"]:
                    if s.upper() in cn and not c.get("isHidden",False):
                        wn("Seguridad RLS","SEC-03",
                           f"Columna sensible visible: {t.get('name','')}.{c.get('name','')}")

    meta = _read_zip_component(z,"Metadata")
    if meta:
        autor = meta.get("createdBy",meta.get("author",""))
        (ok if autor else wn)("Metadatos","META-01",
            f"Autor: {autor}" if autor else "Sin autor registrado")
        desc = meta.get("description","")
        (ok if desc else wn)("Metadatos","META-02",
            "Descripción presente" if desc else "Sin descripción del reporte")

    if lay:
        ls   = json.dumps(lay)
        imgs = ls.count('"base64"') + ls.count('"imageUrl"')
        (wn if imgs>10 else ok)("Performance","PERF-01",f"Imágenes embebidas: {imgs}")
        bm   = len(lay.get("bookmarks",[]))
        (wn if bm>30 else ok)("Performance","PERF-02",f"Bookmarks: {bm}")

    pages  = extraer_paginas(lay) if lay else []
    colors = extraer_colores(lay, z) if lay else {}

    if colors.get("colores"):
        (ok if colors["es_standard"] else wn)("Colores","COL-01",
            f"Tema: '{colors['nombre']}'" + (" — estándar corporativo" if colors["es_standard"]
            else " — verificar paleta corporativa"))
    else:
        wn("Colores","COL-01","Sin tema de color detectado — aplicar tema corporativo")

    z.close()
    return _build_pbix(res, pages, colors, medidas_d)

def _build_pbix(res, pages, colors, medidas_d=None):
    cats = {}
    for r in res: cats.setdefault(r["cat"],[]).append(r)
    er  = sum(1 for r in res if r["sev"]=="ERROR")
    av  = sum(1 for r in res if r["sev"]=="AVISO")
    ok_ = sum(1 for r in res if r["sev"]=="INFO")
    return {"resultados":res,"categorias":cats,
            "errores":er,"avisos":av,"pasaron":ok_,
            "total":len(res),"aprobado":er==0,
            "pages":pages,"colors":colors,
            "medidas_detalle": medidas_d or []}


# ════════════════════════════════════════════════════════
#  RUTAS FLASK — Autenticación
# ════════════════════════════════════════════════════════

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        usuario  = request.form.get("usuario", "").strip()
        password = request.form.get("password", "")
        with _db() as conn:
            row = conn.execute("SELECT * FROM usuarios WHERE usuario=?", (usuario,)).fetchone()
        if row and not row["activo"]:
            return render_template("login.html", error="Este usuario está desactivado. Consultá con un administrador.")
        if row and check_password_hash(row["password_hash"], password):
            session["usuario"]    = row["usuario"]
            session["usuario_id"] = row["id"]
            session["nombre"]     = row["nombre"] or row["usuario"]
            session["rol"]        = row["rol"]
            session["debe_cambiar_password"] = bool(row["debe_cambiar_password"])
            with _db() as conn:
                conn.execute("UPDATE usuarios SET ultimo_login=? WHERE id=?",
                             (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), row["id"]))
                conn.commit()
            if session["debe_cambiar_password"]:
                return redirect(url_for("usuarios_home"))
            destino = request.args.get("next") or url_for("inicio")
            return redirect(destino)
        return render_template("login.html", error="Usuario o contraseña incorrectos")
    return render_template("login.html", error=None)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ════════════════════════════════════════════════════════
#  USUARIOS — alta, activar/desactivar, permisos por pantalla, contraseña
# ════════════════════════════════════════════════════════

import secrets
import string as _string_mod

def _generar_password_temporal(n=12):
    alfabeto = _string_mod.ascii_letters + _string_mod.digits
    return "".join(secrets.choice(alfabeto) for _ in range(n))


@app.route("/usuarios")
@login_required
def usuarios_home():
    es_admin = session.get("rol") == "admin"
    usuarios_lista = []
    permisos_por_usuario = {}

    if es_admin:
        with _db() as conn:
            usuarios_lista = [dict(r) for r in conn.execute(
                "SELECT id, usuario, nombre, rol, activo, ultimo_login FROM usuarios ORDER BY usuario").fetchall()]
            for u in usuarios_lista:
                filas = conn.execute(
                    "SELECT pagina, permitido FROM usuario_permisos WHERE usuario_id=?", (u["id"],)).fetchall()
                permisos_por_usuario[u["id"]] = {r["pagina"]: bool(r["permitido"]) for r in filas}

    return render_template("usuarios.html", es_admin=es_admin, usuarios=usuarios_lista,
                            permisos_por_usuario=permisos_por_usuario, paginas=PAGINAS,
                            debe_cambiar_password=session.get("debe_cambiar_password", False))


@app.route("/api/usuarios/crear", methods=["POST"])
@admin_required
def api_usuarios_crear():
    data = request.get_json(force=True) or {}
    usuario = (data.get("usuario") or "").strip()
    nombre = (data.get("nombre") or "").strip()
    rol = data.get("rol") if data.get("rol") in ("admin", "usuario") else "usuario"
    if not usuario:
        return jsonify({"ok": False, "error": "Falta el nombre de usuario"}), 400

    password_temporal = _generar_password_temporal()
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with _db() as conn:
            cur = conn.execute("""
                INSERT INTO usuarios (usuario, password_hash, nombre, rol, activo, debe_cambiar_password, creado)
                VALUES (?,?,?,?,1,1,?)
            """, (usuario, generate_password_hash(password_temporal), nombre or usuario, rol, ts))
            uid = cur.lastrowid
            for clave in PAGINAS:
                conn.execute("""
                    INSERT INTO usuario_permisos (usuario_id, pagina, permitido) VALUES (?,?,0)
                """, (uid, clave))
            conn.commit()
    except sqlite3.IntegrityError:
        return jsonify({"ok": False, "error": "Ese usuario ya existe"}), 400

    return jsonify({"ok": True, "usuario_id": uid, "password_temporal": password_temporal})


@app.route("/api/usuarios/<int:uid>/eliminar", methods=["POST"])
@admin_required
def api_usuarios_eliminar(uid):
    if uid == session.get("usuario_id"):
        return jsonify({"ok": False, "error": "No podés eliminar tu propio usuario."}), 400
    with _db() as conn:
        row = conn.execute("SELECT usuario, rol FROM usuarios WHERE id=?", (uid,)).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "Usuario no encontrado"}), 404
        if row["rol"] == "admin":
            total_admins = conn.execute(
                "SELECT COUNT(*) c FROM usuarios WHERE rol='admin'").fetchone()["c"]
            if total_admins <= 1:
                return jsonify({"ok": False, "error": "No podés eliminar al único administrador que queda."}), 400
        conn.execute("DELETE FROM usuario_permisos WHERE usuario_id=?", (uid,))
        conn.execute("DELETE FROM usuarios WHERE id=?", (uid,))
        conn.commit()
    return jsonify({"ok": True})


@app.route("/api/usuarios/<int:uid>/activo", methods=["POST"])
@admin_required
def api_usuarios_toggle_activo(uid):
    data = request.get_json(force=True) or {}
    activo = int(bool(data.get("activo", True)))
    if uid == session.get("usuario_id") and not activo:
        return jsonify({"ok": False, "error": "No podés desactivar tu propio usuario."}), 400
    with _db() as conn:
        conn.execute("UPDATE usuarios SET activo=? WHERE id=?", (activo, uid))
        conn.commit()
    return jsonify({"ok": True})


@app.route("/api/usuarios/<int:uid>/permisos", methods=["POST"])
@admin_required
def api_usuarios_permisos(uid):
    """Body: {"pentaho": true, "deploy": false, ...}"""
    data = request.get_json(force=True) or {}
    with _db() as conn:
        for pagina, permitido in data.items():
            if pagina not in PAGINAS:
                continue
            conn.execute("""
                INSERT INTO usuario_permisos (usuario_id, pagina, permitido) VALUES (?,?,?)
                ON CONFLICT(usuario_id, pagina) DO UPDATE SET permitido=excluded.permitido
            """, (uid, pagina, int(bool(permitido))))
        conn.commit()
    return jsonify({"ok": True})


@app.route("/api/usuarios/<int:uid>/resetear_password", methods=["POST"])
@admin_required
def api_usuarios_resetear_password(uid):
    """Genera una contraseña temporal nueva para el usuario y la devuelve UNA vez, en claro."""
    nueva = _generar_password_temporal()
    with _db() as conn:
        row = conn.execute("SELECT usuario FROM usuarios WHERE id=?", (uid,)).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "Usuario no encontrado"}), 404
        conn.execute("UPDATE usuarios SET password_hash=?, debe_cambiar_password=1 WHERE id=?",
                     (generate_password_hash(nueva), uid))
        conn.commit()
    return jsonify({"ok": True, "usuario": row["usuario"], "password_temporal": nueva})


@app.route("/api/usuarios/cambiar_password", methods=["POST"])
@login_required
def api_usuarios_cambiar_password():
    """Cambio de contraseña propio — cualquier usuario logueado, sin necesitar rol admin."""
    data = request.get_json(force=True) or {}
    actual = data.get("password_actual", "")
    nueva = data.get("password_nueva", "")
    if not nueva or len(nueva) < 8:
        return jsonify({"ok": False, "error": "La nueva contraseña debe tener al menos 8 caracteres."}), 400

    with _db() as conn:
        row = conn.execute("SELECT password_hash FROM usuarios WHERE id=?",
                            (session.get("usuario_id"),)).fetchone()
        if not row or not check_password_hash(row["password_hash"], actual):
            return jsonify({"ok": False, "error": "La contraseña actual no es correcta."}), 400
        conn.execute("UPDATE usuarios SET password_hash=?, debe_cambiar_password=0 WHERE id=?",
                     (generate_password_hash(nueva), session.get("usuario_id")))
        conn.commit()
    session["debe_cambiar_password"] = False
    return jsonify({"ok": True})


# ════════════════════════════════════════════════════════
#  RUTAS FLASK — Pentaho Explorer
# ════════════════════════════════════════════════════════

@app.route("/")
@login_required
def home():
    return render_template("index.html")


@app.route("/inicio")
@login_required
def inicio():
    """Dashboard de bienvenida con las tarjetas de todos los módulos."""
    return render_template("inicio.html")

@app.route("/api/tree")
@login_required
def api_tree():
    return jsonify(get_tree())

@app.route("/search")
@login_required
def search():
    q     = request.args.get("q","").strip()
    types = [t for t in request.args.get("types","").split(",") if t]
    start = time.time()
    res   = search_ssh(q, types) or search_local(q, types)
    return jsonify({"results":res,"count":len(res),
                    "elapsed_ms":round((time.time()-start)*1000,2)})

@app.route("/open")
@login_required
def open_file():
    path = request.args.get("path","")
    q    = request.args.get("q","")
    if not path: abort(404)
    is_remote = path.startswith("/")
    ext       = os.path.splitext(path)[1].lower()
    parsed, content = parse_file(path, is_remote=is_remote)
    return render_template("viewer.html",
        file=path, filename=os.path.basename(path), ext=ext,
        content=content, search=q,
        rows=parsed.get("rows",parsed.get("steps",[])),
        summary=parsed["summary"], sources=parsed["sources"],
        targets=parsed["targets"], dependencies=parsed["dependencies"],
        sql_blocks=parsed["sql_blocks"],
        functions=parsed.get("functions",[]),
        classes=parsed.get("classes",[]),
        imports=parsed.get("imports",[]))


@app.route("/api/descargar_local")
@login_required
def api_descargar_local():
    """Descarga un archivo que ya está en el disco local del servidor (LOCAL_PATH)."""
    path = request.args.get("path", "")
    local_root = os.path.normpath(LOCAL_PATH)
    candidato = os.path.normpath(path)
    if not path or not (candidato + os.sep).startswith(local_root + os.sep):
        abort(404)
    if not os.path.isfile(candidato):
        abort(404)
    return send_file(candidato, as_attachment=True, download_name=os.path.basename(candidato))


@app.route("/api/descargar_local_carpeta")
@login_required
def api_descargar_local_carpeta():
    """Comprime y descarga la carpeta local (dentro de LOCAL_PATH) que contiene un archivo."""
    path = request.args.get("path", "")
    carpeta_param = request.args.get("carpeta", "")
    local_root = os.path.normpath(LOCAL_PATH)

    carpeta = os.path.normpath(carpeta_param) if carpeta_param else os.path.dirname(os.path.normpath(path))
    if not (carpeta + os.sep).startswith(local_root + os.sep) or not os.path.isdir(carpeta):
        abort(404)

    nombre_zip = os.path.basename(carpeta.rstrip(os.sep)) or "carpeta"
    zip_base = Path(tempfile.mkdtemp()) / nombre_zip
    shutil.make_archive(str(zip_base), "zip", carpeta)
    return send_file(str(zip_base) + ".zip", as_attachment=True, download_name=f"{nombre_zip}.zip")


@app.route("/api/descargar_remoto")
@login_required
def api_descargar_remoto():
    """
    Descarga directa a tu máquina de cualquier archivo remoto que ya ves en
    el Explorador de Pentaho (KTR/KJB/PY), sin pasar por el flujo de versionado.
    """
    path = request.args.get("path", "")
    if not path or not path.startswith("/"):
        abort(404)
    nombre = posixpath.basename(path)
    tmp_local = Path(tempfile.mkdtemp()) / nombre
    ok, err = _sftp_get(path, tmp_local)
    if not ok:
        return jsonify({"ok": False, "error": f"Fallo el SFTP: {err}"}), 500
    return send_file(str(tmp_local), as_attachment=True, download_name=nombre)


def _zip_carpeta_remota(carpeta_remota, nombre_zip):
    """
    Trae TODOS los archivos de una carpeta remota (recursivo) y arma un .zip
    local con la misma estructura, para bajar la carpeta completa de una.
    Usa sudo (via _run) para empaquetar en el servidor con 'tar', porque el
    usuario SFTP puede no tener permiso de lectura directo sobre esos archivos,
    y así se trae un solo archivo en vez de uno por uno.
    Devuelve (ruta_zip, error).
    """
    staging_tar = f"/tmp/deploy_stage_{uuid.uuid4().hex}.tar.gz"
    cmd = f'tar -czf "{staging_tar}" -C "{carpeta_remota}" . && chmod 644 "{staging_tar}"'
    out, ok = _run(cmd)
    if not ok:
        return None, f"No se pudo preparar la carpeta en el servidor (sudo tar): {out or 'sin detalle'}"

    tmp_local_tar = Path(tempfile.mkdtemp()) / "carpeta.tar.gz"
    ssh = _ssh()
    try:
        sftp = ssh.open_sftp()
        sftp.get(staging_tar, str(tmp_local_tar))
        sftp.close()
    except Exception as e:
        return None, f"Fallo bajando el paquete comprimido: {e}"
    finally:
        ssh.close()
        _run(f'rm -f "{staging_tar}"')

    extract_dir = Path(tempfile.mkdtemp())
    try:
        with tarfile.open(tmp_local_tar) as tf:
            tf.extractall(extract_dir)
    except Exception as e:
        return None, f"El paquete bajado no se pudo abrir: {e}"

    zip_base = Path(tempfile.mkdtemp()) / nombre_zip
    shutil.make_archive(str(zip_base), "zip", str(extract_dir))
    return str(zip_base) + ".zip", None


@app.route("/api/descargar_remoto_carpeta")
@login_required
def api_descargar_remoto_carpeta():
    """
    Descarga, comprimida en .zip, TODA la carpeta que contiene un archivo
    remoto (o una carpeta indicada directamente), para bajar de una todo el
    proceso relacionado y no solo el archivo suelto.
      ?path=<archivo>   -> baja la carpeta que lo contiene
      ?carpeta=<dir>    -> baja esa carpeta directamente
    """
    path = request.args.get("path", "")
    carpeta = request.args.get("carpeta", "")
    if carpeta:
        carpeta_remota = carpeta
    elif path:
        carpeta_remota = posixpath.dirname(path)
    else:
        abort(404)

    nombre_zip = posixpath.basename(carpeta_remota.rstrip("/")) or "carpeta"
    zip_path, err = _zip_carpeta_remota(carpeta_remota, nombre_zip)
    if not zip_path:
        return jsonify({"ok": False, "error": err}), 500
    return send_file(zip_path, as_attachment=True, download_name=f"{nombre_zip}.zip")

@app.route("/catalog")
@login_required
def catalog():
    path = request.args.get("path","")
    if not path: abort(404)
    is_remote = path.startswith("/")
    ext       = os.path.splitext(path)[1].lower()
    parsed, _ = parse_file(path, is_remote=is_remote)
    return render_template("catalog.html",
        file=os.path.basename(path), ext=ext,
        summary=parsed["summary"], sources=parsed["sources"],
        targets=parsed["targets"], dependencies=parsed["dependencies"],
        sql_blocks=parsed["sql_blocks"],
        functions=parsed.get("functions",[]),
        classes=parsed.get("classes",[]),
        imports=parsed.get("imports",[]))

@app.route("/etl")
@login_required
def etl_dashboard():
    log, _ = _read_file(_LOG, tail=LOG_TAIL_LINES)
    lines  = log.splitlines() if log else []
    today  = time.strftime("%Y-%m-%d")
    all_rows = []
    for l in lines:
        l = l.strip()
        if not l: continue
        parts  = l.split()
        if len(parts) < 3: continue
        fecha   = parts[0] if len(parts[0])==10 and "-" in parts[0] else ""
        hora    = parts[1] if len(parts) > 1 and re.match(r'^\d{2}:\d{2}:\d{2}$', parts[1]) else ""
        proceso = parts[2] if len(parts)>2 else parts[-1]
        estado  = "ERROR" if "ERROR" in l.upper() else "OK"
        all_rows.append({"line":l,"estado":estado,"proceso":proceso,
                          "fecha":fecha,"hora":hora,"orden":f"{fecha} {hora}"})
    # Más reciente primero
    all_rows.sort(key=lambda r: r["orden"], reverse=True)
    fechas   = sorted({r["fecha"] for r in all_rows if r["fecha"]},reverse=True)
    hoy_rows = [r for r in all_rows if r["fecha"]==today]
    proc_hoy = {r["proceso"] for r in hoy_rows}
    err_hoy  = {r["proceso"] for r in hoy_rows if r["estado"]=="ERROR"}
    return render_template("etl_dashboard.html",
        all_rows=all_rows, rows=hoy_rows,
        total=len(proc_hoy), ok=len(proc_hoy)-len(err_hoy),
        error=len(err_hoy), today=today, fechas=fechas)

@app.route("/api/etl/log_detail")
@login_required
def api_etl_log_detail():
    """
    Log de detalle del servidor para un proceso puntual.
    Busca primero un archivo de log específico del proceso (ej. log_JOB_TICKETERA_20260703.log
    en /var/pentaho/logs); si no existe, hace fallback a las líneas del log general que
    mencionan ese proceso en esa fecha.
    """
    proceso = request.args.get("proceso", "").strip()
    fecha   = request.args.get("fecha", "").strip()
    if not proceso:
        return jsonify({"ok": False, "error": "Falta el nombre del proceso"}), 400

    safe_proc    = re.sub(r'[^A-Za-z0-9_\-]', '', proceso)
    fecha_compact = fecha.replace("-", "")

    archivos = []
    if safe_proc:
        if fecha_compact:
            cmd = (f'find /var/pentaho/logs -maxdepth 1 -iname "*{safe_proc}*{fecha_compact}*" '
                   f'2>/dev/null | sort')
        else:
            cmd = f'find /var/pentaho/logs -maxdepth 1 -iname "*{safe_proc}*" 2>/dev/null | sort'
        out, ok = _run(cmd)
        archivos = [l.strip() for l in out.splitlines() if l.strip()] if ok else []

    contenido = ""
    if archivos:
        partes = []
        for fp in archivos[:5]:
            txt, _ = _read_file(fp, tail=500)
            partes.append(f"===== {fp} =====\n{txt}")
        contenido = "\n\n".join(partes)
    else:
        grep_cmd = f'grep -i -- "{safe_proc}" {_LOG} 2>/dev/null'
        if fecha:
            grep_cmd += f' | grep -- "{fecha}"'
        contenido, _ = _run(grep_cmd)
        if contenido.strip():
            archivos = [_LOG]

    return jsonify({
        "ok": True, "proceso": proceso, "fecha": fecha,
        "archivos": archivos,
        "contenido": contenido.strip() or "No se encontraron registros de log para este proceso/fecha en el servidor."
    })

@app.route("/crontab")
@login_required
def crontab_view():
    data, _ = _read_file(_CRONTAB)
    rows = []
    for l in (data or "").splitlines():
        raw = l.strip()
        if not raw:
            continue
        activo  = not raw.startswith("#")
        limpio  = raw.lstrip("#").strip()
        p = limpio.split()
        if len(p) < 6:
            continue
        sched = " ".join(p[:5])
        rows.append({"raw":limpio,"schedule":sched,"schedule_text":_cron_text(sched),
                     "user":p[5],"command":" ".join(p[6:]),"activo":activo})
    return render_template("crontab.html", rows=rows)

@app.route("/api/crontab/toggle", methods=["POST"])
@login_required
def api_crontab_toggle():
    """
    Activa o desactiva (comenta con #) una línea del crontab del servidor.
    Se hace un backup de /etc/crontab antes de sobrescribirlo.
    """
    data  = request.get_json(force=True)
    linea = (data.get("linea") or "").strip()
    if not linea:
        return jsonify({"ok": False, "error": "Línea vacía"}), 400

    raw, ok = _read_file(_CRONTAB)
    if not ok or raw is None:
        return jsonify({"ok": False, "error": "No se pudo leer el crontab del servidor"}), 500

    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    _run(f"cp {_CRONTAB} {_CRONTAB}.bak_{ts}")

    nuevas = []
    encontrada = False
    activo_ahora = None
    for l in raw.splitlines():
        stripped = l.strip()
        comparador = stripped.lstrip("#").strip()
        if not encontrada and comparador == linea:
            encontrada = True
            if stripped.startswith("#"):
                nuevas.append(comparador)          # descomentar → activar
                activo_ahora = True
            else:
                nuevas.append("# " + stripped)     # comentar → desactivar
                activo_ahora = False
        else:
            nuevas.append(l)

    if not encontrada:
        return jsonify({"ok": False, "error": "No se encontró esa línea en el crontab actual"}), 404

    contenido_nuevo = "\n".join(nuevas) + "\n"
    try:
        ssh  = _ssh()
        sftp = ssh.open_sftp()
        tmp_remote = f"/tmp/crontab_edit_{ts}.txt"
        with sftp.open(tmp_remote, "w") as fh:
            fh.write(contenido_nuevo)
        sftp.close()
        _out, ok2 = _run(f"cp {tmp_remote} {_CRONTAB} && rm -f {tmp_remote}")
        ssh.close()
    except Exception as e:
        return jsonify({"ok": False, "error": f"No se pudo escribir el crontab: {e}"}), 500

    if not ok2:
        return jsonify({"ok": False, "error": "Falló la escritura del crontab en el servidor"}), 500

    return jsonify({"ok": True, "activo": activo_ahora})


# ════════════════════════════════════════════════════════
#  REPORTE DE ESTADOS — promedio de ejecuciones por proceso
# ════════════════════════════════════════════════════════

def _proximo_domingo(desde_dt):
    dias = (6 - desde_dt.weekday()) % 7   # weekday(): lunes=0 ... domingo=6
    return desde_dt + timedelta(days=dias)

def _veces_planificadas_en_rango(campos, d0, d1):
    """
    Estimación de cuántas veces debería haber corrido una tarea cron entre d0 y d1
    según sus campos (minuto hora dia_mes mes dia_semana). Soporta '*' y '*/N' en
    minuto/hora; NO soporta listas (1,3,5) ni rangos (1-5) — se cuenta como 1 vez/día
    en esos casos, así que es una aproximación, no un valor exacto.
    """
    try:
        minuto, hora, dom, mon, dow = campos
    except Exception:
        return 0
    veces_dia = 1
    if hora == "*" and minuto.startswith("*/"):
        try: veces_dia = max(1, (24*60)//int(minuto[2:]))
        except Exception: veces_dia = 1
    elif hora.startswith("*/"):
        try: veces_dia = max(1, 24//int(hora[2:]))
        except Exception: veces_dia = 1

    total = 0
    d = d0
    while d <= d1:
        dow_cron = str((d.isoweekday()) % 7)   # domingo=0 ... sábado=6 (estilo cron)
        dow_ok = dow in ("*", dow_cron, str(d.isoweekday()))
        dom_ok = dom in ("*", str(d.day))
        mon_ok = mon in ("*", str(d.month))
        if dow_ok and dom_ok and mon_ok:
            total += veces_dia
        d += timedelta(days=1)
    return total

@app.route("/reporte")
@login_required
def reporte_estados():
    return render_template("reporte_estados.html")

@app.route("/api/reporte/estados")
@login_required
def api_reporte_estados():
    hoy = datetime.now()
    desde = request.args.get("desde", "").strip()
    hasta = request.args.get("hasta", "").strip()
    if not desde:
        desde = hoy.strftime("%Y-%m-%d")
    if not hasta:
        hasta = _proximo_domingo(hoy).strftime("%Y-%m-%d")

    try:
        d0 = datetime.strptime(desde, "%Y-%m-%d")
        d1 = datetime.strptime(hasta, "%Y-%m-%d")
    except Exception:
        return jsonify({"ok": False, "error": "Fechas inválidas, usar formato YYYY-MM-DD"}), 400

    log, _ = _read_file(_LOG, tail=LOG_TAIL_LINES)
    lines  = log.splitlines() if log else []
    por_proceso = defaultdict(lambda: {"ok":0, "error":0, "fechas":set()})
    for l in lines:
        l = l.strip()
        if not l: continue
        parts = l.split()
        if len(parts) < 3: continue
        fecha = parts[0] if len(parts[0])==10 and "-" in parts[0] else ""
        if not fecha or fecha < desde or fecha > hasta:
            continue
        proceso = parts[2] if len(parts)>2 else parts[-1]
        estado  = "ERROR" if "ERROR" in l.upper() else "OK"
        por_proceso[proceso]["fechas"].add(fecha)
        por_proceso[proceso]["error" if estado=="ERROR" else "ok"] += 1

    cron_raw, _ = _read_file(_CRONTAB)
    planificado = {}
    for l in (cron_raw or "").splitlines():
        s = l.strip()
        if not s or s.startswith("#"): continue
        p = s.split()
        if len(p) < 6: continue
        cmd = " ".join(p[6:])
        m = re.search(r'([A-Za-z0-9_\-]+)\.(sh|py|kjb|ktr)', cmd)
        if not m: continue
        nombre = m.group(1).upper()
        veces  = _veces_planificadas_en_rango(p[:5], d0, d1)
        planificado[nombre] = planificado.get(nombre, 0) + veces

    filas = []
    for proc in sorted(set(list(por_proceso.keys()) + list(planificado.keys()))):
        datos  = por_proceso.get(proc, {"ok":0,"error":0,"fechas":set()})
        total  = datos["ok"] + datos["error"]
        planif = planificado.get(proc)
        pct_exito = round(datos["ok"]/total*100, 1) if total else 0.0
        cumplimiento = round(total/planif*100, 1) if planif else None
        filas.append({
            "proceso": proc, "ok": datos["ok"], "error": datos["error"],
            "total_ejecuciones": total, "dias_con_registro": len(datos["fechas"]),
            "pct_exito": pct_exito, "planificado": planif,
            "cumplimiento_pct": cumplimiento,
        })

    return jsonify({"ok": True, "desde": desde, "hasta": hasta, "filas": filas})


# ════════════════════════════════════════════════════════
#  AUDITORÍA DEL SERVIDOR — sesiones y cambios de archivos
# ════════════════════════════════════════════════════════

@app.route("/auditoria")
@login_required
def auditoria_servidor():
    return render_template("auditoria.html")

@app.route("/api/auditoria/sesiones")
@login_required
def api_auditoria_sesiones():
    """
    Sesiones recientes contra el servidor Pentaho, incluyendo la IP/host de origen.
    Como todas las conexiones usan el mismo usuario de sistema (sysadmin), esto NO
    identifica a la persona — solo desde qué IP se conectó alguien y cuándo. Para
    saber quién fue hay que cruzarlo con quién tenía esa IP asignada en ese momento
    (VPN, DHCP, etc.), algo que este portal no puede resolver por sí solo.
    """
    out, ok = _run("last -F -n 40 2>/dev/null")
    sesiones = [l.strip() for l in (out or "").splitlines()
                if l.strip() and not l.strip().startswith(("wtmp", "reboot"))]
    return jsonify({"ok": ok, "sesiones": sesiones})

@app.route("/api/auditoria/cambios")
@login_required
def api_auditoria_cambios():
    """
    Archivos creados o modificados recientemente en el proyecto Pentaho y en los logs.
    Incluye fecha de modificación y usuario propietario del archivo — NO incluye la IP
    de origen, porque el sistema de archivos de Linux no la registra. Para acercarse a
    "quién lo cambió y desde dónde", hay que cruzar la hora de este listado con
    /api/auditoria/sesiones (misma ventana de tiempo).
    """
    try:
        horas = float(request.args.get("horas", "48"))
    except Exception:
        horas = 48.0
    minutos = max(1, int(horas * 60))
    cmd = (f'find {_PROOT} /var/pentaho/logs -maxdepth 3 -type f -mmin -{minutos} '
           r'-printf "%TY-%Tm-%Td %TH:%TM|%u|%s|%p\n" 2>/dev/null | sort -r | head -150')
    out, ok = _run(cmd)
    cambios = []
    for l in (out or "").splitlines():
        p = l.split("|")
        if len(p) == 4:
            cambios.append({"fecha_mod": p[0], "usuario": p[1], "bytes": p[2], "path": p[3]})
    return jsonify({"ok": ok, "cambios": cambios})

@app.route("/compare", methods=["GET","POST"])
@login_required
def compare():
    if request.method == "GET":
        q = request.args.get("q","")
        return render_template("compare.html", q=q, results=[], diff=None, error=None)
    remote_path = request.form.get("remote_path","").strip()
    uploaded    = request.files.get("archivo_local")
    if not remote_path or not uploaded:
        return render_template("compare.html", q="", results=[], diff=None,
                               error="Seleccioná un archivo del servidor y subí el archivo local.")
    ext = os.path.splitext(remote_path)[1].lower()
    if ext not in (".ktr",".kjb"):
        return render_template("compare.html", q="", results=[], diff=None,
                               error="Solo se soportan .ktr y .kjb")
    srv_content = _read_content(remote_path)
    if not srv_content:
        return render_template("compare.html", q="", results=[], diff=None,
                               error="No se pudo leer el archivo del servidor.")
    try:
        loc_content = uploaded.read().decode("utf-8", errors="replace")
    except Exception as e:
        return render_template("compare.html", q="", results=[], diff=None,
                               error=f"Error leyendo archivo local: {e}")
    srv  = _ext_diff(srv_content, ext); loc = _ext_diff(loc_content, ext)
    diffs = {"steps":_diff(srv["steps"],loc["steps"]),
             "sources":_diff(srv["sources"],loc["sources"]),
             "targets":_diff(srv["targets"],loc["targets"]),
             "connections":_diff(srv["connections"],loc["connections"])}
    sql_diff = _diff_sql(srv["sql_blocks"],loc["sql_blocks"]) if ext==".ktr" else None
    total = sum(len(d["solo_servidor"])+len(d["solo_local"]) for d in diffs.values())
    if sql_diff:
        total += len(sql_diff["diferentes"])+len(sql_diff["solo_servidor"])+len(sql_diff["solo_local"])
    return render_template("compare.html", q="", results=[], diff={
        "remote_name":os.path.basename(remote_path),
        "local_file":uploaded.filename,
        "ext":ext,"diffs":diffs,"sql_diff":sql_diff,
        "total_diferencias":total,"identicos":total==0,
    }, error=None)

@app.route("/api/status")
@login_required
def api_status():
    _, ok = _run("echo ok")
    return jsonify({"status":"ok" if ok else "error"})


# ════════════════════════════════════════════════════════
#  RUTAS FLASK — Power BI
# ════════════════════════════════════════════════════════

@app.route("/powerbi")
@login_required
def powerbi_home():
    return render_template("powerbi.html", tiene_reglas=_rp.exists())

@app.route("/powerbi/validar", methods=["POST"])
@login_required
def powerbi_validar():
    archivo = request.files.get("pbix_file")
    if not archivo or not archivo.filename:
        return jsonify({"error":"No se recibió archivo"})
    if not archivo.filename.lower().endswith(".pbix"):
        return jsonify({"error":"Solo se aceptan archivos .pbix"})
    tmp = tempfile.mkdtemp()
    try:
        ruta = os.path.join(tmp, archivo.filename)
        archivo.save(ruta)
        data = validar_pbix(ruta)
        data["archivo"]   = archivo.filename
        data["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # Guardar en SQLite
        vid = guardar_validacion(data)
        data["validacion_id"] = vid
        # No enviar medidas detalle al frontend (puede ser pesado)
        data.pop("medidas_detalle", None)
        return jsonify(data)
    except Exception as e:
        app.logger.error(traceback.format_exc())
        return jsonify({"error":f"{type(e).__name__}: {e}"})
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

@app.route("/powerbi/historial")
@login_required
def powerbi_historial():
    """Página de historial de validaciones."""
    q      = request.args.get("q","").strip()
    fecha  = request.args.get("fecha","").strip()
    estado = request.args.get("estado","").strip()

    sql    = "SELECT * FROM validaciones WHERE 1=1"
    params = []
    if q:
        sql += " AND archivo LIKE ?"
        params.append(f"%{q}%")
    if fecha:
        sql += " AND fecha = ?"
        params.append(fecha)
    if estado == "aprobado":
        sql += " AND aprobado = 1"
    elif estado == "rechazado":
        sql += " AND aprobado = 0"

    sql += " ORDER BY id DESC LIMIT 200"

    with _db() as conn:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
        fechas_disp = [r["fecha"] for r in
                       conn.execute("SELECT DISTINCT fecha FROM validaciones ORDER BY fecha DESC").fetchall()]

    return render_template("powerbi_historial.html",
        validaciones=rows, q=q, fecha=fecha, estado=estado,
        fechas_disponibles=fechas_disp)

@app.route("/powerbi/historial/<int:vid>")
@login_required
def powerbi_detalle(vid):
    """Detalle completo de una validación guardada."""
    with _db() as conn:
        v = conn.execute("SELECT * FROM validaciones WHERE id=?", (vid,)).fetchone()
        if not v: abort(404)
        v = dict(v)
        reglas  = [dict(r) for r in conn.execute(
            "SELECT * FROM validacion_reglas WHERE validacion_id=? ORDER BY id", (vid,)).fetchall()]
        paginas = [dict(r) for r in conn.execute(
            "SELECT * FROM validacion_paginas WHERE validacion_id=? ORDER BY id", (vid,)).fetchall()]

    # Reconstruir datos del JSON completo
    full = {}
    try: full = json.loads(v.get("detalle_json","{}"))
    except: pass

    colores_list = []
    try: colores_list = json.loads(v.get("tema_colores","[]"))
    except: pass

    return render_template("powerbi_detalle.html",
        v=v, reglas=reglas, paginas=paginas,
        full=full, colores_list=colores_list)

@app.route("/powerbi/pdf", methods=["POST"])
@login_required
def powerbi_pdf():
    try:
        data = request.get_json(force=True)
        if not data: return jsonify({"error":"Sin datos"}),400
        html = render_template("reporte_pdf.html", d=data)
        try:
            from weasyprint import HTML as WP
            buf  = io.BytesIO(WP(string=html, base_url=str(BASE)).write_pdf())
            name = f"QA_PBIX_{data.get('archivo','reporte').replace('.pbix','')}.pdf"
            return send_file(buf, mimetype="application/pdf",
                             as_attachment=True, download_name=name)
        except ImportError:
            return html, 200, {"Content-Type":"text/html;charset=utf-8","X-PDF-Fallback":"true"}
    except Exception as e:
        return jsonify({"error":str(e)}),500

@app.route("/powerbi/reglas")
@login_required
def powerbi_reglas():
    reglas_data = [
        ({"icono":"🚫","titulo":"Fuentes prohibidas","descripcion":"No permitidas en el banco","tipo":"tags","color":"red"},
         REGLAS["fuentes_prohibidas"]),
        ({"icono":"✅","titulo":"Fuentes autorizadas","descripcion":"Conexiones permitidas","tipo":"tags","color":"green"},
         REGLAS["fuentes_permitidas"]),
        ({"icono":"🔒","titulo":"Tablas críticas RLS","descripcion":"Requieren Row Level Security","tipo":"tags","color":"red"},
         REGLAS["tablas_criticas_rls"]),
        ({"icono":"🔐","titulo":"Columnas sensibles","descripcion":"Deben estar ocultas o con RLS","tipo":"tags","color":"red"},
         REGLAS["columnas_sensibles"]),
        ({"icono":"📏","titulo":"Límites","descripcion":"Cantidades máximas recomendadas","tipo":"limite","color":"blue"},
         [{"label":"Tablas","valor":REGLAS["limite_tablas"]},
          {"label":"Columnas","valor":REGLAS["limite_columnas"]},
          {"label":"Medidas","valor":REGLAS["limite_medidas"]},
          {"label":"Páginas","valor":REGLAS["limite_paginas"]},
          {"label":"Tamaño MB","valor":REGLAS["max_mb"]}]),
    ]
    return render_template("powerbi_reglas.html", tiene_reglas=_rp.exists(), reglas_data=reglas_data)

@app.route("/api/powerbi/reglas", methods=["GET"])
@login_required
def get_powerbi_reglas():
    return jsonify({"reglas":REGLAS,"tiene_archivo":_rp.exists()})

@app.route("/api/powerbi/reglas", methods=["POST"])
@login_required
def save_powerbi_reglas():
    try:
        data  = request.get_json(force=True)
        clean = {k:v for k,v in (data or {}).items() if k in REGLAS_DEFAULT}
        if not clean: return jsonify({"ok":False,"error":"Sin claves válidas"}),400
        _rp.write_text(json.dumps(clean,ensure_ascii=False,indent=2),encoding="utf-8")
        REGLAS.update(clean)
        return jsonify({"ok":True})
    except Exception as e:
        return jsonify({"ok":False,"error":str(e)}),500

@app.route("/api/powerbi/reglas/reset", methods=["POST"])
@login_required
def reset_powerbi_reglas():
    if _rp.exists(): _rp.unlink()
    return jsonify({"ok":True})

@app.route("/api/powerbi/historial")
@login_required
def api_historial():
    """API JSON para consultas externas."""
    q     = request.args.get("q","").strip()
    fecha = request.args.get("fecha","").strip()
    sql   = "SELECT id,archivo,fecha,timestamp,aprobado,errores,avisos,pasaron,total,mb,n_paginas,n_medidas,n_tablas,n_columnas,tema_nombre FROM validaciones WHERE 1=1"
    params = []
    if q:
        sql += " AND archivo LIKE ?"; params.append(f"%{q}%")
    if fecha:
        sql += " AND fecha = ?"; params.append(fecha)
    sql += " ORDER BY id DESC LIMIT 100"
    with _db() as conn:
        rows = [dict(r) for r in conn.execute(sql,params).fetchall()]
    return jsonify({"count":len(rows),"validaciones":rows})


# ════════════════════════════════════════════════════════
#  PYTHON & ML — Ejecución y Análisis
# ════════════════════════════════════════════════════════

SCRIPTS_DIR = BASE / "scripts_python"
SCRIPTS_DIR.mkdir(exist_ok=True)
RESULTS_DIR = BASE / "resultados_python"
RESULTS_DIR.mkdir(exist_ok=True)

# Almacén de ejecuciones en memoria
_executions = {}

def init_python_db():
    with _db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS python_scripts (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre      TEXT NOT NULL,
            tipo        TEXT DEFAULT 'script',
            fecha       TEXT NOT NULL,
            timestamp   TEXT NOT NULL,
            codigo      TEXT,
            archivo     TEXT,
            analisis    TEXT,
            score       INTEGER DEFAULT 0,
            tags        TEXT DEFAULT '[]'
        );
        CREATE TABLE IF NOT EXISTS python_ejecuciones (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            script_id   INTEGER,
            fecha       TEXT NOT NULL,
            timestamp   TEXT NOT NULL,
            duracion_ms REAL DEFAULT 0,
            estado      TEXT DEFAULT 'pending',
            salida      TEXT,
            errores     TEXT,
            metricas    TEXT DEFAULT '{}',
            FOREIGN KEY (script_id) REFERENCES python_scripts(id)
        );
        CREATE TABLE IF NOT EXISTS python_analisis_historial (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo            TEXT NOT NULL,          -- 'archivo' | 'proyecto'
            nombre          TEXT NOT NULL,           -- nombre del proyecto (declarado) o del archivo
            origen          TEXT DEFAULT 'local',    -- 'local' | 'server'
            score           INTEGER DEFAULT 0,
            veredicto_nivel TEXT,                    -- 'requiere_ajustes' | 'observaciones' | 'ok'
            veredicto_label TEXT,
            aprobado        INTEGER DEFAULT 0,
            n_archivos      INTEGER DEFAULT 1,
            n_huerfanos     INTEGER DEFAULT 0,
            n_errores       INTEGER DEFAULT 0,
            n_avisos        INTEGER DEFAULT 0,
            resumen_json    TEXT,                    -- checks + hallazgos + veredicto completo (sin codigo fuente)
            usuario         TEXT,
            responsable_proyecto TEXT,               -- analista/desarrollador responsable del proyecto (declarado antes de analizar)
            parent_id       INTEGER,                 -- para filas tipo='archivo' generadas junto a una corrida de proyecto: id de esa corrida
            fecha           TEXT NOT NULL,
            timestamp       TEXT NOT NULL
        );
        """)

        cols_analisis = {r["name"] for r in conn.execute("PRAGMA table_info(python_analisis_historial)").fetchall()}
        if "responsable_proyecto" not in cols_analisis:
            conn.execute("ALTER TABLE python_analisis_historial ADD COLUMN responsable_proyecto TEXT")
        if "parent_id" not in cols_analisis:
            conn.execute("ALTER TABLE python_analisis_historial ADD COLUMN parent_id INTEGER")
        conn.commit()

init_python_db()


def _guardar_historial_analisis(tipo, nombre, resultado, origen="local", responsable_proyecto=None):
    """
    Guarda en la base un registro liviano del analisis (score + hallazgos +
    veredicto), SIN el codigo fuente — sirve como historial de buenas
    practicas para auditoria y para que el checklist de Deploy pueda
    consultar automaticamente si un proceso ya paso el analisis.
    responsable_proyecto: analista/desarrollador declarado como responsable
    del proyecto antes de analizarlo (se pide en el frontend al cargar
    carpeta/archivo local) — queda documentado para trazabilidad.
    Nunca debe romper la respuesta al usuario si falla: se llama con try/except afuera.
    """
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    usuario = session.get("nombre") or session.get("usuario") or "desconocido"
    responsable_proyecto = (responsable_proyecto or "").strip() or None

    if tipo == "proyecto":
        score = resultado.get("score", 0)
        veredicto = resultado.get("veredicto", {})
        n_errores = sum(1 for c in resultado.get("checks_estructura", []) if c.get("sev") == "ERROR")
        n_avisos = sum(1 for c in resultado.get("checks_estructura", []) if c.get("sev") == "AVISO")
        for info in resultado.get("archivos", {}).values():
            for c in info.get("buenas_practicas", []) or []:
                if c.get("sev") == "ERROR": n_errores += 1
                elif c.get("sev") == "AVISO": n_avisos += 1
        n_archivos = len(resultado.get("archivos", {}))
        n_huerfanos = len(resultado.get("huerfanos", []))
        resumen = {
            "checks_estructura": resultado.get("checks_estructura", []),
            "justificacion": resultado.get("justificacion", []),
            "vinculados": resultado.get("vinculados", []),
            "huerfanos": resultado.get("huerfanos", []),
            "archivos_scores": {k: v.get("score") for k, v in resultado.get("archivos", {}).items()},
        }
    else:
        score = resultado.get("score", 0)
        bps_archivo = resultado.get("buenas_practicas", [])
        veredicto = resultado.get("veredicto") or _veredicto(score, forzar_no_aprobado=_tiene_criticos_personalizados(bps_archivo))
        n_errores = sum(1 for c in bps_archivo if c.get("sev") == "ERROR")
        n_avisos = sum(1 for c in bps_archivo if c.get("sev") == "AVISO")
        n_archivos = 1
        n_huerfanos = 0
        resumen = {"buenas_practicas": bps_archivo, "ml_info": resultado.get("ml_info")}

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO python_analisis_historial
            (tipo, nombre, origen, score, veredicto_nivel, veredicto_label, aprobado,
             n_archivos, n_huerfanos, n_errores, n_avisos, resumen_json, usuario,
             responsable_proyecto, fecha, timestamp)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (tipo, nombre, origen, score, veredicto.get("nivel"), veredicto.get("label"),
              1 if veredicto.get("aprobado") else 0, n_archivos, n_huerfanos, n_errores, n_avisos,
              json.dumps(resumen, ensure_ascii=False), usuario, responsable_proyecto, ts[:10], ts))
        analisis_id = cur.lastrowid

        # Ademas de la fila resumen del proyecto, guardamos UNA fila por archivo
        # (tipo='archivo', enlazada via parent_id) para que las reglas que
        # escalan por repeticion (ej. BP-08) puedan encontrar el historial
        # de ESE archivo puntual, y para poder comparar hallazgos entre
        # corridas del mismo proyecto (resueltos / persisten / nuevos).
        if tipo == "proyecto":
            for rel, info in resultado.get("archivos", {}).items():
                bps = info.get("buenas_practicas", []) or []
                v_archivo = _veredicto(info.get("score", 0), forzar_no_aprobado=_tiene_criticos_personalizados(bps))
                n_err_a = sum(1 for c in bps if c.get("sev") == "ERROR")
                n_avi_a = sum(1 for c in bps if c.get("sev") == "AVISO")
                conn.execute("""
                    INSERT INTO python_analisis_historial
                    (tipo, nombre, origen, score, veredicto_nivel, veredicto_label, aprobado,
                     n_archivos, n_huerfanos, n_errores, n_avisos, resumen_json, usuario,
                     responsable_proyecto, parent_id, fecha, timestamp)
                    VALUES ('archivo',?,?,?,?,?,?,1,0,?,?,?,?,?,?,?,?)
                """, (rel, origen, info.get("score", 0), v_archivo.get("nivel"), v_archivo.get("label"),
                      1 if v_archivo.get("aprobado") else 0, n_err_a, n_avi_a,
                      json.dumps({"buenas_practicas": bps}, ensure_ascii=False), usuario, responsable_proyecto,
                      analisis_id, ts[:10], ts))
        conn.commit()
    return analisis_id


def _racha_regla(nombre, regla, n=2):
    """
    Cuenta cuantas de las ultimas n corridas (tipo='archivo') para este
    nombre de archivo tuvieron la regla dada en estado distinto de OK,
    de forma CONSECUTIVA desde la mas reciente hacia atras. Se corta
    apenas aparece una corrida donde la regla ya estaba OK (o no aparecia).
    Se usa para reglas que 'toleran' un par de incumplimientos antes de
    escalar a critico (ej. BP-08: se permite 2 veces, la 3ra ya es ERROR).
    """
    if not nombre:
        return 0
    try:
        with _db() as conn:
            rows = conn.execute("""
                SELECT resumen_json FROM python_analisis_historial
                WHERE tipo = 'archivo' AND nombre = ?
                ORDER BY id DESC LIMIT ?
            """, (nombre, n)).fetchall()
    except Exception:
        return 0

    racha = 0
    for r in rows:
        try:
            resumen = json.loads(r["resumen_json"])
            bps = resumen.get("buenas_practicas", [])
            encontrada = next((c for c in bps if c.get("regla") == regla), None)
            if encontrada and encontrada.get("sev") != "OK":
                racha += 1
            else:
                break
        except Exception:
            break
    return racha


def _linea_de_offset(codigo, offset):
    """Convierte una posicion de caracter (match.start()) al numero de linea (1-indexado)."""
    return codigo.count("\n", 0, offset) + 1


def _texto_lineas(codigo, numeros_linea, contexto=0):
    """
    Devuelve el texto REAL de una o mas lineas del archivo (1-indexado),
    para mostrar en el reporte el fragmento que efectivamente disparo el
    hallazgo — en vez de (o ademas de) el ejemplo generico de la regla.
    """
    lineas_archivo = codigo.splitlines()
    fragmentos = []
    for n in numeros_linea:
        ini = max(1, n - contexto)
        fin = min(len(lineas_archivo), n + contexto)
        for i in range(ini, fin + 1):
            if 1 <= i <= len(lineas_archivo):
                fragmentos.append(f"{i}: {lineas_archivo[i-1].rstrip()}")
    return "\n".join(fragmentos)


def _primeras_lineas_de_patron(codigo, pattern, flags=0, max_n=5):
    """Devuelve una lista de numeros de linea donde matchea el patron."""
    return [_linea_de_offset(codigo, m.start()) for m in list(re.finditer(pattern, codigo, flags))[:max_n]]


PRACTICA_INFO = {
    "BP-01": {"nombre": "Documentación de funciones (docstrings)",
              "por_que": "Un docstring le dice a cualquiera (incluido vos mismo en 6 meses) que hace la función sin tener que leer el código.",
              "impacto": "Sin esto, cada vez que alguien retoma el script pierde tiempo entendiendo la lógica desde cero, y aumenta el riesgo de romper algo al modificarlo.",
              "rec": "Agregar un docstring corto (que hace, parámetros, que retorna) a cada función pública.",
              "ejemplo": '# Mal:\ndef calcular_score(monto, plazo):\n    return monto * (1 + plazo * 0.01)\n\n# Bien:\ndef calcular_score(monto: float, plazo: int) -> float:\n    """Calcula el score de riesgo segun monto y plazo en meses."""\n    return monto * (1 + plazo * 0.01)'},
    "BP-02": {"nombre": "Sin credenciales hardcodeadas",
              "por_que": "Las credenciales en el código quedan expuestas a cualquiera que vea el archivo (repositorio, backup, capturas de pantalla, este mismo análisis).",
              "impacto": "Si se filtra el código, se filtra el acceso a la base o al sistema — es el tipo de hallazgo que más rápido debe corregirse.",
              "rec": "Mover la credencial a una variable de entorno (os.getenv) y cargarla con python-dotenv, nunca en el código.",
              "ejemplo": '# Mal:\npassword = "MiClave123"\nconn = oracledb.connect(user="dashboard", password=password, dsn=dsn)\n\n# Bien:\nimport os\nfrom dotenv import load_dotenv\nload_dotenv()\npassword = os.getenv("DB_PASSWORD")\nconn = oracledb.connect(user=os.getenv("DB_USER"), password=password, dsn=dsn)'},
    "BP-03": {"nombre": "Manejo de excepciones específico",
              "por_que": "Capturar la excepción exacta esperada permite saber qué falló realmente, en vez de esconder cualquier error bajo la alfombra.",
              "impacto": "Un 'except:' genérico puede ocultar errores graves (de conexión, de datos) que deberían frenar el proceso, y hace muy difícil depurar en producción.",
              "rec": "Reemplazar 'except:' por la excepción específica esperada (ej. except oracledb.DatabaseError as e) y loguear el motivo.",
              "ejemplo": '# Mal:\ntry:\n    conn = oracledb.connect(dsn=dsn)\nexcept:\n    pass\n\n# Bien:\ntry:\n    conn = oracledb.connect(dsn=dsn)\nexcept oracledb.DatabaseError as e:\n    logging.error(f"No se pudo conectar a Oracle: {e}")\n    raise'},
    "BP-04": {"nombre": "Logging en vez de print()",
              "por_que": "El logging permite niveles (info/warning/error), timestamps, y filtrar salida — print() no.",
              "impacto": "Con solo print(), en producción no hay forma de distinguir un mensaje informativo de un error real, ni de desactivar el ruido sin tocar el código.",
              "rec": "Reemplazar print() por el módulo logging, con niveles (info/warning/error) para poder filtrar en producción.",
              "ejemplo": '# Mal:\nprint("Iniciando proceso de scoring...")\n\n# Bien:\nimport logging\nlogging.basicConfig(level=logging.INFO)\nlogging.info("Iniciando proceso de scoring...")'},
    "BP-05": {"nombre": "Configuración por variable de entorno",
              "por_que": "Rutas, hosts y nombres de tabla cambian entre desarrollo/staging/producción — no deberían estar fijos en el código.",
              "impacto": "Sin esto, mover el script a otro ambiente requiere editar el código fuente cada vez, con riesgo de dejar apuntando al ambiente equivocado.",
              "rec": "Cargar configuración (rutas, hosts, tablas) desde variables de entorno con os.getenv, no hardcodeada.",
              "ejemplo": '# Mal:\nRUTA_ARCHIVO = "/pentaho/project/OGD/data/scoring.csv"\nHOST_DB = "10.1.1.2"\n\n# Bien:\nimport os\nfrom dotenv import load_dotenv\nload_dotenv()\nRUTA_ARCHIVO = os.getenv("RUTA_ARCHIVO")\nHOST_DB = os.getenv("DB_HOST")'},
    "BP-06": {"nombre": "Type hints en las funciones",
              "por_que": "Los type hints permiten que el editor y herramientas como mypy detecten errores de tipo antes de ejecutar.",
              "impacto": "Sin tipado, un error de tipo (ej. pasar un string donde se espera un número) recién se descubre en tiempo de ejecución, a veces en producción.",
              "rec": "Agregar type hints en la firma de las funciones (parámetros y retorno) para detectar errores antes de ejecutar.",
              "ejemplo": '# Mal:\ndef calcular_score(monto, plazo):\n    return monto * plazo\n\n# Bien:\ndef calcular_score(monto: float, plazo: int) -> float:\n    return monto * plazo'},
    "BP-07": {"nombre": "Tamaño del script",
              "por_que": "Un script corto y enfocado es más fácil de leer, testear y mantener que uno gigante con todo mezclado.",
              "impacto": "Scripts muy largos concentran demasiadas responsabilidades — un cambio en una parte puede romper otra sin que se note.",
              "rec": "Dividir el script en módulos más chicos (ej. preprocessing.py, scoring.py, utils.py) agrupados por responsabilidad."},
    "BP-08": {"nombre": "Longitud de línea razonable",
              "por_que": "Líneas cortas se leen de un vistazo y se comparan mejor en diffs de Git (lado a lado).",
              "impacto": "Líneas muy largas obligan a hacer scroll horizontal y dificultan ver qué cambió realmente en un code review.",
              "rec": "Cortar las líneas largas en varias, o extraer la expresión a una variable con nombre descriptivo.",
              "ejemplo": '# Mal:\nresultado = df[(df["monto"] > 1000) & (df["plazo"] > 12) & (df["estado"] == "activo") & (df["score"] > 0.5)]\n\n# Bien:\nfiltro_monto = df["monto"] > 1000\nfiltro_plazo = df["plazo"] > 12\nfiltro_estado = df["estado"] == "activo"\nfiltro_score = df["score"] > 0.5\nresultado = df[filtro_monto & filtro_plazo & filtro_estado & filtro_score]'},
    "BP-09": {"nombre": "Funciones de tamaño y firma razonables",
              "por_que": "Funciones chicas con pocos parámetros son más fáciles de entender, testear, y reusar.",
              "impacto": "Funciones gigantes o con muchos parámetros son difíciles de testear por partes, y cualquier cambio tiene más superficie para romper algo.",
              "rec": "Dividir la función en pasos más chicos, o agrupar los parámetros en un dict/dataclass de configuración.",
              "ejemplo": '# Mal:\ndef procesar_todo(a, b, c, d, e, f, g):\n    ...  # 100 lineas mezclando lectura, validacion y calculo\n\n# Bien:\ndef leer_datos(config: dict): ...\ndef validar_datos(df): ...\ndef calcular_score(df): ...\ndef procesar_todo(config: dict):\n    df = leer_datos(config)\n    df = validar_datos(df)\n    return calcular_score(df)'},
    "BP-10": {"nombre": "Sin argumentos mutables por defecto",
              "por_que": "En Python, una lista/dict como valor por defecto se crea UNA sola vez y se comparte entre todas las llamadas a la función.",
              "impacto": "Esto causa un bug clásico y muy difícil de detectar: datos de una ejecución anterior 'se filtran' a la siguiente llamada de la misma función.",
              "rec": "Cambiar el valor por defecto a None y crear la lista/dict/set adentro de la función (evita el bug de estado compartido).",
              "ejemplo": '# Mal (bug clasico: la lista se comparte entre llamadas):\ndef agregar_resultado(item, resultados=[]):\n    resultados.append(item)\n    return resultados\n\n# Bien:\ndef agregar_resultado(item, resultados=None):\n    if resultados is None:\n        resultados = []\n    resultados.append(item)\n    return resultados'},
    "BP-11": {"nombre": "Sin patrones de riesgo de seguridad (eval/exec/shell=True/pickle)",
              "por_que": "Estas funciones ejecutan código o datos arbitrarios — si el input viene de afuera (usuario, archivo, red), es una puerta de entrada para ejecutar código malicioso.",
              "impacto": "Es de los hallazgos más serios: puede permitir que alguien ejecute comandos en el servidor a través de un dato de entrada manipulado.",
              "rec": "Evitar eval/exec/shell=True/pickle.loads con datos no confiables; usar ast.literal_eval, listas de argumentos, o json.",
              "ejemplo": '# Mal:\nresultado = eval(formula_usuario)\nsubprocess.run(comando, shell=True)\n\n# Bien:\nimport ast\nresultado = ast.literal_eval(formula_usuario)  # solo literales, no codigo arbitrario\nsubprocess.run(["ls", "-la", ruta])  # lista de argumentos, sin shell=True'},
    "BP-12": {"nombre": "Consultas SQL sin interpolación directa",
              "por_que": "Armar el SQL con f-string mezcla el dato del usuario con la instrucción SQL — la base no puede distinguir uno de otro.",
              "impacto": "Es la puerta de entrada clásica para SQL injection: alguien podría leer, modificar o borrar datos que no debería poder tocar.",
              "rec": "Usar parámetros bind en la consulta (ej. cursor.execute(sql, {'p1': valor}) o %s), nunca interpolar valores en el string SQL.",
              "ejemplo": '# Mal:\ncursor.execute(f"SELECT * FROM clientes WHERE id = {id_cliente}")\n\n# Bien:\ncursor.execute("SELECT * FROM clientes WHERE id = :id_cliente", {"id_cliente": id_cliente})'},
    "BP-13": {"nombre": "Sin wildcard imports (import *)",
              "por_que": "Importar todo con '*' hace que no quede claro de qué módulo vino cada función o variable usada en el código.",
              "impacto": "Puede pisar nombres sin darse cuenta (dos módulos con una función del mismo nombre), y complica mucho el autocompletado y la lectura.",
              "rec": "Importar solo los nombres que se usan (from modulo import funcion_x) en vez de 'import *'.",
              "ejemplo": '# Mal:\nfrom pandas import *\n\n# Bien:\nfrom pandas import DataFrame, read_csv'},
    "BP-14": {"nombre": "Sin TODO/FIXME pendientes",
              "por_que": "Un TODO es una tarea que alguien reconoció como pendiente pero no resolvió — es deuda técnica documentada.",
              "impacto": "Si se acumulan sin seguimiento, terminan siendo lógica a medio hacer que llega a producción sin que nadie se acuerde por qué quedó así.",
              "rec": "Resolver los TODO/FIXME pendientes antes de pasar a producción, o crear una tarea de seguimiento explícita."},
    "BP-15": {"nombre": "Archivos cerrados con context manager",
              "por_que": "'with open(...)' garantiza que el archivo se cierre solo, incluso si el código de adentro lanza un error.",
              "impacto": "Sin 'with', un error a mitad de la lectura/escritura puede dejar el archivo abierto, bloqueado, o con datos a medio escribir.",
              "rec": "Usar 'with open(...) as f:' para que el archivo se cierre automáticamente aunque ocurra un error.",
              "ejemplo": '# Mal:\nf = open("resultado.csv")\ndata = f.read()\nf.close()  # si algo falla antes de esta linea, el archivo queda abierto\n\n# Bien:\nwith open("resultado.csv") as f:\n    data = f.read()  # se cierra solo, incluso si hay un error'},
    "BP-16": {"nombre": "Assert no usado como validación de negocio",
              "por_que": "Python puede correr con la bandera -O, que elimina TODOS los 'assert' del programa en tiempo de ejecución.",
              "impacto": "Si la única validación de una regla de negocio es un assert, corriendo con -O esa validación simplemente desaparece sin ningún aviso.",
              "rec": "Reemplazar los assert de validación de negocio por 'if not condicion: raise ValueError(...)'.",
              "ejemplo": '# Mal (se desactiva con python -O):\nassert monto > 0, "El monto debe ser positivo"\n\n# Bien:\nif monto <= 0:\n    raise ValueError("El monto debe ser positivo")'},
    "BP-17": {"nombre": "Convención de nombres PEP8",
              "por_que": "Un estilo de nombres consistente (snake_case, PascalCase) hace que cualquiera que conozca Python pueda leer el código sin fricción.",
              "impacto": "Nombres inconsistentes no rompen nada en ejecución, pero aumentan el esfuerzo mental de lectura y las chances de errores de tipeo al llamarlos.",
              "rec": "Renombrar siguiendo PEP8: funciones/variables en snake_case, clases en PascalCase."},
    "BP-18": {"nombre": "Archivo no vacío",
              "por_que": "Un archivo vinculado al proyecto debería tener contenido real — si está vacío, es una señal de que algo quedó incompleto.",
              "impacto": "Un archivo vacío puede romper el import de otros módulos, o indicar que una migración/entrega quedó a medio hacer.",
              "rec": "Completar el archivo con su contenido real, o eliminarlo del proyecto si ya no es necesario.",
              "ejemplo": '# Un __init__.py vacio es correcto (no necesita ejemplo).\n# Cualquier OTRO archivo vacio deberia tener contenido real, por ejemplo:\n"""utils.py — funciones auxiliares del pipeline de scoring."""\n\ndef normalizar(texto: str) -> str:\n    return texto.strip().lower()'},
    "BP-19": {"nombre": "Cierre explícito de conexiones a base de datos",
              "por_que": "Una conexión a Oracle que no se cierra queda consumiendo un slot/sesión en la base hasta que el proceso termina (o expira por timeout).",
              "impacto": "En scripts que corren seguido (ej. un job diario), las conexiones sin cerrar se acumulan y pueden agotar las conexiones disponibles en la base.",
              "rec": "Cerrar la conexión y el cursor explícitamente (conn.close(), cursor.close()), o usar 'with' si el driver lo soporta.",
              "ejemplo": '# Mal:\nconn = oracledb.connect(dsn=dsn)\ncursor = conn.cursor()\ncursor.execute(sql)\n# nunca se cierra conn ni cursor\n\n# Bien:\nwith oracledb.connect(dsn=dsn) as conn:\n    with conn.cursor() as cursor:\n        cursor.execute(sql)'},
    "BP-20": {"nombre": "Commit explícito en operaciones de escritura",
              "por_que": "Un INSERT/UPDATE/DELETE en Oracle no queda guardado hasta que se hace commit — sin eso, la transacción puede perderse.",
              "impacto": "Si el proceso termina (o hace rollback implícito) antes del commit, los datos que creías guardados nunca llegaron a la base.",
              "rec": "Agregar conn.commit() después de las operaciones de escritura, y conn.rollback() en el except correspondiente.",
              "ejemplo": '# Mal:\ncursor.execute("INSERT INTO scoring VALUES (:1, :2)", (id, score))\n# no hay commit\n\n# Bien:\ntry:\n    cursor.execute("INSERT INTO scoring VALUES (:1, :2)", (id, score))\n    conn.commit()\nexcept oracledb.DatabaseError:\n    conn.rollback()\n    raise'},
    "BP-21": {"nombre": "Punto de entrada explícito (if __name__ == '__main__')",
              "por_que": "Separar el código que se ejecuta al importar el módulo del código que se ejecuta al correrlo directamente evita efectos secundarios inesperados.",
              "impacto": "Sin esto, si alguien importa este archivo desde otro script (para reusar una función), el proceso completo se dispara solo, aunque no era la intención.",
              "rec": "Envolver la ejecución principal en 'if __name__ == \"__main__\":' y llamar a una función main().",
              "ejemplo": '# Mal:\ndef main():\n    ...\nmain()  # se ejecuta apenas se importa el archivo\n\n# Bien:\ndef main():\n    ...\n\nif __name__ == "__main__":\n    main()'},
    "BP-22": {"nombre": "Docstring de módulo al inicio del archivo",
              "por_que": "Un docstring al inicio del archivo explica de un vistazo qué hace ese script, sin tener que leer todo el código.",
              "impacto": "Sin esto, alguien que abre el archivo por primera vez no tiene ningún contexto inicial de para qué sirve.",
              "rec": "Agregar un docstring al inicio del archivo con el propósito del script, y opcionalmente autor/fecha.",
              "ejemplo": '# Mal:\nimport oracledb\nimport pandas as pd\n...\n\n# Bien:\n"""\nscoring.py — Pipeline de scoring de clientes preaprobados (PGS).\nBanco Continental - Gobierno de Datos.\n"""\nimport oracledb\nimport pandas as pd'},
    "ML-04": {"nombre": "Métricas de producción (resumen del resultado)",
              "por_que": "En producción no hay ground truth inmediato para accuracy/F1 — pero sí conviene registrar cuántos registros se procesaron, cuántos se aprobaron/rechazaron, y la distribución de scores del batch.",
              "impacto": "Sin un resumen de resultados, un cambio raro en el comportamiento del modelo o en los datos de entrada (ej. de golpe se rechaza el 90%) puede pasar desapercibido hasta que alguien se queja.",
              "rec": "Calcular y loguear un resumen del batch: total procesado, aprobados/rechazados, distribución de scores (value_counts, describe()).",
              "ejemplo": '# Mal:\npredicciones = modelo.predict(X_nuevo)\n# no se registra nada del resultado del batch\n\n# Bien:\npredicciones = modelo.predict(X_nuevo)\nresumen = {\n    "total_procesados": len(predicciones),\n    "aprobados": int((predicciones == 1).sum()),\n    "rechazados": int((predicciones == 0).sum()),\n}\nlogging.info(f"Resumen del batch: {resumen}")'},
    "ML-02": {"nombre": "Validación contra el modelo anterior antes de reemplazarlo",
              "por_que": "Antes de que un modelo nuevo reemplace al que ya está en producción, conviene comparar sus resultados contra el modelo/versión anterior (champion-challenger) para confirmar que no empeora.",
              "impacto": "Sin esta comparación, un modelo nuevo puede reemplazar al anterior en producción y dar peores resultados sin que nadie lo note hasta que ya generó daño (créditos mal aprobados, por ejemplo).",
              "rec": "Antes de poner en producción una versión nueva, correr ambas (anterior y nueva) sobre el mismo batch y comparar resultados/distribución antes de reemplazar.",
              "ejemplo": '# Mal:\nmodelo = joblib.load("modelo_v2.pkl")  # reemplaza directo al v1, sin comparar\n\n# Bien:\nmodelo_anterior = joblib.load("modelo_v1.pkl")\nmodelo_nuevo = joblib.load("modelo_v2.pkl")\npred_anterior = modelo_anterior.predict(df)\npred_nueva = modelo_nuevo.predict(df)\nlogging.info(f"Diferencia de aprobados: {(pred_nueva!=pred_anterior).sum()}")'},
    "ML-03": {"nombre": "Pipeline de preprocesamiento consistente en producción",
              "por_que": "El preprocesamiento (escalado, encoding) que se aplicó en entrenamiento tiene que aplicarse EXACTAMENTE igual en producción — un sklearn Pipeline serializado junto al modelo garantiza eso.",
              "impacto": "Si en producción el preprocesamiento se reimplementa a mano (en vez de reusar el Pipeline entrenado), es fácil que quede levemente distinto al de entrenamiento, y el modelo prediga mal sin ningún error visible.",
              "rec": "Cargar y usar el mismo Pipeline serializado en entrenamiento, en vez de reimplementar el preprocesamiento a mano en el script de producción.",
              "ejemplo": '# Mal: preprocesamiento reimplementado a mano en produccion\ndf["monto_norm"] = (df["monto"] - 1000) / 500  # numeros "magicos", puede no coincidir con el entrenamiento\n\n# Bien:\npipeline = joblib.load("pipeline_preprocesamiento.pkl")  # el mismo que se uso en entrenamiento\ndf_transformado = pipeline.transform(df)\npredicciones = modelo.predict(df_transformado)'},
    "ML-05": {"nombre": "Escalado de features (consistente con el entrenamiento)",
              "por_que": "Si el modelo se entrenó con features escalados, en producción hay que aplicar exactamente la misma transformación antes de predecir.",
              "impacto": "Si en producción no se escala igual que en entrenamiento, las predicciones salen mal aunque el modelo esté cargado correctamente.",
              "rec": "Cargar y aplicar el mismo scaler usado en entrenamiento (ej. scaler = joblib.load('scaler.pkl')) antes de llamar a predict()."},
    "ML-06": {"nombre": "Carga del modelo serializado",
              "por_que": "Un script de producción debe cargar un modelo ya entrenado (joblib/pickle), no entrenarlo de nuevo cada vez que corre.",
              "impacto": "Sin una carga clara del modelo serializado, no queda claro de dónde sale el modelo que se está usando para predecir en producción.",
              "rec": "Cargar el modelo con joblib.load(...) (o pickle.load) al inicio del script, apuntando a un archivo de modelo versionado.",
              "ejemplo": '# Mal: no queda claro de donde sale el modelo\nmodelo = CatBoostClassifier()\n\n# Bien:\nimport joblib\nmodelo = joblib.load("modelo_scoring_v1.pkl")\npredicciones = modelo.predict(X_nuevo)'},
    "ML-07": {"nombre": "Interpretabilidad (feature importance / SHAP)",
              "por_que": "Entender qué variables pesan más en la predicción ayuda a detectar sesgos y a explicar el modelo a negocio/auditoría.",
              "impacto": "Sin esto, el modelo es una \"caja negra\" — difícil de justificar ante un cuestionamiento regulatorio o de negocio.",
              "rec": "Agregar feature_importances_, SHAP, o permutation_importance para poder explicar las predicciones."},
    "ML-11": {"nombre": "Monitoreo de drift (PSI)",
              "por_que": "El PSI (Population Stability Index) mide si los datos de producción se alejaron de los datos con que se entrenó el modelo — un modelo puede degradarse silenciosamente si los datos cambian.",
              "impacto": "Sin niveles de warning y crítico bien definidos, un drift severo puede pasar desapercibido hasta que el modelo ya esté prediciendo mal en producción.",
              "rec": "Definir explícitamente dos umbrales de PSI: uno de warning (ej. > 0.1) y uno crítico (ej. > 0.25), con una acción distinta para cada nivel."},
    "ML-12": {"nombre": "Manejo de errores en la predicción",
              "por_que": "Un modelo puede fallar en producción por datos inesperados (una columna faltante, un tipo de dato distinto) — ese fallo no debería tirar abajo todo el proceso sin control.",
              "impacto": "Sin try/except alrededor de predict(), un solo registro problemático puede frenar el procesamiento de todo el batch, incluidos los registros que sí estaban bien.",
              "rec": "Envolver la predicción en try/except, loguear el registro que falló, y seguir procesando el resto del batch.",
              "ejemplo": '# Mal:\npredicciones = modelo.predict(X_nuevo)\n\n# Bien:\ntry:\n    predicciones = modelo.predict(X_nuevo)\nexcept Exception as e:\n    logging.error(f"Error al predecir el batch: {e}")\n    raise'},
    "ML-13": {"nombre": "Validación del esquema de entrada",
              "por_que": "El modelo espera columnas específicas, en un orden y tipo determinado — si los datos de entrada cambiaron (ej. una columna nueva de Oracle, un rename), predict() puede fallar o dar resultados incorrectos sin avisar.",
              "impacto": "Un cambio silencioso en el esquema de origen (agregar/quitar una columna) puede generar predicciones incorrectas que nadie detecta hasta que impacta al negocio.",
              "rec": "Validar explícitamente que las columnas esperadas estén presentes antes de llamar a predict() (ej. comparar contra una lista de columnas esperadas).",
              "ejemplo": '# Mal:\npredicciones = modelo.predict(df)\n\n# Bien:\nCOLUMNAS_ESPERADAS = ["monto", "plazo", "score_buro"]\nfaltantes = set(COLUMNAS_ESPERADAS) - set(df.columns)\nif faltantes:\n    raise ValueError(f"Faltan columnas esperadas: {faltantes}")\npredicciones = modelo.predict(df[COLUMNAS_ESPERADAS])'},
    "ML-14": {"nombre": "Manejo de valores nulos/faltantes",
              "por_que": "Muchos modelos (y el propio predict de sklearn/CatBoost) fallan o dan resultados raros si reciben valores nulos que el modelo no vio durante el entrenamiento.",
              "impacto": "Un solo registro con un campo nulo (ej. un dato que no llegó de Oracle) puede tirar error en todo el batch, o generar un score sin sentido para ese cliente.",
              "rec": "Revisar y manejar explícitamente los nulos antes de predecir (imputar, descartar el registro, o marcarlo para revisión manual).",
              "ejemplo": '# Mal:\npredicciones = modelo.predict(df)\n\n# Bien:\nnulos = df[COLUMNAS_ESPERADAS].isnull().any(axis=1)\nif nulos.any():\n    logging.warning(f"{nulos.sum()} registros con datos faltantes, se excluyen del batch")\n    df = df[~nulos]\npredicciones = modelo.predict(df)'},
    "ML-15": {"nombre": "Versión del modelo trazable",
              "por_que": "Si el modelo se actualiza con el tiempo, cada predicción debería poder rastrearse a qué versión del modelo la generó.",
              "impacto": "Sin esto, si una predicción vieja se cuestiona (ej. una auditoría, un reclamo), no hay forma de saber con certeza qué versión del modelo la produjo.",
              "rec": "Loguear o guardar junto a cada predicción la versión/nombre del archivo del modelo cargado.",
              "ejemplo": '# Mal:\nmodelo = joblib.load("modelo.pkl")\n\n# Bien:\nMODEL_VERSION = "modelo_scoring_v3.pkl"\nmodelo = joblib.load(MODEL_VERSION)\nlogging.info(f"Prediciendo con modelo version: {MODEL_VERSION}")'},
    "EP-01": {"nombre": "Documentación README",
              "por_que": "Es lo primero que alguien lee al abrir el proyecto — explica qué hace, cómo instalarlo y quién es responsable.",
              "impacto": "Sin README, cada persona nueva (o vos mismo meses después) tiene que reconstruir ese contexto leyendo todo el código.",
              "rec": "Agregar un README.md con: qué hace el proyecto, cómo instalarlo, cómo correrlo, y a quién pertenece."},
    "EP-02": {"nombre": "Dependencias declaradas",
              "por_que": "Un requirements.txt/pyproject.toml deja registrado exactamente qué librerías (y versiones) necesita el proyecto para correr.",
              "impacto": "Sin esto, instalar el proyecto en otra máquina o servidor se vuelve prueba y error, y puede fallar por versiones distintas de librerías.",
              "rec": "Agregar un requirements.txt (pip freeze > requirements.txt) o un pyproject.toml con las dependencias exactas."},
    "EP-03": {"nombre": "Tests automatizados",
              "por_que": "Los tests detectan si un cambio rompió algo que ya funcionaba, antes de que llegue a producción.",
              "impacto": "Sin tests, cada cambio se valida \"a ojo\" — el riesgo de reintroducir un bug ya corregido antes es mucho más alto.",
              "rec": "Agregar al menos un test por módulo crítico (carpeta tests/ con pytest), especialmente para las funciones de scoring/validación."},
    "EP-04": {"nombre": "Modularidad del proyecto",
              "por_que": "Separar el código en módulos por responsabilidad hace que cada pieza se pueda entender, testear y reusar por separado.",
              "impacto": "Un proyecto con todo en un solo archivo es más difícil de mantener entre varias personas y más propenso a conflictos de edición.",
              "rec": "Separar el código en módulos por responsabilidad (data, preprocessing, model, utils) en vez de un único script."},
    "EP-05": {"nombre": "Sin archivos huérfanos",
              "por_que": "Todo archivo del proyecto debería estar conectado al flujo principal (importado desde main) o ser claramente un test/utilidad aparte.",
              "impacto": "Archivos huérfanos generan dudas: ¿se puede borrar? ¿falta conectarlo? — y ensucian el análisis de dependencias reales del proyecto.",
              "rec": "Revisar si esos archivos huérfanos son necesarios; si no, eliminarlos, o importarlos desde el main si son parte del flujo."},
    "EP-06": {"nombre": "Convención de nombres de archivo",
              "por_que": "Nombres de archivo consistentes (snake_case) hacen que el proyecto se sienta uniforme y profesional.",
              "impacto": "No afecta la ejecución, pero la inconsistencia visual dificulta encontrar archivos y sugiere falta de estándares en el equipo.",
              "rec": "Renombrar los archivos a snake_case, sin espacios ni mayúsculas, para consistencia en todo el proyecto."},
    "EP-07": {"nombre": "Sin credenciales repetidas en el proyecto",
              "por_que": "Centralizar credenciales en un solo lugar (.env) evita tener el mismo secreto duplicado en varios archivos.",
              "impacto": "Credenciales repetidas en múltiples archivos multiplican los lugares donde puede filtrarse, y complican rotarlas cuando hay que cambiarlas.",
              "rec": "Centralizar todas las credenciales en un único .env cargado con python-dotenv, y quitarlas del código fuente."},
    "EP-08": {"nombre": "Control de versiones (.gitignore)",
              "por_que": "Un .gitignore evita que archivos sensibles o generados automáticamente terminen versionados en el repositorio.",
              "impacto": "Sin él, es fácil subir por error el .env con credenciales, o ensuciar el repo con archivos temporales/__pycache__.",
              "rec": "Agregar un .gitignore que excluya .env, __pycache__, *.pyc y archivos de datos sensibles del control de versiones."},
    "EP-09": {"nombre": "Estructura de proyecto MLOps",
              "por_que": "Seguir siempre la misma estructura de carpetas hace que cualquiera del equipo pueda entrar a un proyecto nuevo y saber dónde está cada cosa, sin tener que preguntar.",
              "impacto": "Un proyecto con estructura distinta a la convención acordada complica el pase a producción, la revisión de código y el mantenimiento futuro por otra persona del equipo.",
              "rec": "Reorganizar el proyecto según la convención MLOps definida (carpetas config/, src/, scripts/, data/, models/, y archivos requirements.txt/README.md). La lista exacta es editable en Python & ML → Reglas."},
}


REGLAS_PERSONALIZADAS_CRITICAS = {"BP-01", "BP-03", "BP-08", "BP-18", "ML-04", "ML-11"}


def _cargar_reglas_config():
    """Trae todas las reglas configuradas (builtin overrides, custom, estructura)."""
    with _db() as conn:
        filas = conn.execute("SELECT * FROM analizador_reglas ORDER BY codigo").fetchall()
    return [dict(f) for f in filas]


def _reglas_por_codigo():
    """dict {codigo: fila} para lookup rapido de overrides al analizar."""
    return {r["codigo"]: r for r in _cargar_reglas_config()}


_DELTA_APROX_SEVERIDAD = {"ERROR": 15, "AVISO": 5, "OK": 0}


def _aplicar_overrides(checks, reglas=None):
    """
    Aplica, sobre una lista de checks ya generados:
      - activa=0  -> se descarta el check por completo, y se le devuelve al
        score los puntos que esa regla le había restado (aproximado por
        severidad: ERROR=15, AVISO=5 — el analizador tiene mas de 40 reglas
        con pesos puntuales distintos, así que esto es una aproximación
        razonable, no un revert exacto del descuento original)
      - severidad_override -> reemplaza la severidad, y ajusta el score por
        la diferencia entre el peso aproximado de la severidad vieja y la nueva
    Devuelve (checks_resultantes, ajuste_de_score).
    """
    reglas = reglas if reglas is not None else _reglas_por_codigo()
    if not reglas:
        return checks, 0
    resultado = []
    ajuste = 0
    for c in checks:
        cfg = reglas.get(c.get("regla"))
        if cfg and cfg["tipo"] == "builtin":
            if not cfg["activa"]:
                ajuste += _DELTA_APROX_SEVERIDAD.get(c.get("sev"), 0)
                continue
            # Un override de severidad SOLO aplica a un hallazgo real (ERROR/AVISO).
            # Nunca convierte un check que CUMPLE (OK) en un problema: forzar
            # "ERROR" sobre una regla que pasó no tiene sentido y era la causa de
            # que reglas como BP-03 aparecieran como CRÍTICO diciendo "correcto".
            if (cfg.get("severidad_override")
                    and cfg["severidad_override"] != c.get("sev")
                    and c.get("sev") in ("ERROR", "AVISO")):
                ajuste += (_DELTA_APROX_SEVERIDAD.get(c.get("sev"), 0) -
                           _DELTA_APROX_SEVERIDAD.get(cfg["severidad_override"], 0))
                c["sev"] = cfg["severidad_override"]
        resultado.append(c)
    return resultado, ajuste


def _ejecutar_reglas_custom(codigo, reglas=None):
    """Corre las reglas 100% definidas por el usuario (regex propio) sobre el código."""
    reglas = reglas if reglas is not None else _reglas_por_codigo()
    checks = []
    for r in reglas.values():
        if r["tipo"] != "custom" or not r["activa"] or not r.get("patron_regex"):
            continue
        try:
            m = re.search(r["patron_regex"], codigo, re.IGNORECASE)
        except re.error:
            continue
        if m:
            num_linea = _linea_de_offset(codigo, m.start())
            checks.append({
                "sev": r.get("severidad_custom") or "AVISO",
                "regla": r["codigo"],
                "msg": r.get("mensaje") or f"Coincide con la regla personalizada {r['codigo']}",
                "lineas": [num_linea],
                "codigo_real": _texto_lineas(codigo, [num_linea], contexto=1),
                "nombre": r.get("nombre") or r["codigo"],
            })
    return checks


def _reglas_completas():
    """
    Todas las reglas builtin conocidas por el analizador (42 reglas: BP-XX,
    ML-XX, EP-XX), existan o no todavía en la base — más las reglas
    'estructura' y 'custom' que sí viven en la base. Antes solo se listaban
    las reglas que alguien ya había tocado alguna vez.
    """
    filas_db = {r["codigo"]: r for r in _cargar_reglas_config()}
    resultado = []
    for codigo, info in PRACTICA_INFO.items():
        if codigo == "EP-09":
            continue  # va aparte: es tipo 'estructura', siempre viene sembrada en la base
        if codigo in filas_db:
            resultado.append(filas_db[codigo])
        else:
            resultado.append({
                "id": None, "codigo": codigo, "tipo": "builtin", "nombre": info.get("nombre", codigo),
                "activa": 1, "severidad_override": None, "patron_regex": None, "mensaje": None,
                "severidad_custom": None, "valor_config": None, "creado_por": None, "fecha": None,
            })
    for codigo, fila in filas_db.items():
        if fila["tipo"] in ("estructura", "custom"):
            resultado.append(fila)
    resultado.sort(key=lambda r: r["codigo"])
    return resultado


@app.route("/api/python/reglas/por_codigo/<codigo>", methods=["PUT"])
@login_required
def api_reglas_editar_por_codigo(codigo):
    """
    Igual que PUT /api/python/reglas/<id>, pero para reglas builtin que
    TODAVÍA no tienen fila propia en la base (se crea recién ahora, la
    primera vez que se tocan — antes de eso ni existían como fila).
    """
    data = request.get_json(force=True) or {}
    with _db() as conn:
        fila = conn.execute("SELECT * FROM analizador_reglas WHERE codigo=?", (codigo,)).fetchone()
        if not fila:
            info = PRACTICA_INFO.get(codigo)
            if not info:
                return jsonify({"ok": False, "error": f"Código de regla desconocido: {codigo}"}), 404
            conn.execute("""
                INSERT INTO analizador_reglas (codigo, tipo, nombre, activa, fecha)
                VALUES (?, 'builtin', ?, 1, ?)
            """, (codigo, info.get("nombre", codigo), datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            conn.commit()
            fila = conn.execute("SELECT * FROM analizador_reglas WHERE codigo=?", (codigo,)).fetchone()
        rid = fila["id"]

    return api_reglas_editar(rid)


@app.route("/api/python/reglas", methods=["GET"])
@login_required
def api_reglas_listar():
    return jsonify({"ok": True, "reglas": _reglas_completas()})


@app.route("/api/python/reglas", methods=["POST"])
@login_required
def api_reglas_crear():
    """Crea una regla CUSTOM 100% nueva, con su propio regex y severidad."""
    data = request.get_json(force=True) or {}
    codigo = (data.get("codigo") or "").strip().upper()
    if not codigo:
        return jsonify({"ok": False, "error": "Falta el código de la regla (ej. CUSTOM-01)"}), 400
    if not (data.get("patron_regex") or "").strip():
        return jsonify({"ok": False, "error": "Falta el patrón (regex) a buscar"}), 400
    try:
        re.compile(data["patron_regex"])
    except re.error as e:
        return jsonify({"ok": False, "error": f"El patrón no es un regex válido: {e}"}), 400

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with _db() as conn:
            conn.execute("""
                INSERT INTO analizador_reglas
                (codigo, tipo, nombre, activa, patron_regex, mensaje, severidad_custom, creado_por, fecha)
                VALUES (?, 'custom', ?, 1, ?, ?, ?, ?, ?)
            """, (codigo, (data.get("nombre") or codigo).strip(), data["patron_regex"].strip(),
                  (data.get("mensaje") or "").strip(),
                  data.get("severidad_custom") if data.get("severidad_custom") in ("AVISO", "ERROR") else "AVISO",
                  session.get("usuario", "desconocido"), ts))
            conn.commit()
    except sqlite3.IntegrityError:
        return jsonify({"ok": False, "error": f"Ya existe una regla con el código {codigo}"}), 400
    return jsonify({"ok": True})


@app.route("/api/python/reglas/<int:rid>", methods=["PUT"])
@login_required
def api_reglas_editar(rid):
    """
    Edita una regla existente:
      - builtin: se puede activar/desactivar y forzar severidad_override
      - custom:  ademas se puede editar el regex, mensaje y severidad_custom
    """
    data = request.get_json(force=True) or {}
    with _db() as conn:
        fila = conn.execute("SELECT * FROM analizador_reglas WHERE id=?", (rid,)).fetchone()
        if not fila:
            return jsonify({"ok": False, "error": "Regla no encontrada"}), 404
        fila = dict(fila)

        campos, valores = [], []
        if "activa" in data:
            campos.append("activa=?"); valores.append(int(bool(data["activa"])))
        if "severidad_override" in data:
            val = data["severidad_override"] or None
            if val not in (None, "OK", "AVISO", "ERROR"):
                return jsonify({"ok": False, "error": "severidad_override debe ser OK, AVISO, ERROR o vacío"}), 400
            campos.append("severidad_override=?"); valores.append(val)

        if fila["tipo"] == "custom":
            if "patron_regex" in data:
                try:
                    re.compile(data["patron_regex"])
                except re.error as e:
                    return jsonify({"ok": False, "error": f"Regex inválido: {e}"}), 400
                campos.append("patron_regex=?"); valores.append(data["patron_regex"])
            if "mensaje" in data:
                campos.append("mensaje=?"); valores.append(data["mensaje"])
            if "severidad_custom" in data and data["severidad_custom"] in ("AVISO", "ERROR"):
                campos.append("severidad_custom=?"); valores.append(data["severidad_custom"])
            if "nombre" in data:
                campos.append("nombre=?"); valores.append(data["nombre"])

        if fila["tipo"] == "estructura" and "valor_config" in data:
            try:
                json.loads(data["valor_config"]) if isinstance(data["valor_config"], str) else data["valor_config"]
            except Exception:
                return jsonify({"ok": False, "error": "valor_config debe ser JSON válido"}), 400
            valor = data["valor_config"] if isinstance(data["valor_config"], str) else json.dumps(data["valor_config"], ensure_ascii=False)
            campos.append("valor_config=?"); valores.append(valor)

        if not campos:
            return jsonify({"ok": False, "error": "Nada para actualizar"}), 400

        valores.append(rid)
        conn.execute(f"UPDATE analizador_reglas SET {', '.join(campos)} WHERE id=?", valores)
        conn.commit()
    return jsonify({"ok": True})


@app.route("/api/python/reglas/<int:rid>", methods=["DELETE"])
@login_required
def api_reglas_eliminar(rid):
    """
    Elimina una regla:
      - custom: se borra completamente
      - builtin/estructura: no se pueden borrar (son parte del analizador),
        pero se puede desactivar via PUT {"activa": false}
    """
    with _db() as conn:
        fila = conn.execute("SELECT tipo FROM analizador_reglas WHERE id=?", (rid,)).fetchone()
        if not fila:
            return jsonify({"ok": False, "error": "Regla no encontrada"}), 404
        if fila["tipo"] != "custom":
            return jsonify({"ok": False, "error": "Las reglas propias del analizador no se pueden eliminar, "
                                                    "solo desactivar (PUT con activa=false)."}), 400
        conn.execute("DELETE FROM analizador_reglas WHERE id=?", (rid,))
        conn.commit()
    return jsonify({"ok": True})


def _con_recomendacion(check):
    """
    Enriquece un check con informacion educativa, tenga o no problema:
    - 'nombre': nombre legible de la practica
    - 'por_que': por que esta practica es buena (se muestra siempre)
    - 'impacto': que pasa si no se cumple (se muestra siempre)
    - 'rec':     que hacer para arreglarlo (solo si el check NO esta OK)
    - 'critico_personalizado': True si es una de las reglas con logica
       de escalado/critico pedida especificamente (BP-01, BP-03, BP-08,
       BP-18, ML-11) y ademas esta en estado ERROR ahora mismo.
    """
    info = PRACTICA_INFO.get(check.get("regla"))
    if check.get("regla") in REGLAS_PERSONALIZADAS_CRITICAS and check.get("sev") == "ERROR":
        check["critico_personalizado"] = True
    if info:
        check["nombre"] = info["nombre"]
        check["por_que"] = info["por_que"]
        check["impacto"] = info["impacto"]
        if check.get("sev") in ("ERROR", "AVISO"):
            check["rec"] = info["rec"]
            if info.get("ejemplo"):
                check["ejemplo"] = info["ejemplo"]
    return check





def analizar_python(codigo, nombre=None):
    """Analiza un script Python para buenas prácticas y patrones ML.
    'nombre' es opcional — si se pasa, permite consultar el historial para
    reglas que escalan con la repetición (ej. BP-08 despues de 3 corridas seguidas)."""
    resultado = {
        "tipo": "script",
        "imports": [],
        "funciones": [],
        "clases": [],
        "buenas_practicas": [],
        "problemas": [],
        "ml_info": None,
        "score": 0,
        "lineas": len(codigo.splitlines()),
        "tags": [],
    }

    # ¿Es un archivo de test? (tests/, test_*.py, *_test.py, conftest.py)
    # Los tests tienen convenciones propias: credenciales ficticias, asserts y
    # docstrings opcionales son CORRECTOS en un test. No se les aplican las reglas
    # pensadas para código de producción (BP-02, BP-16, BP-01 laxo), y no bloquean
    # el pase porque los tests no van a producción.
    _base_nom = os.path.basename(nombre) if nombre else ""
    _ruta_low = (nombre or "").replace("\\", "/").lower()
    _es_test = bool(nombre) and (
        _base_nom.startswith("test_") or _base_nom.endswith("_test.py")
        or _base_nom == "conftest.py" or "/tests/" in _ruta_low
        or _ruta_low.startswith("tests/")
    )
    if _es_test:
        resultado["tags"].append("Test")
    # BP-18: archivo vacio — criterio critico, EXCEPTO __init__.py
    # (un __init__.py vacio es idiomatico en Python: marca la carpeta como paquete)
    if not codigo.strip():
        es_init = nombre and os.path.basename(nombre) == "__init__.py"
        if es_init:
            check_init = _con_recomendacion({
                "sev": "OK", "regla": "BP-18",
                "msg": "__init__.py vacío — normal, define el paquete Python de la carpeta"
            })
            resultado["buenas_practicas"] = [check_init]
            resultado["score"] = 100
            resultado["tags"] = ["Paquete"]
            resultado["veredicto"] = _veredicto(100)
            return resultado
        check_vacio = _con_recomendacion({"sev": "ERROR", "regla": "BP-18", "msg": "Archivo vacío — sin contenido"})
        resultado["buenas_practicas"] = [check_vacio]
        resultado["score"] = 0
        resultado["tags"] = ["Vacío"]
        resultado["veredicto"] = _veredicto(0, forzar_no_aprobado=True)
        return resultado

    # Parse AST
    try:
        tree = pyast.parse(codigo)
    except SyntaxError as e:
        resultado["problemas"].append({
            "sev": "ERROR", "regla": "SYN-01",
            "msg": f"Error de sintaxis línea {e.lineno}: {e.msg}",
        })
        resultado["score"] = 0
        return resultado

    # Collect imports, functions, classes
    imports_set = set()
    funciones = []
    clases = []
    for node in pyast.walk(tree):
        if isinstance(node, pyast.Import):
            for n in node.names:
                imports_set.add(n.name.split(".")[0])
        elif isinstance(node, pyast.ImportFrom):
            if node.module:
                imports_set.add(node.module.split(".")[0])
        elif isinstance(node, (pyast.FunctionDef, pyast.AsyncFunctionDef)):
            has_doc = (isinstance(node.body[0], pyast.Expr) and
                       isinstance(node.body[0].value, (pyast.Constant, pyast.Str))
                       if node.body else False)
            funciones.append({
                "nombre": node.name,
                "args": len(node.args.args),
                "linea": node.lineno,
                "tiene_docstring": has_doc,
                "decoradores": [d.id if isinstance(d, pyast.Name) else
                               getattr(d, 'attr', '?') for d in node.decorator_list],
            })
        elif isinstance(node, pyast.ClassDef):
            clases.append({"nombre": node.name, "linea": node.lineno})

    resultado["imports"] = sorted(imports_set)
    resultado["funciones"] = funciones
    resultado["clases"] = clases

    # ── Detect ML type ──
    ml_libs = {"sklearn", "xgboost", "lightgbm", "catboost", "tensorflow",
               "keras", "torch", "pytorch", "statsmodels", "prophet"}
    data_libs = {"pandas", "numpy", "scipy", "polars"}
    found_ml = ml_libs & imports_set
    found_data = data_libs & imports_set

    if found_ml:
        resultado["tipo"] = "ml_model"
        resultado["tags"].append("ML")
        resultado["ml_info"] = {
            "frameworks": sorted(found_ml),
            "data_libs": sorted(found_data),
            "tiene_train_test_split": "train_test_split" in codigo,
            "tiene_cross_validation": any(k in codigo for k in ["cross_val_score", "cross_validate", "KFold", "StratifiedKFold"]),
            "tiene_pipeline": "Pipeline" in codigo,
            "tiene_grid_search": any(k in codigo for k in ["GridSearchCV", "RandomizedSearchCV", "BayesSearchCV"]),
            "tiene_metricas": any(k in codigo for k in ["accuracy_score", "f1_score", "roc_auc", "mean_squared_error",
                                                         "classification_report", "confusion_matrix", "r2_score"]),
            "tiene_pickle_joblib": any(k in codigo for k in ["joblib", "pickle", "save_model", "dump("]),
            "tiene_feature_importance": any(k in codigo for k in ["feature_importances_", "shap", "SHAP", "permutation_importance"]),
            "tiene_logging": "logging" in imports_set or "logger" in codigo.lower(),
            "tiene_mlflow": "mlflow" in imports_set,
            "tiene_early_stopping": "early_stopping" in codigo.lower(),
            "tiene_scaler": any(k in codigo for k in ["StandardScaler", "MinMaxScaler", "RobustScaler", "normalize"]),
        }
        for fw in found_ml:
            resultado["tags"].append(fw)
    elif found_data:
        resultado["tipo"] = "data_processing"
        resultado["tags"].append("Data")

    if "cx_Oracle" in imports_set or "oracledb" in imports_set:
        resultado["tags"].append("Oracle")
    if "flask" in imports_set or "Flask" in codigo:
        resultado["tags"].append("Flask")
    if "airflow" in imports_set:
        resultado["tags"].append("Airflow")

    # ── Best practices checks ──
    score = 100
    checks = []

    # BP-01: Docstrings (umbral subido a 85% para considerarse Cumple)
    fns_sin_doc_info = [f for f in funciones if not f["tiene_docstring"]]
    fns_sin_doc = [f"{f['nombre']} (L{f['linea']})" for f in fns_sin_doc_info]
    lineas_bp01 = [f["linea"] for f in fns_sin_doc_info[:8]]
    if funciones and _es_test:
        pct = len([f for f in funciones if f["tiene_docstring"]]) / len(funciones) * 100
        checks.append({"sev": "OK", "regla": "BP-01",
                       "msg": f"Docstrings: {pct:.0f}% (archivo de test — el nombre del test documenta el caso)"})
    elif funciones:
        pct = len([f for f in funciones if f["tiene_docstring"]]) / len(funciones) * 100
        if pct >= 85:
            checks.append({"sev": "OK", "regla": "BP-01", "msg": f"Docstrings: {pct:.0f}% de funciones documentadas"})
        elif pct >= 40:
            checks.append({"sev": "AVISO", "regla": "BP-01", "msg": f"Docstrings: solo {pct:.0f}% documentadas (mínimo exigido: 85%)", "det": ", ".join(fns_sin_doc[:5]), "lineas": lineas_bp01})
            score -= 10
        else:
            checks.append({"sev": "ERROR", "regla": "BP-01", "msg": f"Docstrings: {pct:.0f}% — falta documentación (mínimo exigido: 85%)", "det": ", ".join(fns_sin_doc[:5]), "lineas": lineas_bp01})
            score -= 20

    # BP-02: Hardcoded credentials
    # En tests, valores como user="test_user"/password="clave" son ficticios para
    # mocks, no credenciales reales — no se marcan.
    cred_patterns = [
        (r'(?:password|passwd|pwd)\s*=\s*["\'][^"\']+["\']', "password hardcoded"),
        (r'(?:user|usuario)\s*=\s*["\'][^"\']+["\']', "usuario hardcoded"),
        (r'\b(?:10\.\d+\.\d+\.\d+)\b', "IP privada hardcoded"),
    ]
    if _es_test:
        checks.append({"sev": "OK", "regla": "BP-02",
                       "msg": "Sin credenciales reales (archivo de test — valores ficticios para mocks)"})
    for pat, desc in ([] if _es_test else cred_patterns):
        m = re.search(pat, codigo, re.IGNORECASE)
        if m:
            linea = _linea_de_offset(codigo, m.start())
            checks.append({"sev": "ERROR", "regla": "BP-02", "msg": f"Credencial: {desc}", "lineas": [linea]})
            score -= 15

    # BP-03: Exception handling — 'except:' generico es siempre CRITICO (no aviso)
    lineas_except = _primeras_lineas_de_patron(codigo, r'except\s*:')
    bare_except = len(lineas_except)
    if bare_except > 0:
        checks.append({"sev": "ERROR", "regla": "BP-03",
                        "msg": f"except: genérico ({bare_except} ocurrencias) — capturar excepciones específicas",
                        "lineas": lineas_except})
        score -= 15 * min(bare_except, 4)
    else:
        checks.append({"sev": "OK", "regla": "BP-03", "msg": "Manejo de excepciones correcto"})

    # BP-04: Logging
    has_logging = "logging" in imports_set or "logger" in codigo.lower()
    has_print = len(re.findall(r'\bprint\s*\(', codigo))
    if has_logging:
        checks.append({"sev": "OK", "regla": "BP-04", "msg": "Usa logging estructurado"})
    elif has_print > 5:
        checks.append({"sev": "AVISO", "regla": "BP-04", "msg": f"{has_print} print() — considerar logging module"})
        score -= 10
    elif has_print > 0:
        checks.append({"sev": "OK", "regla": "BP-04", "msg": f"{has_print} print() detectados"})

    # BP-05: Configuración centralizada (credenciales en .env, datos sensibles en config.yaml)
    #
    # Criterio (definido por Gobierno de Datos): las credenciales van en .env y
    # los datos que deben ocultarse (tablas, esquemas, rutas) en config.yaml. Un
    # módulo que RECIBE esa configuración (parámetro `cfg`/`config`, o importa el
    # cargador/clase Config) NO tiene que volver a leer el entorno — es la
    # arquitectura correcta. Solo se marca si el archivo tiene rutas/hosts/tablas
    # HARDCODEADAS sin pasar por esa configuración centralizada.
    has_env = "os.environ" in codigo or "os.getenv" in codigo or "dotenv" in codigo
    delega_configuracion = bool(re.search(
        r'\bimport\b[^\n]*\b(cargar_configuracion|load_config|get_config|Config)\b', codigo))
    # ¿Recibe la config como parámetro? (cfg: Config, config, def x(..., cfg, ...))
    recibe_config_param = bool(re.search(
        r'def\s+\w+\s*\([^)]*\b(cfg|config|conf|settings)\b', codigo)) or \
        bool(re.search(r'\b(cfg|config)\.\w+', codigo))
    # ¿Tiene rutas/hosts/tablas hardcodeadas? (lo único que sí es un problema)
    m_hardcode = re.search(
        r'=\s*["\'](/[\w./-]+|[0-9]{1,3}(\.[0-9]{1,3}){3}|[A-Z_]+\.[A-Z_]+)["\']', codigo)
    tiene_hardcode_sensible = bool(m_hardcode)

    if has_env:
        checks.append({"sev": "OK", "regla": "BP-05", "msg": "Carga configuración desde variables de entorno (.env)"})
    elif delega_configuracion or recibe_config_param:
        checks.append({"sev": "OK", "regla": "BP-05",
                        "msg": "Recibe la configuración centralizada (cfg/Config) — no lee el entorno "
                               "directamente, que es lo correcto: credenciales en .env y tablas/rutas en config.yaml."})
    elif tiene_hardcode_sensible:
        ln_hc = _linea_de_offset(codigo, m_hardcode.start())
        checks.append({"sev": "AVISO", "regla": "BP-05",
                        "msg": "Hay rutas/hosts/tablas que parecen hardcodeadas — moverlas a config.yaml "
                               "(datos de tablas/esquemas) o .env (credenciales).",
                        "lineas": [ln_hc],
                        "codigo_real": _texto_lineas(codigo, [ln_hc], contexto=1)})
        score -= 5
    else:
        # No lee entorno, no recibe cfg, pero tampoco hardcodea nada sensible: informativo, no penaliza.
        checks.append({"sev": "OK", "regla": "BP-05",
                        "msg": "No maneja configuración sensible en este archivo."})

    # BP-06: Type hints
    typed_funcs = sum(1 for f in funciones
                      if any(True for node in pyast.walk(tree)
                             if isinstance(node, (pyast.FunctionDef, pyast.AsyncFunctionDef))
                             and node.name == f["nombre"] and node.returns))
    if funciones:
        pct_typed = typed_funcs / len(funciones) * 100
        if pct_typed >= 50:
            checks.append({"sev": "OK", "regla": "BP-06", "msg": f"Type hints: {pct_typed:.0f}% de funciones tipadas"})
        else:
            checks.append({"sev": "AVISO", "regla": "BP-06", "msg": f"Type hints: solo {pct_typed:.0f}% — mejorar tipado"})
            score -= 5

    # BP-07: Code length
    n_lines = len(codigo.splitlines())
    if n_lines > 500:
        checks.append({"sev": "AVISO", "regla": "BP-07", "msg": f"Script largo: {n_lines} líneas — considerar modularizar"})
        score -= 10
    elif n_lines > 200:
        checks.append({"sev": "OK", "regla": "BP-07", "msg": f"Tamaño: {n_lines} líneas"})
    else:
        checks.append({"sev": "OK", "regla": "BP-07", "msg": f"Script compacto: {n_lines} líneas"})

    # BP-08: Lineas demasiado largas (PEP8 sugiere <=79-99 caracteres)
    # Regla de tolerancia: se permite esta situacion 2 corridas seguidas (aviso);
    # si en la 3ra corrida consecutiva sigue igual, escala a critico.
    lineas_largas = [i+1 for i, l in enumerate(codigo.splitlines()) if len(l) > 120]
    if lineas_largas:
        racha_bp08 = _racha_regla(nombre, "BP-08", n=2)
        if racha_bp08 >= 2:
            checks.append({"sev": "ERROR", "regla": "BP-08",
                            "msg": f"{len(lineas_largas)} línea(s) superan 120 caracteres — persiste hace 3 análisis consecutivos, ya no se tolera",
                            "det": ", ".join(f"L{n}" for n in lineas_largas[:8]), "lineas": lineas_largas[:8]})
            score -= 15
        else:
            checks.append({"sev": "AVISO", "regla": "BP-08",
                            "msg": f"{len(lineas_largas)} línea(s) superan 120 caracteres — dificulta lectura/diffs (tolerado hasta 2 análisis seguidos)",
                            "det": ", ".join(f"L{n}" for n in lineas_largas[:8]), "lineas": lineas_largas[:8]})
            score -= min(len(lineas_largas), 5)
    else:
        checks.append({"sev": "OK", "regla": "BP-08", "msg": "Longitud de línea razonable en todo el script"})

    # BP-09: Funciones muy largas / demasiados parametros (complejidad)
    funcs_largas, funcs_muchos_args = [], []
    lineas_bp09_largas, lineas_bp09_args = [], []
    for node in pyast.walk(tree):
        if isinstance(node, (pyast.FunctionDef, pyast.AsyncFunctionDef)):
            largo = (node.end_lineno - node.lineno) if hasattr(node, "end_lineno") and node.end_lineno else 0
            if largo > 60:
                funcs_largas.append(f"{node.name} ({largo} líneas)")
                lineas_bp09_largas.append(node.lineno)
            n_args = len(node.args.args)
            if n_args > 6:
                funcs_muchos_args.append(f"{node.name} ({n_args} args)")
                lineas_bp09_args.append(node.lineno)
    if funcs_largas:
        checks.append({"sev": "AVISO", "regla": "BP-09", "msg": f"{len(funcs_largas)} función(es) muy largas (>60 líneas) — dividir en funciones más chicas",
                        "det": ", ".join(funcs_largas[:5]), "lineas": lineas_bp09_largas})
        score -= 5 * min(len(funcs_largas), 3)
    if funcs_muchos_args:
        checks.append({"sev": "AVISO", "regla": "BP-09", "msg": f"{len(funcs_muchos_args)} función(es) con más de 6 parámetros — considerar agrupar en un dict/dataclass",
                        "det": ", ".join(funcs_muchos_args[:5]), "lineas": lineas_bp09_args})
        score -= 3 * min(len(funcs_muchos_args), 3)
    if not funcs_largas and not funcs_muchos_args and funciones:
        checks.append({"sev": "OK", "regla": "BP-09", "msg": "Funciones de tamaño y firma razonables"})

    # BP-10: Argumentos mutables por defecto (bug clasico de Python)
    mutables_default = []
    lineas_bp10 = []
    for node in pyast.walk(tree):
        if isinstance(node, (pyast.FunctionDef, pyast.AsyncFunctionDef)):
            for default in node.args.defaults:
                if isinstance(default, (pyast.List, pyast.Dict, pyast.Set)):
                    mutables_default.append(node.name)
                    lineas_bp10.append(node.lineno)
    if mutables_default:
        checks.append({"sev": "ERROR", "regla": "BP-10",
                        "msg": f"Argumento mutable como valor por defecto (list/dict/set) en: {', '.join(set(mutables_default))} — bug clasico, usar None y crear adentro",
                        "lineas": lineas_bp10})
        score -= 10
    else:
        checks.append({"sev": "OK", "regla": "BP-10", "msg": "Sin argumentos mutables por defecto"})

    # BP-11: eval/exec/shell=True/pickle.loads (riesgos de seguridad)
    riesgos = []
    lineas_bp11 = []
    for pat, desc in [(r'\beval\s*\(', "eval()"), (r'\bexec\s*\(', "exec()"),
                       (r'shell\s*=\s*True', "subprocess con shell=True"),
                       (r'pickle\.loads?\s*\(', "pickle.load — inseguro con datos no confiables")]:
        m = re.search(pat, codigo)
        if m:
            riesgos.append(desc)
            lineas_bp11.append(_linea_de_offset(codigo, m.start()))
    if riesgos:
        checks.append({"sev": "ERROR", "regla": "BP-11", "msg": "Patrones de riesgo de seguridad: " + ", ".join(riesgos), "lineas": lineas_bp11})
        score -= 15
    else:
        checks.append({"sev": "OK", "regla": "BP-11", "msg": "Sin patrones de riesgo de seguridad conocidos (eval/exec/shell=True)"})

    # BP-12: SQL con f-strings (riesgo de SQL injection)
    #
    # Criterio (definido por Gobierno de Datos):
    #  - Oracle NO admite bind params para nombres de tabla/vista/columna
    #    (identificadores). Interpolar un identificador que viene de una VARIABLE
    #    (cfg.x, config.x, self.x, o una variable local tipo `tabla`, `vista`,
    #    `columnas_sql`, `schema`) es la práctica correcta y NO es un hallazgo:
    #    las tablas/esquemas están variabilizados, no hardcodeados.
    #  - Solo se reporta cuando hay riesgo real:
    #      * se interpola un VALOR crudo (ej. {id_cliente}, {periodo} suelto), o
    #      * se HARDCODEA un nombre de tabla/valor como literal dentro del SQL.
    #    No se exige ningún comentario para "aprobar" — el validador no obliga a
    #    documentar de más; juzga el código como está.
    sql_fstrings = list(re.finditer(r'(execute|executemany)\s*\(\s*(f"""|f\'\'\'|f"|f\')', codigo))
    if sql_fstrings:
        for sql_fstring in sql_fstrings:
            num_linea = _linea_de_offset(codigo, sql_fstring.start())
            fragmento_real = _texto_lineas(codigo, [num_linea], contexto=1)

            # Delimitar EXACTAMENTE el string SQL (entre las comillas de apertura y
            # su cierre), para no capturar el dict de bind params ni f-strings de
            # logs que vengan después. Soporta """ ''' " ' como delimitadores.
            apertura = sql_fstring.group(2)          # f""" | f''' | f" | f'
            quote = apertura[1:]                     # """ | ''' | " | '
            ini_str = sql_fstring.end()              # justo después de la comilla de apertura
            fin_str = codigo.find(quote, ini_str)
            sql_text = codigo[ini_str:fin_str] if fin_str != -1 else codigo[ini_str:ini_str + 300]

            # Expresiones {…} SOLO dentro del string SQL.
            expresiones = [e.strip() for e in re.findall(r'\{([^{}]+)\}', sql_text)]
            expresion = expresiones[0] if expresiones else ""

            # ¿Cada expresión interpolada es un IDENTIFICADOR variabilizado?
            # Acepta: cfg.x / config.x / settings.x / conf.x / self.x  y variables
            # cuyo nombre denota un identificador (tabla, vista, esquema, columnas…).
            patron_ident = re.compile(
                r'^((cfg|config|settings|conf|self)\.[\w.]+'
                r'|[\w]*\b(tabla|vista|schema|esquema|columna|columnas|col|owner|nombre_tabla)[\w]*'
                r'|columnas?_sql)$',
                re.IGNORECASE)
            def _es_identificador(expr):
                return bool(patron_ident.match(expr))

            todas_identificadores = bool(expresiones) and all(_es_identificador(e) for e in expresiones)

            if todas_identificadores:
                # Correcto: interpola solo identificadores variabilizados. No es hallazgo.
                nombres = ", ".join(f"'{e}'" for e in expresiones[:3])
                checks.append({
                    "sev": "OK", "regla": "BP-12",
                    "msg": (f"SQL con identificador(es) variabilizado(s) ({nombres}) — correcto: "
                            f"Oracle no admite bind params para nombres de tabla/vista, y no hay "
                            f"tablas ni valores hardcodeados."),
                    "lineas": [num_linea], "codigo_real": fragmento_real,
                })
            elif expresiones:
                # Interpola algo que NO parece un identificador → posible valor crudo.
                crudas = [e for e in expresiones if not _es_identificador(e)]
                checks.append({
                    "sev": "ERROR", "regla": "BP-12",
                    "msg": (f"SQL con f-string interpolando un valor no variabilizado como identificador "
                            f"({', '.join(crudas[:3])}) — si es un VALOR, usar bind params (:param); "
                            f"si es un identificador, traerlo de config."),
                    "lineas": [num_linea], "codigo_real": fragmento_real,
                })
                score -= 15
            else:
                # f-string sin interpolación real (raro) — informativo.
                checks.append({
                    "sev": "OK", "regla": "BP-12",
                    "msg": "Ejecución SQL con f-string sin interpolación de variables (revisar igualmente).",
                    "lineas": [num_linea], "codigo_real": fragmento_real,
                })
    elif re.search(r'\.execute\s*\(', codigo):
        checks.append({"sev": "OK", "regla": "BP-12", "msg": "Ejecución SQL con parámetros bind (sin f-strings)"})

    # BP-13: import * (contamina namespace, dificulta saber de donde viene cada nombre)
    m_importstar = re.search(r'from\s+\S+\s+import\s+\*', codigo)
    if m_importstar:
        checks.append({"sev": "AVISO", "regla": "BP-13", "msg": "Uso de 'from modulo import *' — evitar, dificulta rastrear origen de nombres",
                        "lineas": [_linea_de_offset(codigo, m_importstar.start())]})
        score -= 5
    else:
        checks.append({"sev": "OK", "regla": "BP-13", "msg": "Sin wildcard imports"})

    # BP-14: TODO / FIXME pendientes
    todos = re.findall(r'#\s*(TODO|FIXME|XXX)\b', codigo, re.IGNORECASE)
    if todos:
        checks.append({"sev": "AVISO", "regla": "BP-14", "msg": f"{len(todos)} comentario(s) TODO/FIXME/XXX pendientes en el código"})
    else:
        checks.append({"sev": "OK", "regla": "BP-14", "msg": "Sin TODO/FIXME pendientes"})

    # BP-15: open() sin context manager (riesgo de no cerrar el archivo)
    opens_sin_with = len(re.findall(r'(?<!with\s)(?<!with )\bopen\s*\(', codigo))
    opens_con_with = len(re.findall(r'with\s+open\s*\(', codigo))
    if opens_sin_with > opens_con_with:
        checks.append({"sev": "AVISO", "regla": "BP-15",
                        "msg": f"Posibles open() sin 'with' ({opens_sin_with} open, {opens_con_with} con with) — riesgo de no cerrar el archivo"})
        score -= 5
    elif opens_con_with > 0:
        checks.append({"sev": "OK", "regla": "BP-15", "msg": "Manejo de archivos con context manager (with open)"})

    # BP-16: assert usado como validacion (se elimina con python -O, no usar para logica de negocio)
    asserts_negocio = len(re.findall(r'^\s*assert\s+', codigo, re.MULTILINE))
    if _es_test and asserts_negocio > 0:
        checks.append({"sev": "OK", "regla": "BP-16",
                        "msg": f"{asserts_negocio} 'assert' — correcto en un archivo de test (es la API de pytest)"})
    elif asserts_negocio > 3:
        checks.append({"sev": "AVISO", "regla": "BP-16",
                        "msg": f"{asserts_negocio} 'assert' en el código — si son validaciones de negocio (no tests), se desactivan con python -O; usar excepciones"})
        score -= 5

    # BP-17: convencion de nombres (funciones/clases)
    funcs_mal = [f["nombre"] for f in funciones if not re.match(r'^_?[a-z][a-z0-9_]*$', f["nombre"])]
    clases_mal = [c["nombre"] for c in clases if not re.match(r'^[A-Z][A-Za-z0-9]*$', c["nombre"])]
    if funcs_mal or clases_mal:
        det = (f"funciones: {', '.join(funcs_mal[:5])}" if funcs_mal else "") + \
              (f" | clases: {', '.join(clases_mal[:5])}" if clases_mal else "")
        checks.append({"sev": "AVISO", "regla": "BP-17",
                        "msg": "Nombres fuera de convención PEP8 (snake_case funciones, PascalCase clases)", "det": det})
        score -= 3
    else:
        checks.append({"sev": "OK", "regla": "BP-17", "msg": "Convención de nombres PEP8 respetada"})

    # BP-19: cierre explicito de conexiones a base de datos
    usa_conexion_db = bool(re.search(r'\.connect\s*\(|oracledb\.connect', codigo))
    if usa_conexion_db:
        tiene_close = bool(re.search(r'\.close\s*\(\s*\)', codigo))
        tiene_with_conexion = bool(re.search(r'with\s+[\w\.]+\.connect\s*\(', codigo))
        if tiene_close or tiene_with_conexion:
            checks.append({"sev": "OK", "regla": "BP-19", "msg": "Conexión a base de datos con cierre explícito"})
        else:
            checks.append({"sev": "AVISO", "regla": "BP-19",
                            "msg": "Conexión a base de datos detectada sin .close() ni 'with' — verificar que se cierre"})
            score -= 5

    # BP-20: commit explicito en operaciones de escritura (INSERT/UPDATE/DELETE)
    tiene_dml = bool(re.search(r'execute(?:many)?\s*\([^)]*\b(INSERT|UPDATE|DELETE|MERGE)\b', codigo, re.IGNORECASE))
    if tiene_dml:
        tiene_commit = bool(re.search(r'\.commit\s*\(\s*\)', codigo))
        if tiene_commit:
            checks.append({"sev": "OK", "regla": "BP-20", "msg": "Operación de escritura con commit explícito"})
        else:
            checks.append({"sev": "AVISO", "regla": "BP-20",
                            "msg": "INSERT/UPDATE/DELETE detectado sin .commit() — verificar que la transacción se confirme"})
            score -= 8

    # BP-21: punto de entrada explicito (if __name__ == "__main__")
    # Solo tiene sentido para SCRIPTS ejecutables (los que corren algo al arrancar).
    # Un módulo importable que solo define funciones/clases (config.py, utils.py,
    # scoring.py…) NO necesita __main__ guard — no ejecuta nada al importarse.
    # La regla solo marca si hay código SUELTO a nivel de módulo (llamadas top-level)
    # que se ejecutaría al importar, sin estar protegido por el guard.
    if funciones:
        tiene_main_guard = bool(re.search(r'if\s+__name__\s*==\s*[\'"]__main__[\'"]', codigo))
        # ¿Hay llamadas ejecutables a nivel de módulo (col 0, no def/class/import/decorador)?
        tiene_codigo_top_level = False
        try:
            for node in pyast.iter_child_nodes(tree):
                if isinstance(node, pyast.Expr) and isinstance(node.value, pyast.Call):
                    tiene_codigo_top_level = True
                    break
                if isinstance(node, pyast.If):
                    # if __name__ == "__main__": está bien; otros if top-level con llamadas, no
                    test = node.test
                    es_guard = (isinstance(test, pyast.Compare)
                                and isinstance(test.left, pyast.Name)
                                and test.left.id == "__name__")
                    if not es_guard:
                        tiene_codigo_top_level = True
                        break
        except Exception:
            tiene_codigo_top_level = False

        if tiene_main_guard:
            checks.append({"sev": "OK", "regla": "BP-21", "msg": "Punto de entrada protegido con if __name__ == '__main__'"})
        elif tiene_codigo_top_level:
            checks.append({"sev": "AVISO", "regla": "BP-21",
                            "msg": "Hay código que se ejecuta al importar el módulo — protegerlo con if __name__ == '__main__'"})
            score -= 5
        else:
            checks.append({"sev": "OK", "regla": "BP-21",
                            "msg": "Módulo importable (solo define funciones/clases) — no requiere guard __main__"})

    # BP-22: docstring de modulo al inicio del archivo
    tiene_docstring_modulo = False
    if tree.body and isinstance(tree.body[0], pyast.Expr) and isinstance(tree.body[0].value, (pyast.Constant,)):
        if isinstance(tree.body[0].value.value, str):
            tiene_docstring_modulo = True
    if tiene_docstring_modulo:
        checks.append({"sev": "OK", "regla": "BP-22", "msg": "Docstring de módulo presente al inicio del archivo"})
    else:
        checks.append({"sev": "AVISO", "regla": "BP-22", "msg": "Sin docstring de módulo — falta descripción al inicio del archivo"})
        score -= 3

    # ── ML-specific checks ──
    # Contexto: estos scripts corren en PRODUCCION (cargan un modelo ya
    # entrenado y predicen) — no entrenan el modelo. Por eso las reglas
    # de esta seccion evaluan conceptos de INFERENCIA/PASE A PRODUCCION.
    # No se evaluan train/test split (ML-01), busqueda de hiperparametros,
    # ni early stopping — esos SI son exclusivos de entrenamiento y no
    # tienen forma de reenfocarse a produccion.
    if resultado["ml_info"]:
        ml = resultado["ml_info"]

        # ML-02 (reenfocada a produccion): validacion champion-challenger
        # contra el modelo anterior antes de reemplazarlo — no es "cross
        # validation" de entrenamiento, es comparar versiones en produccion.
        tiene_validacion_champion = bool(re.search(
            r'\bchampion\b|\bchallenger\b|modelo_anterior|version_anterior|modelo_v\d+.*modelo_v\d+',
            codigo, re.IGNORECASE))
        if tiene_validacion_champion:
            checks.append({"sev": "OK", "regla": "ML-02", "msg": "Comparación contra modelo/versión anterior detectada"})
        else:
            checks.append({"sev": "AVISO", "regla": "ML-02",
                            "msg": "Sin comparación contra el modelo anterior antes de reemplazarlo (champion-challenger)"})
            score -= 5

        # ML-03 (reenfocada a produccion): usar el Pipeline serializado del
        # entrenamiento para el preprocesamiento, en vez de reimplementarlo
        # a mano en el script de produccion.
        tiene_pipeline_serializado = bool(re.search(
            r'pipeline.*\.(load|transform)\s*\(|joblib\.load\([^)]*pipeline', codigo, re.IGNORECASE))
        if ml["tiene_pipeline"] or tiene_pipeline_serializado:
            checks.append({"sev": "OK", "regla": "ML-03", "msg": "Usa Pipeline serializado para preprocesamiento consistente"})
        else:
            checks.append({"sev": "AVISO", "regla": "ML-03",
                            "msg": "Sin Pipeline serializado — verificar que el preprocesamiento en producción sea idéntico al del entrenamiento"})
            score -= 5

        # ML-04: metricas que SI se pueden calcular en produccion (sin ground
        # truth): resumen del batch — total procesado, aprobados/rechazados,
        # distribucion de scores. NO exige accuracy/F1 (eso es de entrenamiento).
        tiene_resumen_produccion = bool(re.search(
            r'value_counts\s*\(|\.describe\s*\(\s*\)|\bresumen\s*=|\btotal_procesados\b|'
            r'\bn_aprobados\b|\bn_rechazados\b|\baprobados\b\s*[:=]|\brechazados\b\s*[:=]',
            codigo, re.IGNORECASE))
        if tiene_resumen_produccion:
            checks.append({"sev": "OK", "regla": "ML-04", "msg": "Resumen de resultados del batch detectado"})
        else:
            checks.append({"sev": "ERROR", "regla": "ML-04",
                            "msg": "Sin resumen del batch — llevar a producción sin poder ver qué pasó con el batch (aprobados/rechazados/distribución) es crítico"})
            score -= 15

        if ml["tiene_scaler"]:
            checks.append({"sev": "OK", "regla": "ML-05", "msg": "Normalización/escalado de features"})
        else:
            checks.append({"sev": "AVISO", "regla": "ML-05", "msg": "Sin scaler — verificar si el modelo espera features normalizados/escalados"})
            score -= 5

        if ml["tiene_pickle_joblib"]:
            checks.append({"sev": "OK", "regla": "ML-06", "msg": "Carga del modelo serializado (joblib/pickle) detectada"})
        else:
            checks.append({"sev": "AVISO", "regla": "ML-06", "msg": "Sin indicios de carga de modelo serializado — verificar cómo se carga el modelo en producción"})
            score -= 5

        if ml["tiene_feature_importance"]:
            checks.append({"sev": "OK", "regla": "ML-07", "msg": "Interpretabilidad (feature importance/SHAP)"})

        # ML-11: PSI (Population Stability Index) — monitoreo de drift de datos
        # Solo se evalua SI el script calcula PSI (no aplica a todos los scripts)
        if re.search(r'\bpsi\b', codigo, re.IGNORECASE):
            umbrales_psi = re.findall(r'psi.{0,80}?(?:>=?|<=?)\s*0?\.\d+', codigo, re.IGNORECASE | re.DOTALL)
            tiene_warning = bool(re.search(r'(warning|aviso|alerta)', codigo, re.IGNORECASE))
            tiene_critico = bool(re.search(r'(cr[ií]tico|critical)', codigo, re.IGNORECASE))
            if len(umbrales_psi) >= 2 or (tiene_warning and tiene_critico):
                checks.append({"sev": "OK", "regla": "ML-11",
                                "msg": "PSI calculado con niveles de umbral (warning y crítico) detectados"})
            else:
                checks.append({"sev": "AVISO", "regla": "ML-11",
                                "msg": "PSI calculado pero sin dos niveles claros de umbral (warning y crítico)"})
                score -= 5

        # ML-12: manejo de errores alrededor de la prediccion
        tiene_predict = bool(re.search(r'\.predict(_proba)?\s*\(', codigo))
        if tiene_predict:
            tiene_try_general = bool(re.search(r'\btry\s*:', codigo))
            if tiene_try_general:
                checks.append({"sev": "OK", "regla": "ML-12", "msg": "Manejo de errores presente en el script de predicción"})
            else:
                checks.append({"sev": "AVISO", "regla": "ML-12",
                                "msg": "predict() sin ningún try/except en el script — un dato problemático puede frenar todo el batch"})
                score -= 8

        # ML-13: validacion de esquema/columnas de entrada antes de predecir
        if tiene_predict:
            tiene_validacion_esquema = bool(re.search(
                r'columnas_esperadas|expected_columns|set\(df\.columns\)|\.columns\s*==|schema', codigo, re.IGNORECASE))
            if tiene_validacion_esquema:
                checks.append({"sev": "OK", "regla": "ML-13", "msg": "Validación de esquema de entrada detectada"})
            else:
                checks.append({"sev": "AVISO", "regla": "ML-13",
                                "msg": "Sin validación de columnas esperadas antes de predecir"})
                score -= 5

        # ML-14: manejo de valores nulos/faltantes antes de predecir
        if tiene_predict:
            tiene_manejo_nulos = bool(re.search(r'\.dropna\s*\(|\.fillna\s*\(|\.isnull\s*\(|\.isna\s*\(', codigo))
            if tiene_manejo_nulos:
                checks.append({"sev": "OK", "regla": "ML-14", "msg": "Manejo de valores nulos/faltantes detectado"})
            else:
                checks.append({"sev": "AVISO", "regla": "ML-14",
                                "msg": "Sin manejo explícito de nulos/faltantes antes de predecir"})
                score -= 5

        # ML-15: version del modelo trazable
        tiene_version_modelo = bool(re.search(r'model_version|version_modelo|MODEL_VERSION', codigo, re.IGNORECASE))
        if tiene_version_modelo:
            checks.append({"sev": "OK", "regla": "ML-15", "msg": "Versión del modelo registrada/trazable"})
        else:
            checks.append({"sev": "AVISO", "regla": "ML-15",
                            "msg": "Sin versión de modelo explícita — no se puede rastrear qué modelo generó cada predicción"})
            score -= 3

    # ── Reglas configurables: overrides sobre las builtin + reglas 100% custom ──
    reglas_cfg = _reglas_por_codigo()
    checks, ajuste_score = _aplicar_overrides(checks, reglas_cfg)
    checks_custom = _ejecutar_reglas_custom(codigo, reglas_cfg)
    for cc in checks_custom:
        score -= _DELTA_APROX_SEVERIDAD.get(cc["sev"], 5)
    checks = checks + checks_custom
    score += ajuste_score

    resultado["buenas_practicas"] = [_con_recomendacion(c) for c in checks]
    resultado["score"] = max(0, min(100, score))
    resultado["veredicto"] = _veredicto(
        resultado["score"],
        forzar_no_aprobado=_tiene_criticos_personalizados(resultado["buenas_practicas"])
    )
    return resultado


# ════════════════════════════════════════════════════════
#  ANALISIS DE PROYECTO COMPLETO (main + dependencias + docs)
# ════════════════════════════════════════════════════════

def esc_pdf(s):
    """Escapa texto para insertarlo seguro dentro de un Paragraph de reportlab (que interpreta XML/HTML basico)."""
    if s is None:
        return ""
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def _dotted_variantes(rel_path):
    """
    'raiz/src/preprocessing.py' -> {'raiz.src.preprocessing', 'src.preprocessing', 'preprocessing'}
    'src/__init__.py'          -> {'src'}
    Genera TODOS los sufijos dotted posibles, para cubrir cualquier
    carpeta que el proyecto use como raiz de sys.path (no sabemos
    cual es desde afuera, asi que se prueban todas las combinaciones).
    """
    sin_ext = os.path.splitext(rel_path)[0]
    partes = [p for p in sin_ext.split("/") if p]
    if partes and partes[-1] == "__init__":
        partes = partes[:-1]
    if not partes:
        return set()
    variantes = set()
    for i in range(len(partes)):
        variantes.add(".".join(partes[i:]))
    return variantes


def _mapa_modulos(archivos):
    """dotted_name -> ruta_relativa, para TODOS los archivos del proyecto."""
    mapa = {}
    for rel in archivos:
        for variante in _dotted_variantes(rel):
            mapa.setdefault(variante, rel)
    return mapa


def _extraer_candidatos_import(codigo, rel_path_actual):
    """
    Devuelve una lista de nombres 'dotted' candidatos a ser una
    dependencia LOCAL del proyecto — cubre:
      import src.preprocessing
      from src.preprocessing import DataPreprocessor
      from src import preprocessing
      from . import utils            (relativo, mismo paquete)
      from .utils import algo        (relativo)
      from ..config import settings  (relativo, sube un nivel)
    """
    candidatos = []
    try:
        tree = pyast.parse(codigo)
    except SyntaxError:
        return candidatos

    dir_actual = os.path.dirname(rel_path_actual)
    partes_dir = [p for p in dir_actual.split("/") if p]

    for node in pyast.walk(tree):
        if isinstance(node, pyast.Import):
            for n in node.names:
                candidatos.append(n.name)
                candidatos.append(n.name.split(".")[0])

        elif isinstance(node, pyast.ImportFrom):
            if node.level and node.level > 0:
                # Import relativo. level=1 -> paquete actual; level=2 -> un nivel arriba; etc.
                subir = node.level - 1
                base_partes = partes_dir[:-subir] if subir and subir <= len(partes_dir) else (
                    partes_dir if subir == 0 else [])
                base = ".".join(base_partes)
                if node.module:
                    dotted = (base + "." + node.module) if base else node.module
                    candidatos.append(dotted)
                    candidatos.append(dotted.split(".")[-1])
                for n in node.names:
                    prefijo = (base + "." + node.module) if (base and node.module) else (node.module or base)
                    if prefijo:
                        candidatos.append(prefijo + "." + n.name)
                    else:
                        candidatos.append(n.name)
            else:
                if node.module:
                    candidatos.append(node.module)
                    candidatos.append(node.module.split(".")[0])
                    # Antes solo se probaba el nombre completo ("src.preprocessing")
                    # y el primer segmento ("src") — nunca el último segmento
                    # ("preprocessing") solo. Si por cualquier motivo el archivo
                    # quedó registrado sin el prefijo del paquete (rutas aplanadas,
                    # proyecto sin __init__.py, etc.), esto hacía que nunca
                    # coincidiera con nada y el archivo quedara marcado como
                    # huérfano aunque sí estuviera importado.
                    candidatos.append(node.module.split(".")[-1])
                    for n in node.names:
                        candidatos.append(node.module + "." + n.name)

    return candidatos


def _resolver_grafo_dependencias(archivos, main_rel):
    """
    archivos: dict {ruta_relativa: codigo}
    main_rel: ruta relativa del archivo principal (entry point)

    Devuelve:
      vinculados: set de rutas relativas alcanzables desde main (incluye main)
      huerfanos:  archivos .py del set que NO son alcanzados desde main
      edges:      lista de (origen, destino) para dibujar el grafo
    """
    mapa_modulos = _mapa_modulos(archivos)

    vinculados = set()
    edges = []
    stack = [main_rel]
    while stack:
        actual = stack.pop()
        if actual in vinculados or actual not in archivos:
            continue
        vinculados.add(actual)

        for candidato in _extraer_candidatos_import(archivos[actual], actual):
            destino = mapa_modulos.get(candidato)
            if destino and destino != actual:
                edges.append((actual, destino))
                if destino not in vinculados:
                    stack.append(destino)

    def _es_test_path(p):
        pl = p.replace("\\", "/").lower()
        b = os.path.basename(pl)
        return (b.startswith("test_") or b.endswith("_test.py")
                or b == "conftest.py" or "/tests/" in pl or pl.startswith("tests/"))

    # Los tests NO son huérfanos: pytest los descubre solo, nunca se importan
    # desde main. Marcarlos como huérfanos era un falso positivo de EP-05.
    huerfanos = sorted(
        p for p in (set(archivos) - vinculados - {main_rel})
        if os.path.basename(p) != "__init__.py" and not _es_test_path(p)
    )
    edges = sorted(set(edges))
    return vinculados, huerfanos, edges


def _validar_estructura_readme(md_files, todos_los_nombres):
    """
    Busca en el README un bloque de 'Estructura de Directorios' dibujado con
    caracteres de árbol (├── └── │) y lo compara contra las rutas reales del
    proyecto. Devuelve una lista de nodos {nombre, tipo, nivel, existe} para que
    el frontend lo dibuje como árbol con ✓/✗, o None si no hay estructura en el README.
    """
    # Tomar el contenido del README
    readme = None
    for k, v in (md_files or {}).items():
        if re.search(r'readme', k, re.IGNORECASE):
            readme = v
            break
    if not readme:
        return None

    lineas = readme.splitlines()
    # Buscar el encabezado de estructura (## Estructura de Directorios, o similar)
    idx_ini = None
    for i, ln in enumerate(lineas):
        if re.search(r'estructura\s+de\s+(directorios|carpetas|proyecto|archivos)', ln, re.IGNORECASE):
            idx_ini = i
            break
    if idx_ini is None:
        return None

    # El árbol suele venir dentro de un bloque ``` … ```. Buscar el primer fence
    # después del encabezado y tomar hasta el fence de cierre.
    bloque = []
    dentro = False
    for ln in lineas[idx_ini + 1:]:
        if ln.strip().startswith("```"):
            if not dentro:
                dentro = True
                continue
            else:
                break  # fin del bloque
        if dentro:
            bloque.append(ln)
        elif re.search(r'[├└│]', ln):
            # también aceptar árboles sin fences
            bloque.append(ln)
    if not bloque:
        return None

    # Conjunto de nombres reales (carpetas y archivos, en cualquier nivel)
    nombres_reales = set()
    carpetas_reales = set()
    for ruta in todos_los_nombres:
        partes = ruta.replace("\\", "/").split("/")
        nombres_reales.add(partes[-1].lower())          # nombre de archivo
        for seg in partes[:-1]:
            carpetas_reales.add(seg.lower())            # carpetas
            nombres_reales.add(seg.lower())

    def _existe(nombre, es_carpeta):
        n = nombre.lower().rstrip("/")
        if es_carpeta:
            variantes = {n, n.rstrip("s"), n + "s"}
            return any(v in carpetas_reales for v in variantes)
        return n in nombres_reales

    nodos = []
    for ln in bloque:
        if not ln.strip():
            continue
        # Nivel = profundidad según los conectores de árbol antes del nombre
        m = re.match(r'^([\s│]*)(├──|└──|\|--|`--)?\s*(.+)$', ln)
        if not m:
            continue
        prefijo, _conector, resto = m.groups()
        # Quitar comentarios de flecha (← …, # …) y espacios
        nombre = re.split(r'\s*(?:←|<-|#|//)', resto, 1)[0].strip()
        if not nombre or nombre in ("```",):
            continue
        # Ignorar la línea raíz del proyecto (ej. "scoring_pgs/")
        nivel = len(re.findall(r'[│]', prefijo)) + (1 if _conector else 0)
        es_carpeta = nombre.endswith("/")
        nombre_limpio = nombre.rstrip("/")
        # La raíz (nivel 0 y termina en /) no se valida, es el contenedor
        if nivel == 0 and es_carpeta:
            nodos.append({"nombre": nombre_limpio, "tipo": "raiz", "nivel": 0, "existe": True})
            continue
        existe = _existe(nombre_limpio, es_carpeta)
        nodos.append({
            "nombre": nombre_limpio,
            "tipo": "carpeta" if es_carpeta else "archivo",
            "nivel": nivel,
            "existe": bool(existe),
        })

    return nodos if nodos else None


def _checks_estructura_proyecto(archivos, md_files, huerfanos, otros_files=None, tree_paths=None):
    """Buenas practicas a nivel de PROYECTO de ciencia de datos (no de un solo script)."""
    otros_files = otros_files or {}
    # tree_paths trae TODAS las rutas del proyecto (incluidas carpetas con solo
    # datos/binarios como data/ o models/*.cbm), para que EP-09 confirme la
    # estructura completa aunque esos archivos no se analicen como código.
    tree_paths = tree_paths or []
    todos_los_nombres = list(archivos) + list(md_files) + list(otros_files) + list(tree_paths)
    checks = []
    bonus = 0

    # EP-01: documentacion (README / md)
    tiene_readme = any(re.search(r'readme', k, re.IGNORECASE) for k in md_files)
    if tiene_readme:
        checks.append({"sev": "OK", "regla": "EP-01", "msg": "Documentacion README encontrada"})
        bonus += 5
    elif md_files:
        checks.append({"sev": "AVISO", "regla": "EP-01", "msg": f"Hay {len(md_files)} .md pero ninguno parece README"})
    else:
        checks.append({"sev": "ERROR", "regla": "EP-01", "msg": "Sin ningun archivo .md de documentacion en el proyecto"})
        bonus -= 10

    # EP-02: requirements / dependencias declaradas
    tiene_requirements = any(re.search(r'requirements.*\.txt$|pyproject\.toml$|environment\.ya?ml$|pipfile$', k, re.IGNORECASE)
                              for k in todos_los_nombres)
    if tiene_requirements:
        checks.append({"sev": "OK", "regla": "EP-02", "msg": "Dependencias declaradas (requirements/pyproject/environment)"})
        bonus += 5
    else:
        checks.append({"sev": "AVISO", "regla": "EP-02", "msg": "No se encontro requirements.txt / pyproject.toml — dificulta reproducibilidad"})
        bonus -= 5

    # EP-03: tests
    tiene_tests = any(re.search(r'(^|/)(test_|tests/)', k, re.IGNORECASE) for k in archivos)
    if tiene_tests:
        checks.append({"sev": "OK", "regla": "EP-03", "msg": "Se detectaron archivos de test (test_*.py o carpeta tests/)"})
        bonus += 10
    else:
        checks.append({"sev": "AVISO", "regla": "EP-03", "msg": "Sin tests automatizados detectados"})
        bonus -= 5

    # EP-04: modularidad — si hay mas de 1 archivo, main no deberia ser el unico con codigo real
    if len(archivos) > 1:
        checks.append({"sev": "OK", "regla": "EP-04", "msg": f"Proyecto modular: {len(archivos)} archivos .py vinculados/analizados"})
        bonus += 5
    else:
        checks.append({"sev": "AVISO", "regla": "EP-04", "msg": "Un solo archivo — para proyectos de ML conviene separar en modulos (data, model, utils)"})

    # EP-05: archivos huerfanos (no alcanzados desde main)
    # (ya viene sin __init__.py incluido — ver _resolver_grafo_dependencias)
    if huerfanos:
        checks.append({"sev": "AVISO", "regla": "EP-05",
                        "msg": f"{len(huerfanos)} archivo(s) no se importan desde el main — revisar si son necesarios",
                        "det": ", ".join(huerfanos[:8])})
        bonus -= 3 * min(len(huerfanos), 3)
    else:
        checks.append({"sev": "OK", "regla": "EP-05", "msg": "Todos los archivos del proyecto estan vinculados al main"})

    # EP-06: convencion de nombres (snake_case, sin espacios)
    mal_nombrados = [k for k in archivos if re.search(r'[A-Z ]', os.path.basename(k))]
    if mal_nombrados:
        checks.append({"sev": "AVISO", "regla": "EP-06", "msg": "Archivos con nombres fuera de snake_case",
                        "det": ", ".join(mal_nombrados[:5])})
        bonus -= 3
    else:
        checks.append({"sev": "OK", "regla": "EP-06", "msg": "Nombres de archivo consistentes (snake_case)"})

    # EP-07: credenciales hardcodeadas repetidas en MAS de un archivo del proyecto
    # Excluye los archivos de test (sus credenciales son ficticias para mocks).
    def _es_test_ep07(p):
        pl = p.replace("\\", "/").lower()
        b = os.path.basename(pl)
        return (b.startswith("test_") or b.endswith("_test.py")
                or b == "conftest.py" or "/tests/" in pl or pl.startswith("tests/"))

    cred_hits = []  # (archivo, linea, fragmento)
    patron_cred = re.compile(r'(?:password|passwd|pwd|secret|api_key|token)\s*=\s*["\'][^"\']+["\']', re.IGNORECASE)
    for rel, codigo_arch in archivos.items():
        if _es_test_ep07(rel):
            continue
        for m in patron_cred.finditer(codigo_arch):
            ln = codigo_arch[:m.start()].count("\n") + 1
            cred_hits.append((rel, ln, codigo_arch.splitlines()[ln - 1].strip()[:80]))

    if cred_hits:
        archivos_afectados = sorted({h[0] for h in cred_hits})
        # Detalle línea por línea: "src/utils.py:L136 — password = ..."
        detalle_lineas = "; ".join(f"{a}:L{l} → {frag}" for a, l, frag in cred_hits[:6])
        checks.append({"sev": "ERROR", "regla": "EP-07",
                        "msg": (f"Credenciales hardcodeadas en {len(archivos_afectados)} archivo(s): "
                                f"{', '.join(archivos_afectados)}. Centralizar en .env."),
                        "det": detalle_lineas,
                        "codigo_real": detalle_lineas})
        bonus -= 5 * min(len(archivos_afectados), 3)
    else:
        checks.append({"sev": "OK", "regla": "EP-07", "msg": "Sin credenciales hardcodeadas detectadas en el proyecto"})

    # EP-08: control de versiones / archivos que no deberian versionarse
    tiene_gitignore = any(re.search(r'(^|/)\.gitignore$', k) for k in todos_los_nombres)
    tiene_env_en_md_o_py = any(re.search(r'(^|/)\.env$', k) for k in todos_los_nombres)
    if tiene_env_en_md_o_py and not tiene_gitignore:
        checks.append({"sev": "AVISO", "regla": "EP-08",
                        "msg": "Se detecto un archivo .env dentro del proyecto sin .gitignore visible — riesgo de subir credenciales al repo"})
        bonus -= 5
    elif tiene_gitignore:
        checks.append({"sev": "OK", "regla": "EP-08", "msg": ".gitignore presente en el proyecto"})
    else:
        checks.append({"sev": "AVISO", "regla": "EP-08", "msg": "No se encontro .gitignore — verificar que no se versionen credenciales/artefactos"})

    # EP-09: estructura de carpetas/archivos segun la convencion MLOps del equipo
    # (editable en /python -> Reglas: que carpetas y archivos son obligatorios)
    fila_ep09 = _reglas_por_codigo().get("EP-09")
    if fila_ep09 and fila_ep09["activa"]:
        try:
            cfg_estructura = json.loads(fila_ep09.get("valor_config") or "{}")
        except (json.JSONDecodeError, TypeError):
            cfg_estructura = {}
        carpetas_esperadas = cfg_estructura.get("carpetas", [])
        archivos_esperados = cfg_estructura.get("archivos", [])

        # Antes solo se miraba el PRIMER segmento de cada ruta (n.split("/")[0]).
        # Si el proyecto queda anidado bajo una carpeta contenedora extra (ej. el
        # nombre del repo, o una carpeta de versión), el primer segmento nunca
        # es "src"/"config"/etc., y TODO aparecía como faltante aunque sí
        # existiera un nivel más adentro. Ahora se busca en CUALQUIER nivel de
        # la ruta, no solo el primero — más tolerante a cómo haya quedado
        # anidado el proyecto en el escaneo.
        todos_los_segmentos = set()
        for n in todos_los_nombres:
            todos_los_segmentos.update(n.split("/")[:-1])  # todas las carpetas, no el archivo final

        def _carpeta_presente(esperada):
            # Tolerante a singular/plural: 'test' matchea 'tests', 'model' matchea
            # 'models', 'script' matchea 'scripts'. Evita falsos "faltantes" por
            # una 's' de diferencia entre la convención y el nombre real.
            variantes = {esperada.lower(), esperada.lower().rstrip("s"), esperada.lower() + "s"}
            return any(seg.lower() in variantes for seg in todos_los_segmentos)

        carpetas_faltantes = [c for c in carpetas_esperadas if not _carpeta_presente(c)]
        archivos_faltantes = [a for a in archivos_esperados
                               if not any(n == a or n.endswith("/" + a) for n in todos_los_nombres)]

        faltantes = carpetas_faltantes + archivos_faltantes
        sev_default = "AVISO"
        sev = fila_ep09.get("severidad_override") or sev_default
        if faltantes:
            partes_msg = []
            if carpetas_faltantes:
                partes_msg.append(f"Carpetas faltantes: {', '.join(carpetas_faltantes)}")
            if archivos_faltantes:
                partes_msg.append(f"Archivos faltantes: {', '.join(archivos_faltantes)}")
            # Detalle: qué se esperaba vs qué carpetas se encontraron realmente.
            carpetas_encontradas = sorted(s for s in todos_los_segmentos if s)
            det = (f"Esperado: carpetas [{', '.join(carpetas_esperadas)}], "
                   f"archivos [{', '.join(archivos_esperados)}]. "
                   f"Encontrado en el proyecto: [{', '.join(carpetas_encontradas) or '(ninguna carpeta)'}]. "
                   f"Si una carpeta existe pero está vacía o solo tiene binarios (ej. models/*.cbm), "
                   f"agregá un archivo .gitkeep adentro para que viaje en el análisis.")
            checks.append({"sev": sev, "regla": "EP-09",
                            "msg": (" · ".join(partes_msg) +
                                    " — según la estructura MLOps definida por el equipo "
                                    "(editable en Python & ML → Reglas)"),
                            "det": det, "codigo_real": det})
            bonus -= 3 * min(len(faltantes), 4)
        else:
            checks.append({"sev": "OK", "regla": "EP-09",
                            "msg": "Estructura del proyecto conforme a la convención MLOps definida"})

    checks = [_con_recomendacion(c) for c in checks]
    return checks, bonus


def _veredicto(score, forzar_no_aprobado=False):
    """
    Aplica el criterio de aprobacion del portal.
    forzar_no_aprobado=True cuando hay al menos un hallazgo marcado como
    'critico_personalizado' (BP-01/03/08/18, ML-11 en ERROR) — en ese caso
    no puede pasar a Deploy todavia (aprobado=False), sin importar el
    score, ni siquiera con 90+: un hallazgo critico bloquea igual.
    Ademas, "Aprobado" pleno (verde) solo aplica con 100/100 exacto y sin
    criticos — cualquier cosa por debajo, aunque este aprobada para pasar
    a Deploy, queda marcada como "con observaciones", nunca como un
    Aprobado sin matices.
    """
    if forzar_no_aprobado:
        return {"aprobado": False, "nivel": "requiere_ajustes",
                "label": "Requiere ajustes (hallazgo crítico)", "color": "#dc2626"}
    if score <= 50:
        return {"aprobado": False, "nivel": "requiere_ajustes", "label": "Requiere ajustes", "color": "#dc2626"}
    elif score < 100:
        return {"aprobado": True, "nivel": "observaciones", "label": "Aprobado con observaciones", "color": "#d97706"}
    else:
        return {"aprobado": True, "nivel": "ok", "label": "Aprobado", "color": "#16a34a"}


def _tiene_criticos_personalizados(checks):
    """True si alguno de los checks tiene el flag critico_personalizado en ERROR."""
    return any(c.get("critico_personalizado") for c in (checks or []))


def analizar_proyecto(archivos, main_rel, md_files, otros_files=None, tree_paths=None):
    """
    archivos:    dict {ruta_relativa: codigo}      (todos los .py disponibles, locales o del server)
    main_rel:    ruta relativa del archivo principal (el que se ejecuta / entry point)
    md_files:    dict {ruta_relativa: contenido}   (documentacion .md del proyecto)
    otros_files: dict {ruta_relativa: contenido}   (requirements.txt, .gitignore, pyproject.toml, etc.
                 — solo se usan para checks de EXISTENCIA de estructura, no se analizan como codigo)
    """
    otros_files = otros_files or {}
    if main_rel not in archivos:
        raise ValueError(f"El archivo principal '{main_rel}' no esta en el set de archivos analizados")

    vinculados, huerfanos, edges = _resolver_grafo_dependencias(archivos, main_rel)

    # Analisis individual de cada archivo VINCULADO (el main y todo lo que importa)
    detalle_archivos = {}
    for rel in vinculados:
        detalle_archivos[rel] = analizar_python(archivos[rel], nombre=rel)

    # Analisis tambien de huerfanos, pero no pesan igual en el score global
    for rel in huerfanos:
        detalle_archivos[rel] = analizar_python(archivos[rel], nombre=rel)

    # Analizar también los archivos de test (para mostrarlos en el detalle), pero
    # sin que entren en vinculados ni en el score del proyecto: los tests se
    # revisan pero no van a producción, así que no bajan el score ni bloquean.
    def _es_test_rel(p):
        pl = p.replace("\\", "/").lower()
        b = os.path.basename(pl)
        return (b.startswith("test_") or b.endswith("_test.py")
                or b == "conftest.py" or "/tests/" in pl or pl.startswith("tests/"))
    archivos_test = [r for r in archivos if _es_test_rel(r) and r not in detalle_archivos]
    for rel in archivos_test:
        detalle_archivos[rel] = analizar_python(archivos[rel], nombre=rel)

    # BP-07 (tamaño de script) en el MAIN: si el proyecto ya esta modularizado
    # (main + al menos otro archivo vinculado, ej. preprocessing.py, scoring.py,
    # utils.py), un main.py largo no es necesariamente "todo mezclado" — puede
    # ser solo la orquestacion. Se ablanda a informativo y no resta puntos.
    if len(vinculados) > 1 and main_rel in detalle_archivos:
        bps_main = detalle_archivos[main_rel]["buenas_practicas"]
        for c in bps_main:
            if c.get("regla") == "BP-07" and c.get("sev") == "AVISO":
                c["sev"] = "OK"
                c["msg"] = c["msg"] + " (Verificar si corresponde — el proyecto ya está modularizado en otros archivos)"
                detalle_archivos[main_rel]["score"] = min(100, detalle_archivos[main_rel]["score"] + 10)
                # Recalcular el veredicto de ese archivo con el score ya corregido
                detalle_archivos[main_rel]["veredicto"] = _veredicto(
                    detalle_archivos[main_rel]["score"],
                    forzar_no_aprobado=_tiene_criticos_personalizados(bps_main)
                )

    # ── Score agregado ──
    # El main pesa mas fuerte (40%), el resto de los vinculados se promedia (60%)
    score_main = detalle_archivos[main_rel]["score"]
    otros_vinculados = [detalle_archivos[r]["score"] for r in vinculados if r != main_rel]
    score_resto = sum(otros_vinculados) / len(otros_vinculados) if otros_vinculados else score_main

    score_base = round(score_main * 0.4 + score_resto * 0.6) if otros_vinculados else score_main

    checks_estructura, bonus_estructura = _checks_estructura_proyecto(archivos, md_files, huerfanos, otros_files, tree_paths=tree_paths)
    checks_estructura, ajuste_estructura = _aplicar_overrides(checks_estructura)
    bonus_estructura += ajuste_estructura

    # ── Techo por hallazgos de código ──
    # El bonus de estructura (buen README, carpetas ordenadas, etc.) NO puede
    # tapar errores de código. Regla de Gobierno de Datos: un proyecto llega a
    # 100 SOLO si no hay nada que ajustar. Si hay algún ERROR o AVISO en un
    # archivo de PRODUCCIÓN (no test) o en la estructura, el score queda por
    # debajo de 100 de forma proporcional, aunque la estructura sea perfecta.
    # Los tests se muestran pero no cuentan para el techo ni bloquean.
    todos_los_checks = list(checks_estructura)
    for rel, info in detalle_archivos.items():
        if _es_test_rel(rel):
            continue
        todos_los_checks.extend(info.get("buenas_practicas", []))
    n_errores = sum(1 for c in todos_los_checks if c.get("sev") == "ERROR")
    n_avisos = sum(1 for c in todos_los_checks if c.get("sev") == "AVISO")

    score_final = max(0, min(100, score_base + bonus_estructura))

    if n_errores or n_avisos:
        # Techo estricto: con hallazgos abiertos no se puede mostrar 100.
        # Cada ERROR pesa como -8 y cada AVISO como -3 sobre el techo, para que
        # el número refleje cuántos ajustes faltan, no solo la estructura.
        techo = 100 - (n_errores * 8 + n_avisos * 3)
        techo = max(50, min(99, techo))  # nunca baja de 50 solo por esto, nunca llega a 100
        score_final = min(score_final, techo)

    hay_criticos = _tiene_criticos_personalizados(checks_estructura) or any(
        _tiene_criticos_personalizados(info["buenas_practicas"])
        for rel, info in detalle_archivos.items() if not _es_test_rel(rel)
    )
    veredicto = _veredicto(score_final, forzar_no_aprobado=hay_criticos)

    # Justificacion: cuando no aprueba, listar las razones concretas
    # (primero los hallazgos CRITICOS personalizados, despues ERROR, despues AVISO)
    justificacion = []
    if not veredicto["aprobado"]:
        todas = list(checks_estructura)
        for rel in vinculados:
            todas.extend(detalle_archivos[rel]["buenas_practicas"])
        criticos = [c for c in todas if c.get("critico_personalizado")]
        errores = [c for c in todas if c["sev"] == "ERROR" and not c.get("critico_personalizado")]
        avisos = [c for c in todas if c["sev"] == "AVISO" and not c.get("critico_personalizado")]
        malas = criticos + errores + avisos
        justificacion = [f'[{c["regla"]}]{"  CRÍTICO —" if c.get("critico_personalizado") else ""} {c["msg"]}' for c in malas[:10]]

    # Validación visual de la estructura documentada en el README contra la real.
    _todos_nombres_proy = list(archivos) + list(md_files) + list(otros_files) + list(tree_paths or [])
    estructura_readme = _validar_estructura_readme(md_files, _todos_nombres_proy)

    return {
        "main": main_rel,
        "score": score_final,
        "score_main": score_main,
        "score_resto_vinculados": round(score_resto),
        "bonus_estructura": bonus_estructura,
        "veredicto": veredicto,
        "justificacion": justificacion,
        "vinculados": sorted(vinculados),
        "huerfanos": huerfanos,
        "dependencias": [{"origen": o, "destino": d} for o, d in edges],
        "md_files": sorted(md_files.keys()),
        "otros_files": sorted(otros_files.keys()),
        "checks_estructura": checks_estructura,
        "estructura_readme": estructura_readme,
        "archivos": {
            rel: {
                "score": det["score"],
                "tipo": det["tipo"],
                "tags": det["tags"],
                "lineas": det["lineas"],
                "es_vinculado": rel in vinculados,
                "buenas_practicas": det["buenas_practicas"],
                "ml_info": det["ml_info"],
            }
            for rel, det in detalle_archivos.items()
        },
    }


def ejecutar_python(codigo, timeout=120, args=""):
    """Ejecuta código Python en subprocess y retorna métricas."""
    exec_id = str(uuid.uuid4())[:8]
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Write script to temp
    script_path = RESULTS_DIR / f"exec_{exec_id}.py"
    script_path.write_text(codigo, encoding="utf-8")

    result = {
        "exec_id": exec_id,
        "timestamp": ts,
        "estado": "running",
        "salida": "",
        "errores": "",
        "duracion_ms": 0,
        "codigo_retorno": None,
        "metricas": {},
    }

    _executions[exec_id] = result

    start = time.time()
    try:
        cmd = ["python3", str(script_path)]
        if args.strip():
            cmd.extend(args.strip().split())

        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(RESULTS_DIR),
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )
        elapsed = (time.time() - start) * 1000

        result.update({
            "estado": "ok" if proc.returncode == 0 else "error",
            "salida": proc.stdout[-50000:] if proc.stdout else "",
            "errores": proc.stderr[-10000:] if proc.stderr else "",
            "duracion_ms": round(elapsed, 2),
            "codigo_retorno": proc.returncode,
            "metricas": {
                "duracion_s": round(elapsed / 1000, 3),
                "stdout_lines": len(proc.stdout.splitlines()) if proc.stdout else 0,
                "stderr_lines": len(proc.stderr.splitlines()) if proc.stderr else 0,
            },
        })
    except subprocess.TimeoutExpired:
        elapsed = (time.time() - start) * 1000
        result.update({
            "estado": "timeout",
            "errores": f"Tiempo excedido ({timeout}s)",
            "duracion_ms": round(elapsed, 2),
        })
    except Exception as e:
        elapsed = (time.time() - start) * 1000
        result.update({
            "estado": "error",
            "errores": str(e),
            "duracion_ms": round(elapsed, 2),
        })
    finally:
        # Clean up temp script
        try:
            script_path.unlink(missing_ok=True)
        except:
            pass

    # Save to DB
    try:
        with _db() as conn:
            conn.execute("""
                INSERT INTO python_ejecuciones
                (script_id, fecha, timestamp, duracion_ms, estado, salida, errores, metricas)
                VALUES (?,?,?,?,?,?,?,?)
            """, (None, ts[:10], ts, result["duracion_ms"], result["estado"],
                  result["salida"][:50000], result["errores"][:10000],
                  json.dumps(result["metricas"])))
            conn.commit()
    except:
        pass

    return result


# ── Rutas Flask — Python & ML ──

@app.route("/python")
@login_required
def python_home():
    # Load saved scripts
    with _db() as conn:
        scripts = [dict(r) for r in conn.execute(
            "SELECT * FROM python_scripts ORDER BY id DESC LIMIT 50").fetchall()]
        ejecuciones = [dict(r) for r in conn.execute(
            "SELECT * FROM python_ejecuciones ORDER BY id DESC LIMIT 30").fetchall()]
    return render_template("python_ml.html", scripts=scripts, ejecuciones=ejecuciones)


@app.route("/api/python/tree")
@login_required
def api_python_tree():
    """Árbol de directorios del servidor Pentaho — solo archivos .py, excluye venv/__pycache__/.git."""
    prune = " -o ".join(f'-name "{d}" -prune' for d in IGNORE_DIRS)
    cmd = (f'find {_PROOT} \\( {prune} \\) -prune -o -type f -name "*.py" -print '
           '2>/dev/null | sort')
    out, ok = _run(cmd)
    if not ok or not out.strip():
        return jsonify({"name":"project","type":"folder","path":_PROOT,"children":[]})
    paths = [p.strip() for p in out.splitlines() if p.strip()]
    return jsonify(_tree_from_paths(paths, _PROOT))


@app.route("/api/python/load_remote")
@login_required
def api_python_load_remote():
    """Lee un archivo .py remoto del servidor Pentaho."""
    path = request.args.get("path","").strip()
    if not path:
        return jsonify({"error":"Sin ruta"}), 400
    if not path.endswith(".py"):
        return jsonify({"error":"Solo archivos .py"}), 400
    # Security: must be under _PROOT
    if not path.startswith(_PROOT):
        return jsonify({"error":"Ruta fuera del directorio permitido"}), 403
    content = _read_content(path)
    if not content:
        return jsonify({"error":"No se pudo leer el archivo"}), 404
    return jsonify({
        "path": path,
        "nombre": os.path.basename(path),
        "carpeta": os.path.dirname(path).replace(_PROOT,"").lstrip("/") or ".",
        "codigo": content,
        "lineas": len(content.splitlines()),
    })


@app.route("/api/python/analyze", methods=["POST"])
@login_required
def api_python_analyze():
    """Analiza código Python sin ejecutarlo (un solo archivo)."""
    data = request.get_json(force=True)
    codigo = data.get("codigo", "")
    nombre = (data.get("nombre") or "script.py").strip()
    origen = data.get("origen", "local")
    responsable_proyecto = data.get("responsable_proyecto")
    if not codigo.strip():
        return jsonify({"error": "Sin código para analizar"}), 400
    try:
        analisis = analizar_python(codigo, nombre=nombre)
        analisis["responsable_proyecto"] = (responsable_proyecto or "").strip() or None
        try:
            _guardar_historial_analisis("archivo", nombre, analisis, origen, responsable_proyecto)
        except Exception as e:
            app.logger.error("No se pudo guardar historial de analisis: %s", e)
        return jsonify(analisis)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/python/tree_folder")
@login_required
def api_python_tree_folder():
    """
    Trae TODOS los .py, .md y archivos de configuracion relevantes
    (requirements.txt, .gitignore, pyproject.toml, etc.) de la carpeta
    (y subcarpetas) donde vive un archivo del servidor Pentaho, para
    poder resolver el proyecto completo en un solo viaje.
    """
    path = request.args.get("path", "").strip()
    if not path:
        return jsonify({"error": "Sin ruta"}), 400
    if not path.startswith(_PROOT):
        return jsonify({"error": "Ruta fuera del directorio permitido"}), 403

    # OJO: antes esto usaba directamente os.path.dirname(path), es decir, la
    # carpeta que contiene al archivo 'main' clickeado. Si el main vive en una
    # subcarpeta (ej. .../mi_proyecto/src/main.py), eso hacía que 'carpeta'
    # quedara en '.../mi_proyecto/src' — un nivel más ADENTRO que la raíz real
    # del proyecto. Los archivos hermanos (README.md, requirements.txt,
    # scripts sueltos en la raíz) quedaban con una ruta relativa completamente
    # distinta a la de los archivos de 'src/', y las comparaciones de imports
    # dejaban de coincidir aunque el código sí estuviera bien importado.
    # Si el 'main' está en una carpeta llamada src/ (u otra típica de paquete),
    # se sube un nivel para usar como raíz la carpeta del PROYECTO, no la del
    # paquete interno.
    carpeta_main = os.path.dirname(path)
    NOMBRES_CARPETA_PAQUETE = {"src", "source", "app", "lib"}
    if os.path.basename(carpeta_main) in NOMBRES_CARPETA_PAQUETE:
        carpeta = os.path.dirname(carpeta_main)
    else:
        carpeta = carpeta_main

    prune = " -o ".join(f'-name "{d}" -prune' for d in IGNORE_DIRS)
    nombres_otros = ["*.txt", "*.toml", "*.yml", "*.yaml", "*.cfg", "*.ini",
                      ".gitignore", "Pipfile", ".env.example"]
    filtro_otros = " -o ".join(f'-name "{n}"' for n in nombres_otros)
    marker_cmd = (
        f'find "{carpeta}" \\( {prune} \\) -prune -o -type f '
        f'\\( -name "*.py" -o -name "*.md" -o {filtro_otros} \\) -print0 2>/dev/null | '
        f'xargs -0 -I{{}} sh -c \'echo "===FILE_START==={{}}"; cat "{{}}"; echo "===FILE_END==="\''
    )
    out, ok = _run(marker_cmd)
    if not ok:
        return jsonify({"error": "No se pudo leer la carpeta del servidor"}), 500

    archivos = {}
    md_files = {}
    otros_files = {}
    partes = out.split("===FILE_START===")
    for parte in partes[1:]:
        if "===FILE_END===" not in parte:
            continue
        header, resto = parte.split("\n", 1)
        contenido = resto.rsplit("===FILE_END===", 1)[0]
        fp = header.strip()
        rel = fp.replace(carpeta, "").lstrip("/")
        if fp.endswith(".md"):
            md_files[rel] = contenido
        elif fp.endswith(".py"):
            archivos[rel] = contenido
        else:
            otros_files[rel] = contenido[:2000]  # solo hace falta confirmar existencia/inicio

    main_rel = path.replace(carpeta, "").lstrip("/")
    return jsonify({"carpeta": carpeta, "main": main_rel, "archivos": archivos,
                     "md_files": md_files, "otros_files": otros_files})


@app.route("/api/python/analyze_project", methods=["POST"])
@login_required
def api_python_analyze_project():
    """
    Analiza un PROYECTO completo (varios archivos .py + .md + config), a partir
    del archivo 'main' (entry point) — sigue sus imports locales para
    saber que otros archivos estan realmente vinculados, y da un score
    y veredicto a nivel de proyecto (no solo del archivo suelto).
    Body JSON: { "main": "app.py", "archivos": {"app.py": "...", "utils.py": "..."},
                 "md_files": {"README.md": "..."}, "otros_files": {"requirements.txt": "..."} }
    """
    data = request.get_json(force=True) or {}
    archivos = data.get("archivos") or {}
    md_files = data.get("md_files") or {}
    otros_files = data.get("otros_files") or {}
    tree_paths = data.get("tree_paths") or []
    main_rel = (data.get("main") or "").strip()
    origen = data.get("origen", "local")
    responsable_proyecto = data.get("responsable_proyecto")
    nombre_proyecto_declarado = (data.get("nombre_proyecto_declarado") or "").strip()

    if not archivos:
        return jsonify({"error": "Sin archivos para analizar"}), 400
    if not main_rel:
        return jsonify({"error": "No se especifico el archivo principal (main)"}), 400
    if main_rel not in archivos:
        return jsonify({"error": f"El main '{main_rel}' no esta entre los archivos enviados"}), 400

    try:
        resultado = analizar_proyecto(archivos, main_rel, md_files, otros_files, tree_paths=tree_paths)
        resultado["responsable_proyecto"] = (responsable_proyecto or "").strip() or None
        resultado["nombre_proyecto_declarado"] = nombre_proyecto_declarado or None
        # El historial se agrupa por el nombre de proyecto DECLARADO por el
        # usuario (si lo dio) en vez del path del main.py — asi el control
        # historico no se corta si el main cambia de carpeta/nombre entre
        # corridas del mismo proyecto.
        nombre_historial = nombre_proyecto_declarado or main_rel
        analisis_id = None
        try:
            analisis_id = _guardar_historial_analisis("proyecto", nombre_historial, resultado, origen, responsable_proyecto)
        except Exception as e:
            app.logger.error("No se pudo guardar historial de analisis de proyecto: %s", e)
        resultado["analisis_id"] = analisis_id
        return jsonify(resultado)
    except Exception as e:
        app.logger.error("Error analizando proyecto: %s", e)
        return jsonify({"error": str(e)}), 500


@app.route("/api/python/export_json", methods=["POST"])
@login_required
def api_python_export_json():
    """
    Exporta crudo (hallazgos + scoring completo) el resultado de un analisis
    ya calculado en el navegador — sirve tanto para 'archivo unico' como para
    'proyecto'. El cliente manda de vuelta el mismo JSON que le devolvimos
    antes en /analyze o /analyze_project, para no tener que recalcular nada.
    Body JSON: { "modo": "archivo"|"proyecto", "nombre": "...", "data": {...} }
    """
    body = request.get_json(force=True) or {}
    data = body.get("data") or {}
    modo = body.get("modo", "archivo")
    nombre_base = re.sub(r'[^\w\-\.]', '_', body.get("nombre") or "analisis")

    paquete = {
        "generado": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "generado_por": session.get("nombre") or session.get("usuario") or "desconocido",
        "modo": modo,
        "resultado": data,
    }
    buf = io.BytesIO(json.dumps(paquete, ensure_ascii=False, indent=2).encode("utf-8"))
    nombre = f"analisis_{modo}_{nombre_base}_{datetime.now().strftime('%Y%m%d_%H%M')}.json"
    return send_file(buf, mimetype="application/json", as_attachment=True, download_name=nombre)


@app.route("/api/python/export_pdf", methods=["POST"])
@login_required
def api_python_export_pdf():
    """
    Exporta a PDF (mismo estilo visual que el historial de implementaciones)
    el resultado completo de un analisis de codigo Python — archivo unico o
    proyecto completo — con TODOS los checks (cumplidos y no), su porque
    importa, su impacto, y la recomendacion de arreglo cuando corresponde.
    Body JSON: { "modo": "archivo"|"proyecto", "nombre": "...", "data": {...} }
    """
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import cm
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, KeepTogether
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.pdfgen import canvas as _canvas_mod
    except ImportError:
        return jsonify({"ok": False, "error": "Falta instalar 'reportlab' en el servidor. "
                         "Corré: pip install -r requirements.txt --break-system-packages "
                         "y reiniciá el servicio."}), 500

    body = request.get_json(force=True) or {}
    data = body.get("data") or {}
    modo = body.get("modo", "archivo")
    nombre_archivo = body.get("nombre") or (data.get("main") if modo == "proyecto" else "script.py")

    try:
        NAVY   = colors.HexColor("#16324a")
        CORAL  = colors.HexColor("#c96a4e")
        LIGHT_BG  = colors.HexColor("#f6f4f1")
        GRID_GRAY = colors.HexColor("#dedad3")
        GREEN_BG  = colors.HexColor("#e8f3ea"); GREEN_TXT = colors.HexColor("#2f6b41")
        AMBER_BG  = colors.HexColor("#fbf1de"); AMBER_TXT = colors.HexColor("#8a5b09")
        RED_BG    = colors.HexColor("#f8e9e6"); RED_TXT   = colors.HexColor("#a43d27")
        GRAY_TXT  = colors.HexColor("#6b675f")

        styles = getSampleStyleSheet()
        celda        = ParagraphStyle("celda", parent=styles["Normal"], fontSize=8.3, leading=11)
        celda_bold   = ParagraphStyle("celda_bold", parent=celda, fontName="Helvetica-Bold", textColor=colors.white)
        celda_detalle = ParagraphStyle("celda_detalle", parent=celda, fontSize=7.7, leading=10, textColor=GRAY_TXT)
        meta_valor   = ParagraphStyle("meta_valor", parent=styles["Normal"], fontSize=8.6,
                                       fontName="Helvetica-Bold", textColor=NAVY)
        banner_title = ParagraphStyle("banner_title", parent=styles["Normal"], fontSize=19,
                                       fontName="Helvetica-Bold", textColor=colors.white, leading=23)
        banner_sub   = ParagraphStyle("banner_sub", parent=styles["Normal"], fontSize=9.3,
                                       textColor=colors.HexColor("#d7dee6"))
        kpi_num      = ParagraphStyle("kpi_num", parent=styles["Normal"], fontSize=21, leading=25,
                                       fontName="Helvetica-Bold", alignment=1)
        kpi_label    = ParagraphStyle("kpi_label", parent=styles["Normal"], fontSize=7.6, leading=9.5,
                                       textColor=GRAY_TXT, alignment=1)
        seccion_h    = ParagraphStyle("seccion_h", parent=styles["Normal"], fontSize=11.5,
                                       fontName="Helvetica-Bold", textColor=NAVY, spaceBefore=4, spaceAfter=6)
        archivo_h    = ParagraphStyle("archivo_h", parent=styles["Normal"], fontSize=9.5,
                                       fontName="Helvetica-Bold", textColor=NAVY, spaceBefore=6, spaceAfter=3)
        justif_item  = ParagraphStyle("justif_item", parent=styles["Normal"], fontSize=8.5, leading=11,
                                       textColor=RED_TXT)
        leyenda_txt  = ParagraphStyle("leyenda", parent=styles["Normal"], fontSize=7.8, textColor=GRAY_TXT)

        ahora = datetime.now()
        usuario_actual = session.get("nombre") or session.get("usuario") or "desconocido"
        id_reporte = f"PY-{ahora.strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6].upper()}"

        ancho_pagina_pts = A4[0]
        ancho_util_cm = (ancho_pagina_pts / cm) - 2.6

        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=A4,
                                 leftMargin=1.3*cm, rightMargin=1.3*cm, topMargin=1.1*cm, bottomMargin=1.6*cm,
                                 title="Análisis de código Python — ETL Governance Portal",
                                 author="Willian Arce — Gobierno de Datos, Banco Continental")

        # ── Banner ──
        responsable_proyecto_pdf = (data.get("responsable_proyecto") or "").strip()
        linea_responsable = f" &nbsp;·&nbsp; Analista/Desarrollador responsable: {esc_pdf(responsable_proyecto_pdf)}" if responsable_proyecto_pdf else ""
        banner = Table([[
            Paragraph("ETL GOVERNANCE PORTAL &nbsp;·&nbsp; BANCO CONTINENTAL", banner_sub),
        ], [
            Paragraph("Análisis de Código Python" + (" — Proyecto" if modo == "proyecto" else ""), banner_title),
        ], [
            Paragraph(f"{esc_pdf(nombre_archivo)} &nbsp;·&nbsp; Generado el {ahora.strftime('%Y-%m-%d %H:%M')} por {esc_pdf(usuario_actual)} &nbsp;·&nbsp; ID {id_reporte}{linea_responsable}", banner_sub),
        ]], colWidths=[ancho_util_cm*cm])
        banner.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), NAVY),
            ("LEFTPADDING", (0, 0), (-1, -1), 16), ("RIGHTPADDING", (0, 0), (-1, -1), 16),
            ("TOPPADDING", (0, 0), (-1, 0), 10), ("BOTTOMPADDING", (0, 0), (-1, 0), 2),
            ("TOPPADDING", (0, 1), (-1, 1), 2), ("BOTTOMPADDING", (0, 1), (-1, 1), 4),
            ("TOPPADDING", (0, 2), (-1, 2), 2), ("BOTTOMPADDING", (0, 2), (-1, 2), 10),
        ]))
        elementos = [banner, Spacer(1, 12)]

        def _tarjeta(valor, etiqueta, bg, txt, ancho_frac=4, valor_fontsize=None):
            fs = valor_fontsize or 21
            estilo_valor = ParagraphStyle("n_" + str(fs), parent=kpi_num, fontSize=fs, leading=fs + 4, textColor=txt)
            t = Table([[Paragraph(str(valor), estilo_valor)],
                       [Paragraph(etiqueta, kpi_label)]], colWidths=[ancho_util_cm/ancho_frac*cm])
            t.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), bg),
                ("TOPPADDING", (0, 0), (-1, 0), 9), ("BOTTOMPADDING", (0, 0), (-1, 0), 2),
                ("TOPPADDING", (0, 1), (-1, 1), 0), ("BOTTOMPADDING", (0, 1), (-1, 1), 9),
                ("BOX", (0, 0), (-1, -1), 0.5, GRID_GRAY),
            ]))
            return t

        def _color_score(score):
            if score <= 50: return (RED_BG, RED_TXT)
            if score <= 75: return (AMBER_BG, AMBER_TXT)
            return (GREEN_BG, GREEN_TXT)

        def _color_veredicto(veredicto):
            """A diferencia de _color_score, este deriva el color del VEREDICTO
            ya calculado (que puede estar forzado a no-aprobado por un hallazgo
            critico personalizado aunque el score numerico sea alto) — para que
            la tarjeta de color nunca contradiga al veredicto mostrado al lado."""
            nivel = (veredicto or {}).get("nivel")
            if nivel == "requiere_ajustes": return (RED_BG, RED_TXT)
            if nivel == "observaciones": return (AMBER_BG, AMBER_TXT)
            return (GREEN_BG, GREEN_TXT)

        def _color_sev(sev):
            return {"OK": (GREEN_BG, GREEN_TXT, "Cumple"),
                    "AVISO": (AMBER_BG, AMBER_TXT, "Cumple parcial"),
                    "ERROR": (RED_BG, RED_TXT, "No cumple")}.get(sev, (LIGHT_BG, GRAY_TXT, sev))

        def _label_estado(c):
            """Devuelve el texto de estado, marcando explicitamente CRITICO
            para las reglas personalizadas (BP-01/03/08/18, ML-11) cuando
            estan en ERROR — no solo 'No cumple' generico.
            Sin emoji: Helvetica (fuente base de reportlab) no los soporta
            y los muestra como un cuadrado vacio."""
            if c.get("critico_personalizado"):
                return "CRÍTICO"
            _, _, label = _color_sev(c.get("sev"))
            return label

        veredicto_doc = data.get("veredicto") or {}

        if modo == "proyecto":
            score = data.get("score", 0)
            bg, txt = _color_veredicto(veredicto_doc)
            anchos_kpi = [0.20, 0.36, 0.22, 0.22]  # Score / Resultado (mas ancho, es texto) / Vinculados / Huerfanos
            fracs_kpi = [1/a for a in anchos_kpi]
            tarjetas = Table([[
                _tarjeta(score, "Score de proyecto", bg, txt, ancho_frac=fracs_kpi[0]),
                _tarjeta(veredicto_doc.get("label", "-"), "Resultado", bg, txt, ancho_frac=fracs_kpi[1], valor_fontsize=13),
                _tarjeta(len(data.get("vinculados", [])), "Archivos vinculados", LIGHT_BG, NAVY, ancho_frac=fracs_kpi[2]),
                _tarjeta(len(data.get("huerfanos", [])), "Huérfanos", AMBER_BG if data.get("huerfanos") else LIGHT_BG,
                          AMBER_TXT if data.get("huerfanos") else NAVY, ancho_frac=fracs_kpi[3]),
            ]], colWidths=[ancho_util_cm*a*cm for a in anchos_kpi])
        else:
            score = data.get("score", 0)
            bg, txt = _color_veredicto(veredicto_doc) if veredicto_doc else _color_score(score)
            anchos_kpi = [0.20, 0.20, 0.20, 0.20]
            tarjetas = Table([[
                _tarjeta(score, "Score", bg, txt),
                _tarjeta(data.get("lineas", 0), "Líneas", LIGHT_BG, NAVY),
                _tarjeta(len(data.get("funciones", [])), "Funciones", LIGHT_BG, NAVY),
                _tarjeta(len(data.get("imports", [])), "Imports", LIGHT_BG, NAVY),
            ]], colWidths=[ancho_util_cm/4*cm]*4)

        tarjetas.setStyle(TableStyle([
            ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        elementos += [tarjetas, Spacer(1, 10)]

        # ── 1. Resultado del análisis (siempre visible, coherente con el color de arriba) ──
        if veredicto_doc:
            bg_v, txt_v = _color_veredicto(veredicto_doc)
            if modo == "proyecto":
                todos_los_checks = list(data.get("checks_estructura", [])) + [
                    c for info in data.get("archivos", {}).values() for c in info.get("buenas_practicas", [])
                ]
            else:
                todos_los_checks = data.get("buenas_practicas", [])
            hay_criticos = any(c.get("critico_personalizado") for c in todos_los_checks)

            if hay_criticos:
                texto_veredicto = (
                    f'<b>1. Resultado del análisis: {esc_pdf(veredicto_doc.get("label",""))}</b><br/>'
                    f'Este {"proyecto" if modo == "proyecto" else "archivo"} tiene al menos un hallazgo marcado '
                    f'como CRÍTICO — se requiere ajustarlo antes de continuar con el pase a producción '
                    f'(score: {score}/100). Ver la sección de justificación y recomendaciones para el detalle de qué corregir.'
                )
            else:
                texto_veredicto = (
                    f'<b>1. Resultado del análisis: {esc_pdf(veredicto_doc.get("label",""))}</b><br/>'
                    f'Score {score}/100 — {esc_pdf(veredicto_doc.get("label",""))}.'
                )

            caja_veredicto = Table([[Paragraph(texto_veredicto, ParagraphStyle("vf", parent=celda, fontSize=9.5, leading=13, textColor=txt_v))]],
                                    colWidths=[ancho_util_cm*cm])
            caja_veredicto.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), bg_v),
                ("BOX", (0, 0), (-1, -1), 0.5, GRID_GRAY),
                ("TOPPADDING", (0, 0), (-1, -1), 8), ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                ("LEFTPADDING", (0, 0), (-1, -1), 12), ("RIGHTPADDING", (0, 0), (-1, -1), 12),
            ]))
            elementos.append(caja_veredicto)
            elementos.append(Spacer(1, 10))

        # ── Leyenda ──
        elementos.append(Paragraph(
            '<font color="#2f6b41">●</font> Cumple &nbsp;&nbsp; '
            '<font color="#8a5b09">●</font> Cumple parcial / aviso &nbsp;&nbsp; '
            '<font color="#a43d27">●</font> No cumple &nbsp;&nbsp; '
            '<font color="#a43d27"><b>CRÍTICO</b></font> = regla con criterio de escalado especial, bloquea la aprobación aunque el score sea alto',
            leyenda_txt))
        elementos.append(Spacer(1, 10))

        # ── 2. Justificación (cuando no aprueba) ──
        if modo == "proyecto" and not veredicto_doc.get("aprobado", True):
            elementos.append(Paragraph("2. Justificación — ajustes requeridos", seccion_h))
            for j in data.get("justificacion", []):
                elementos.append(Paragraph("• " + esc_pdf(j), justif_item))
            elementos.append(Spacer(1, 10))

        # ── Tabla de checks completa (TODOS: cumplen y no) ──
        def _celda_detalle(c):
            partes = []
            if c.get("lineas"):
                partes.append(f"<b>Líneas:</b> " + ", ".join(f"L{n}" for n in c["lineas"][:8]))
            if c.get("codigo_real"):
                codigo_html = esc_pdf(c["codigo_real"]).replace("\n", "<br/>")
                partes.append(f'<b>Encontrado en tu código:</b><br/><font face="Courier" size="7" color="#a43d27">{codigo_html}</font>')
            if c.get("por_que"):
                partes.append(f"<b>Por qué importa:</b> {esc_pdf(c['por_que'])}")
            if c.get("impacto"):
                partes.append(f"<b>Impacto:</b> {esc_pdf(c['impacto'])}")
            if c.get("rec"):
                partes.append(f"<b>Recomendación:</b> {esc_pdf(c['rec'])}")
            if c.get("ejemplo"):
                ejemplo_html = esc_pdf(c["ejemplo"]).replace("\n", "<br/>")
                etiqueta_ejemplo = "Ejemplo genérico de la regla" if c.get("codigo_real") else "Ejemplo"
                partes.append(f'<b>{etiqueta_ejemplo}:</b><br/><font face="Courier" size="7">{ejemplo_html}</font>')
            return "<br/>".join(partes) if partes else "—"

        def _tabla_grupo(subtitulo, color_sub, checks_grupo):
            """Tabla completa (con detalle) para un grupo de severidad."""
            if not checks_grupo:
                return
            elementos.append(Paragraph(subtitulo, ParagraphStyle("subt", parent=meta_valor, textColor=color_sub, fontSize=9.5)))
            encabezado = [Paragraph(h, celda_bold) for h in ["Regla", "Estado", "Práctica", "Hallazgo y recomendación"]]
            filas = [encabezado]
            for c in checks_grupo:
                bg_sev, txt_sev, _ = _color_sev(c.get("sev"))
                label_sev = _label_estado(c)
                filas.append([
                    Paragraph(c.get("regla", ""), celda),
                    Paragraph(label_sev, ParagraphStyle("estado_" + c.get("regla",""), parent=celda, textColor=txt_sev, fontName="Helvetica-Bold")),
                    Paragraph(esc_pdf(c.get("nombre") or c.get("msg", "")), celda),
                    Paragraph(_celda_detalle(c) + ("<br/><i>" + esc_pdf(c["msg"]) + "</i>" if c.get("nombre") else ""), celda_detalle),
                ])
            t = Table(filas, repeatRows=1, colWidths=[1.6*cm, 2.3*cm, 3.8*cm, ancho_util_cm*cm - 7.7*cm])
            estilo = [
                ("BACKGROUND", (0, 0), (-1, 0), CORAL),
                ("GRID", (0, 0), (-1, -1), 0.4, GRID_GRAY),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
            for i, c in enumerate(checks_grupo, start=1):
                bg_sev, _, _ = _color_sev(c.get("sev"))
                estilo.append(("BACKGROUND", (1, i), (1, i), bg_sev))
            t.setStyle(TableStyle(estilo))
            elementos.append(t)
            elementos.append(Spacer(1, 12))

        def _tabla_checks_completa(titulo, checks):
            """
            Separa los checks en 3 bloques, en este orden:
            1) No cumple / CRITICO (con detalle completo) — lo mas importante primero.
            2) Cumple parcial / aviso (con detalle completo).
            3) Cumple — lista compacta (solo regla + practica), sin repetir todo
               el por-que/impacto para no alargar el documento con lo que ya esta bien.
            """
            if not checks:
                return
            elementos.append(Paragraph(titulo, seccion_h))

            criticos = [c for c in checks if c.get("sev") == "ERROR"]
            criticos.sort(key=lambda c: 0 if c.get("critico_personalizado") else 1)
            avisos = [c for c in checks if c.get("sev") == "AVISO"]
            cumplen = [c for c in checks if c.get("sev") == "OK"]

            _tabla_grupo(f"✗ No cumple ({len(criticos)})", RED_TXT, criticos)
            _tabla_grupo(f"! Cumple parcial ({len(avisos)})", AMBER_TXT, avisos)

            if cumplen:
                elementos.append(Paragraph(f"✓ Cumple ({len(cumplen)})", ParagraphStyle("subtok", parent=meta_valor, textColor=GREEN_TXT, fontSize=9.5)))
                filas_ok = [[Paragraph(h, celda_bold) for h in ["Regla", "Práctica", "Detalle"]]]
                for c in cumplen:
                    filas_ok.append([
                        Paragraph(c.get("regla", ""), celda),
                        Paragraph(esc_pdf(c.get("nombre") or ""), celda),
                        Paragraph(esc_pdf(c.get("msg", "")), celda_detalle),
                    ])
                t_ok = Table(filas_ok, repeatRows=1, colWidths=[1.6*cm, 4.5*cm, ancho_util_cm*cm - 6.1*cm])
                t_ok.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, 0), GREEN_BG),
                    ("GRID", (0, 0), (-1, -1), 0.4, GRID_GRAY),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ]))
                elementos.append(t_ok)
                elementos.append(Spacer(1, 12))

        if modo == "archivo":
            _tabla_checks_completa("3. Buenas prácticas — detalle completo", data.get("buenas_practicas", []))

            if data.get("ml_info"):
                ml = data["ml_info"]
                items = [
                    ("Train/Test split", ml.get("tiene_train_test_split")), ("Cross-validation", ml.get("tiene_cross_validation")),
                    ("Pipeline sklearn", ml.get("tiene_pipeline")), ("Métricas de evaluación", ml.get("tiene_metricas")),
                    ("Escalado de features", ml.get("tiene_scaler")), ("Serialización (joblib/pickle)", ml.get("tiene_pickle_joblib")),
                    ("Interpretabilidad (SHAP/importancia)", ml.get("tiene_feature_importance")),
                    ("Tracking de experimentos", ml.get("tiene_logging") or ml.get("tiene_mlflow")),
                    ("Optimización de hiperparámetros", ml.get("tiene_grid_search")), ("Early stopping", ml.get("tiene_early_stopping")),
                ]
                elementos.append(Paragraph("4. Checks de Machine Learning", seccion_h))
                filas_ml = [[Paragraph(h, celda_bold) for h in ["Práctica", "Estado"]]]
                for label, ok in items:
                    bg_sev, txt_sev, label_sev = (GREEN_BG, GREEN_TXT, "Cumple") if ok else (AMBER_BG, AMBER_TXT, "No detectado")
                    filas_ml.append([Paragraph(label, celda), Paragraph(label_sev, celda)])
                t_ml = Table(filas_ml, repeatRows=1, colWidths=[ancho_util_cm*cm - 3*cm, 3*cm])
                estilo_ml = [
                    ("BACKGROUND", (0, 0), (-1, 0), CORAL),
                    ("GRID", (0, 0), (-1, -1), 0.4, GRID_GRAY),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]
                for i, (label, ok) in enumerate(items, start=1):
                    bg_sev = GREEN_BG if ok else AMBER_BG
                    estilo_ml.append(("BACKGROUND", (1, i), (1, i), bg_sev))
                t_ml.setStyle(TableStyle(estilo_ml))
                elementos.append(t_ml)
                elementos.append(Spacer(1, 12))

        else:
            _tabla_checks_completa("3. Checks de estructura de proyecto", data.get("checks_estructura", []))

            archivos_dict = data.get("archivos", {})
            if archivos_dict:
                elementos.append(Paragraph("4. Score por archivo", seccion_h))
                filas = [[Paragraph(h, celda_bold) for h in ["Archivo", "Score", "Vinculado", "Líneas", "Tags"]]]
                for rel, info in sorted(archivos_dict.items(), key=lambda kv: kv[1]["score"]):
                    _, txt_c = _color_score(info["score"])
                    filas.append([
                        Paragraph(esc_pdf(rel), celda),
                        Paragraph(str(info["score"]), ParagraphStyle("sc", parent=celda, textColor=txt_c, fontName="Helvetica-Bold")),
                        Paragraph("Sí" if info.get("es_vinculado") else "Huérfano", celda),
                        Paragraph(str(info.get("lineas", "-")), celda),
                        Paragraph(", ".join(info.get("tags") or []), celda),
                    ])
                t = Table(filas, repeatRows=1, colWidths=[6.5*cm, 1.8*cm, 2.5*cm, 2*cm, ancho_util_cm*cm - 12.8*cm])
                t.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, 0), CORAL),
                    ("GRID", (0, 0), (-1, -1), 0.4, GRID_GRAY),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_BG]),
                    ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]))
                elementos.append(t)
                elementos.append(Spacer(1, 12))

            # ── Detalle de hallazgos por archivo (todo lo que no sea OK, con recomendacion,
            #    + un resumen compacto de lo que SI cumple para que quede constancia
            #    de que esas reglas se evaluaron y no solo lo que falta) ──
            if archivos_dict:
                elementos.append(Paragraph("5. Detalle de hallazgos por archivo", seccion_h))
                for rel, info in sorted(archivos_dict.items(), key=lambda kv: kv[1]["score"]):
                    bps_archivo = info.get("buenas_practicas", [])
                    hallazgos = [c for c in bps_archivo if c.get("sev") != "OK"]
                    cumplen = [c for c in bps_archivo if c.get("sev") == "OK"]
                    if not bps_archivo:
                        continue
                    elementos.append(Paragraph(esc_pdf(rel), archivo_h))

                    if hallazgos:
                        filas_h = [[Paragraph(h, celda_bold) for h in ["Regla", "Estado", "Hallazgo, impacto y recomendación"]]]
                        for c in hallazgos:
                            bg_sev, txt_sev, _ = _color_sev(c.get("sev"))
                            label_sev = _label_estado(c)
                            filas_h.append([
                                Paragraph(c.get("regla", ""), celda),
                                Paragraph(label_sev, ParagraphStyle("esth_" + c.get("regla",""), parent=celda, textColor=txt_sev, fontName="Helvetica-Bold")),
                                Paragraph(esc_pdf(c.get("msg", "")) + "<br/>" + _celda_detalle(c), celda_detalle),
                            ])
                        t_h = Table(filas_h, repeatRows=1, colWidths=[1.6*cm, 2.3*cm, ancho_util_cm*cm - 3.9*cm])
                        estilo_h = [
                            ("BACKGROUND", (0, 0), (-1, 0), CORAL),
                            ("GRID", (0, 0), (-1, -1), 0.4, GRID_GRAY),
                            ("VALIGN", (0, 0), (-1, -1), "TOP"),
                            ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                        ]
                        for i, c in enumerate(hallazgos, start=1):
                            bg_sev, _, _ = _color_sev(c.get("sev"))
                            estilo_h.append(("BACKGROUND", (1, i), (1, i), bg_sev))
                        t_h.setStyle(TableStyle(estilo_h))
                        elementos.append(t_h)
                    else:
                        elementos.append(Paragraph("Sin hallazgos — todas las reglas evaluadas cumplen.", celda_detalle))

                    if cumplen:
                        reglas_ok = ", ".join(c.get("regla", "") for c in cumplen)
                        elementos.append(Paragraph(
                            f"<font color='#2f6b41'>✓ Cumple ({len(cumplen)}):</font> {esc_pdf(reglas_ok)}",
                            ParagraphStyle("okcompacto", parent=celda_detalle, spaceBefore=3)))
                    elementos.append(Spacer(1, 8))

            if data.get("md_files") or data.get("otros_files"):
                docs = ", ".join((data.get("md_files") or []) + (data.get("otros_files") or []))
                elementos.append(Paragraph("6. Documentación y configuración encontrada", seccion_h))
                elementos.append(Paragraph(esc_pdf(docs), celda_detalle))
                elementos.append(Spacer(1, 8))

        # ── Resumen final (siempre al fondo del documento) ──
        if modo == "proyecto":
            todos_para_resumen = list(data.get("checks_estructura", [])) + [
                c for info in data.get("archivos", {}).values() for c in info.get("buenas_practicas", [])
            ]
        else:
            todos_para_resumen = data.get("buenas_practicas", [])
        n_ok = sum(1 for c in todos_para_resumen if c.get("sev") == "OK")
        n_aviso = sum(1 for c in todos_para_resumen if c.get("sev") == "AVISO")
        n_error = sum(1 for c in todos_para_resumen if c.get("sev") == "ERROR")
        n_critico = sum(1 for c in todos_para_resumen if c.get("critico_personalizado"))

        bg_resumen, txt_resumen = _color_veredicto(veredicto_doc)
        elementos.append(Paragraph("Resumen final", seccion_h))
        tarjetas_resumen = Table([[
            _tarjeta(score, "Score final", bg_resumen, txt_resumen, ancho_frac=5),
            _tarjeta(n_ok, "Cumple", GREEN_BG, GREEN_TXT, ancho_frac=5),
            _tarjeta(n_aviso, "Cumple parcial", AMBER_BG, AMBER_TXT, ancho_frac=5),
            _tarjeta(n_error, "No cumple", RED_BG, RED_TXT, ancho_frac=5),
            _tarjeta(n_critico, "Críticos", RED_BG, RED_TXT, ancho_frac=5),
        ]], colWidths=[ancho_util_cm/5*cm]*5)
        tarjetas_resumen.setStyle(TableStyle([
            ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        elementos.append(tarjetas_resumen)
        elementos.append(Spacer(1, 6))
        elementos.append(Paragraph(
            f"Este {'proyecto' if modo == 'proyecto' else 'archivo'} quedó en estado "
            f"<b>{esc_pdf(veredicto_doc.get('label',''))}</b> con score {score}/100, sobre un total de "
            f"{len(todos_para_resumen)} reglas evaluadas.",
            ParagraphStyle("resumen_txt", parent=celda, fontSize=9, leading=13)
        ))

        # ── Pie de página ──
        class _CanvasConPie(_canvas_mod.Canvas):
            def __init__(self, *args, **kwargs):
                _canvas_mod.Canvas.__init__(self, *args, **kwargs)
                self._paginas = []

            def showPage(self):
                self._paginas.append(dict(self.__dict__))
                self._startPage()

            def save(self):
                total_pag = len(self._paginas)
                for estado in self._paginas:
                    self.__dict__.update(estado)
                    self._dibujar_pie(total_pag)
                    _canvas_mod.Canvas.showPage(self)
                _canvas_mod.Canvas.save(self)

            def _dibujar_pie(self, total_paginas):
                ancho_pagina = A4[0]
                self.setStrokeColor(GRID_GRAY)
                self.setLineWidth(0.5)
                self.line(1.3*cm, 1.15*cm, ancho_pagina - 1.3*cm, 1.15*cm)
                self.setFont("Helvetica", 7.3)
                self.setFillColor(GRAY_TXT)
                self.drawString(1.3*cm, 0.9*cm, "Desarrollado por Willian Arce — © " + str(ahora.year))
                self.drawCentredString(ancho_pagina/2, 0.9*cm,
                                       f"ETL Governance Portal — Banco Continental — {id_reporte}")
                self.drawRightString(ancho_pagina - 1.3*cm, 0.9*cm,
                                      f"Página {self._pageNumber} de {total_paginas}")

        doc.build(elementos, canvasmaker=_CanvasConPie)
        buf.seek(0)
    except Exception as e:
        app.logger.error("Error generando PDF de analisis Python: %s", e)
        return jsonify({"ok": False, "error": f"Error generando el PDF: {e}"}), 500

    nombre_base = re.sub(r'[^\w\-\.]', '_', os.path.basename(nombre_archivo or "analisis"))
    nombre = f"analisis_{modo}_{nombre_base}_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    return send_file(buf, mimetype="application/pdf", as_attachment=True, download_name=nombre)



@app.route("/api/python/run", methods=["POST"])
@login_required
def api_python_run():
    """Ejecuta código Python y retorna resultado."""
    data = request.get_json(force=True)
    codigo = data.get("codigo", "")
    timeout = min(int(data.get("timeout", 120)), 300)
    args = data.get("args", "")
    if not codigo.strip():
        return jsonify({"error": "Sin código para ejecutar"}), 400
    try:
        result = ejecutar_python(codigo, timeout=timeout, args=args)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/python/save", methods=["POST"])
@login_required
def api_python_save():
    """Guarda un script en la biblioteca."""
    data = request.get_json(force=True)
    nombre = data.get("nombre", "sin_nombre.py")
    codigo = data.get("codigo", "")
    if not codigo.strip():
        return jsonify({"error": "Sin código"}), 400

    analisis = analizar_python(codigo, nombre=nombre)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO python_scripts
            (nombre, tipo, fecha, timestamp, codigo, analisis, score, tags)
            VALUES (?,?,?,?,?,?,?,?)
        """, (nombre, analisis["tipo"], ts[:10], ts, codigo,
              json.dumps(analisis, ensure_ascii=False),
              analisis["score"], json.dumps(analisis["tags"])))
        conn.commit()
        sid = cur.lastrowid

    # Also save to filesystem
    safe_name = re.sub(r'[^\w\-\.]', '_', nombre)
    fpath = SCRIPTS_DIR / safe_name
    fpath.write_text(codigo, encoding="utf-8")

    return jsonify({"ok": True, "id": sid, "analisis": analisis})


@app.route("/api/python/analyze_local_file", methods=["POST"])
@login_required
def api_python_analyze_local_file():
    """
    Analiza un archivo .py del PC del usuario (modo LOCAL). NO persiste el
    codigo fuente en el servidor (no escribe en SCRIPTS_DIR, no lo guarda
    en python_scripts) — pero SI registra el resultado del analisis
    (score + hallazgos, sin el codigo) en el historial de buenas practicas,
    para trazabilidad y para que Deploy pueda consultarlo despues.
    """
    archivo = request.files.get("archivo")
    if not archivo or not archivo.filename:
        return jsonify({"error": "No se recibió archivo"}), 400
    if not archivo.filename.lower().endswith(".py"):
        return jsonify({"error": "Solo archivos .py"}), 400

    responsable_proyecto = request.form.get("responsable_proyecto")
    codigo = archivo.read().decode("utf-8", errors="replace")
    try:
        analisis = analizar_python(codigo, nombre=archivo.filename)
        analisis["responsable_proyecto"] = (responsable_proyecto or "").strip() or None
        try:
            _guardar_historial_analisis("archivo", archivo.filename, analisis, "local", responsable_proyecto)
        except Exception as e:
            app.logger.error("No se pudo guardar historial de analisis: %s", e)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    return jsonify({"ok": True, "nombre": archivo.filename, "codigo": codigo, "analisis": analisis})


@app.route("/api/python/upload", methods=["POST"])
@login_required
def api_python_upload():
    """Sube un archivo .py."""
    archivo = request.files.get("archivo")
    if not archivo or not archivo.filename:
        return jsonify({"error": "No se recibió archivo"}), 400
    if not archivo.filename.lower().endswith(".py"):
        return jsonify({"error": "Solo archivos .py"}), 400

    codigo = archivo.read().decode("utf-8", errors="replace")
    analisis = analizar_python(codigo, nombre=archivo.filename)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO python_scripts
            (nombre, tipo, fecha, timestamp, codigo, archivo, analisis, score, tags)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (archivo.filename, analisis["tipo"], ts[:10], ts, codigo,
              archivo.filename, json.dumps(analisis, ensure_ascii=False),
              analisis["score"], json.dumps(analisis["tags"])))
        conn.commit()
        sid = cur.lastrowid

    # Save to filesystem
    safe_name = re.sub(r'[^\w\-\.]', '_', archivo.filename)
    (SCRIPTS_DIR / safe_name).write_text(codigo, encoding="utf-8")

    return jsonify({"ok": True, "id": sid, "nombre": archivo.filename,
                    "codigo": codigo, "analisis": analisis})


@app.route("/api/python/script/<int:sid>")
@login_required
def api_python_script(sid):
    """Retorna un script guardado."""
    with _db() as conn:
        row = conn.execute("SELECT * FROM python_scripts WHERE id=?", (sid,)).fetchone()
        if not row:
            return jsonify({"error": "Script no encontrado"}), 404
        return jsonify(dict(row))


@app.route("/api/python/download/<int:sid>")
@login_required
def api_python_download(sid):
    """Descarga un script como .py."""
    with _db() as conn:
        row = conn.execute("SELECT nombre, codigo FROM python_scripts WHERE id=?", (sid,)).fetchone()
        if not row:
            abort(404)
    buf = io.BytesIO(row["codigo"].encode("utf-8"))
    return send_file(buf, mimetype="text/x-python",
                     as_attachment=True, download_name=row["nombre"])


@app.route("/api/python/historial")
@login_required
def api_python_historial():
    """Historial de ejecuciones."""
    with _db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM python_ejecuciones ORDER BY id DESC LIMIT 100").fetchall()]
    return jsonify({"count": len(rows), "ejecuciones": rows})


@app.route("/api/python/nombres_proyectos")
@login_required
def api_python_nombres_proyectos():
    """
    Lista los nombres de proyecto ya usados (tipo='proyecto'), mas
    recientes primero — se usa para sugerir/autocompletar al preguntar
    el nombre del proyecto, y para avisar si el nombre nuevo se parece
    a uno ya existente (evita que "Pre Aprobado" y "Pre Aprobados"
    queden separados por un simple typo, sin poder compararse).
    """
    with _db() as conn:
        rows = conn.execute("""
            SELECT nombre, MAX(id) as ultimo_id FROM python_analisis_historial
            WHERE tipo='proyecto' GROUP BY nombre ORDER BY ultimo_id DESC LIMIT 100
        """).fetchall()
    return jsonify({"nombres": [r["nombre"] for r in rows]})


@app.route("/api/python/historial_analisis")
@login_required
def api_python_historial_analisis():
    """
    Historial de analisis de buenas practicas (archivo unico o proyecto),
    con score y veredicto — es lo que Deploy consulta para auto-marcar
    el criterio 'puntaje_minimo' del checklist, y lo que alimenta la
    vista de "Historial de Análisis" en el portal (control por proyecto
    a lo largo del tiempo).
    Filtros opcionales:
      ?nombre=xxx     busca coincidencias de un proceso puntual
      ?tipo=proyecto  solo corridas de proyecto completo (recomendado para
                      la vista de control — evita las filas internas por
                      archivo que se guardan solo para la regla BP-08)
    """
    nombre_filtro = request.args.get("nombre", "").strip()
    tipo_filtro = request.args.get("tipo", "").strip()

    condiciones = []
    params = []
    if nombre_filtro:
        condiciones.append("nombre LIKE ?")
        params.append(f"%{nombre_filtro}%")
    if tipo_filtro:
        condiciones.append("tipo = ?")
        params.append(tipo_filtro)

    where = ("WHERE " + " AND ".join(condiciones)) if condiciones else ""
    with _db() as conn:
        rows = [dict(r) for r in conn.execute(f"""
            SELECT * FROM python_analisis_historial
            {where} ORDER BY id DESC LIMIT 200
        """, params).fetchall()]
    return jsonify({"count": len(rows), "analisis": rows})


@app.route("/api/python/comparar_analisis")
@login_required
def api_python_comparar_analisis():
    """
    Compara una corrida de proyecto (?id=<id>) contra la corrida
    INMEDIATAMENTE ANTERIOR del mismo proyecto (mismo nombre), y devuelve
    que hallazgos se resolvieron, cuales persisten sin corregir, y cuales
    son nuevos desde esa corrida anterior — para ver de un vistazo si una
    correccion realmente se aplico y que falta.
    """
    id_actual = request.args.get("id", type=int)
    if not id_actual:
        return jsonify({"error": "Falta el id de la corrida"}), 400

    with _db() as conn:
        actual = conn.execute(
            "SELECT * FROM python_analisis_historial WHERE id=? AND tipo='proyecto'", (id_actual,)
        ).fetchone()
        if not actual:
            return jsonify({"error": "Corrida no encontrada"}), 404

        anterior = conn.execute("""
            SELECT * FROM python_analisis_historial
            WHERE tipo='proyecto' AND nombre=? AND id<?
            ORDER BY id DESC LIMIT 1
        """, (actual["nombre"], id_actual)).fetchone()

        def _hallazgos_de(row):
            """Junta los hallazgos (sev != OK) de esta corrida: los de
            estructura de proyecto + los de cada archivo hijo (via parent_id)."""
            if not row:
                return {}
            hallazgos = {}
            try:
                resumen = json.loads(row["resumen_json"] or "{}")
            except Exception:
                resumen = {}
            for c in resumen.get("checks_estructura", []):
                if c.get("sev") != "OK":
                    hallazgos[f"[estructura] {c.get('regla')}"] = {**c, "archivo": "(estructura del proyecto)"}
            hijos = conn.execute(
                "SELECT * FROM python_analisis_historial WHERE parent_id=?", (row["id"],)
            ).fetchall()
            for h in hijos:
                try:
                    r2 = json.loads(h["resumen_json"] or "{}")
                except Exception:
                    r2 = {}
                for c in r2.get("buenas_practicas", []):
                    if c.get("sev") != "OK":
                        hallazgos[f"{h['nombre']} :: {c.get('regla')}"] = {**c, "archivo": h["nombre"]}
            return hallazgos

        hallazgos_actual = _hallazgos_de(actual)
        hallazgos_anterior = _hallazgos_de(anterior) if anterior else {}

        keys_actual = set(hallazgos_actual)
        keys_anterior = set(hallazgos_anterior)

        def _fmt(keys, fuente):
            out = []
            for k in sorted(keys):
                c = fuente[k]
                out.append({
                    "archivo": c.get("archivo", "(proyecto)"), "regla": c.get("regla"),
                    "msg": c.get("msg"), "sev": c.get("sev"),
                    "critico_personalizado": bool(c.get("critico_personalizado")),
                })
            return out

        return jsonify({
            "ok": True,
            "tiene_anterior": anterior is not None,
            "anterior": {"score": anterior["score"], "timestamp": anterior["timestamp"]} if anterior else None,
            "actual": {"score": actual["score"], "timestamp": actual["timestamp"]},
            "resueltos": _fmt(keys_anterior - keys_actual, hallazgos_anterior),
            "persisten": _fmt(keys_actual & keys_anterior, hallazgos_actual),
            "nuevos": _fmt(keys_actual - keys_anterior, hallazgos_actual),
        })


def _ultimo_analisis_aprobado(nombre_proceso):
    """
    Busca en el historial de analisis el registro mas reciente cuyo
    nombre coincida (razonablemente) con nombre_proceso, para poder
    auto-marcar el checklist de Deploy. Coincidencia flexible: nombre
    de archivo sin extension, dentro del nombre guardado (o viceversa).
    """
    base = re.sub(r'[^\w]', '', os.path.splitext(nombre_proceso)[0]).lower()
    if not base:
        return None
    with _db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM python_analisis_historial ORDER BY id DESC LIMIT 300").fetchall()]
    for r in rows:
        candidato = re.sub(r'[^\w]', '', os.path.splitext(r["nombre"])[0]).lower()
        if base in candidato or candidato in base:
            return r
    return None


@app.route("/api/python/delete/<int:sid>", methods=["POST"])
@login_required
def api_python_delete(sid):
    with _db() as conn:
        conn.execute("DELETE FROM python_scripts WHERE id=?", (sid,))
        conn.commit()
    return jsonify({"ok": True})


@app.route("/api/python/enviar_a_deploy/<int:sid>", methods=["POST"])
@login_required
def api_python_enviar_a_deploy(sid):
    """
    Toma un script ya guardado en la biblioteca y lo empaqueta como .zip
    (script + requirements.txt si existe) para entrar al mismo flujo de
    versionado/checklist/implementar que KTR y JOB, usando la misma raíz
    configurable (PENTAHO_PROD_PY_PATH / PENTAHO_PROD_KTR_PATH).
    Body JSON: {"nombre_proceso":"...", "id_hu":"...", "destino_dir":"..."}
    """
    data = request.get_json(force=True) or {}
    nombre_proceso = (data.get("nombre_proceso") or "").strip()
    id_hu = (data.get("id_hu") or "").strip()
    if not nombre_proceso:
        return jsonify({"ok": False, "error": "Falta nombre_proceso"}), 400

    with _db() as conn:
        row = conn.execute("SELECT * FROM python_scripts WHERE id=?", (sid,)).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "Script no encontrado"}), 404

    version = _siguiente_version("PY", nombre_proceso)
    version_tag = (data.get("version_tag") or "").strip() or f"v{version}"
    destino_dir = _normalizar_bajo_root("PY", data.get("destino_dir", ""))

    folder = _deploy_folder("PY", nombre_proceso, version)
    zip_name = f"{re.sub(r'[^\\w\\-\\.]', '_', nombre_proceso)}_{version_tag}.zip"
    zip_path = folder / zip_name
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(row["nombre"] or "script.py", row["codigo"] or "")
        zf.writestr("requirements.txt", "")  # completar con las dependencias reales
        zf.writestr(f"{nombre_proceso}.md",
                    f"# {nombre_proceso}\n\nNecesidad que cubre: <completar>\n\nResponsable: {session.get('usuario','')}\n")

    file_hash = _file_hash(zip_path)
    responsable = session.get("usuario", "desconocido")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Buscar en el historial de analisis (Python & ML) si este script/proceso
    # ya paso el analisis de buenas practicas, para auto-marcar el checklist.
    analisis_previo = _ultimo_analisis_aprobado(row["nombre"] or nombre_proceso)

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO deploy_versiones
            (tipo, nombre_proceso, id_hu, version, version_tag, archivo_nombre,
             ruta_local, destino_dir, hash_sha256, responsable, fecha, timestamp, estado)
            VALUES ('PY',?,?,?,?,?,?,?,?,?,?,?,'borrador')
        """, (nombre_proceso, id_hu, version, version_tag, zip_name,
              str(zip_path), destino_dir, file_hash, responsable, ts[:10], ts))
        vid = cur.lastrowid
        for criterio, _desc in CHECKLIST_ITEMS["PY"]:
            if criterio == "puntaje_minimo" and analisis_previo and analisis_previo["aprobado"]:
                conn.execute("""
                    INSERT INTO deploy_checklist (version_id, criterio, cumplido, marcado_por, fecha)
                    VALUES (?,?,1,?,?)
                """, (vid, criterio,
                      f"Automático (análisis Python&ML): score {analisis_previo['score']}/100 — {analisis_previo['veredicto_label']}",
                      ts))
            else:
                conn.execute("""
                    INSERT INTO deploy_checklist (version_id, criterio, cumplido)
                    VALUES (?,?,0)
                """, (vid, criterio))
        conn.commit()

    respuesta = {"ok": True, "version_id": vid, "version": version, "version_tag": version_tag}
    if analisis_previo:
        respuesta["analisis_vinculado"] = {
            "score": analisis_previo["score"], "veredicto": analisis_previo["veredicto_label"],
            "aprobado": bool(analisis_previo["aprobado"]), "fecha": analisis_previo["timestamp"],
        }
    return jsonify(respuesta)


# ════════════════════════════════════════════════════════
#  VERSIONADO — Implementar (subir a PROD) / Bajar (descargar de PROD)
# ════════════════════════════════════════════════════════

def _deploy_folder(tipo, nombre_proceso, version):
    safe_nombre = re.sub(r'[^\w\-\.]', '_', nombre_proceso)
    folder = DEPLOY_DIR / tipo / safe_nombre / f"v{version}"
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def _siguiente_version(tipo, nombre_proceso):
    with _db() as conn:
        row = conn.execute("""
            SELECT MAX(version) mx FROM deploy_versiones
            WHERE tipo=? AND nombre_proceso=?
        """, (tipo, nombre_proceso)).fetchone()
        return (row["mx"] or 0) + 1

def _normalizar_bajo_root(tipo, subpath):
    """
    Resuelve subpath (relativo, elegido en el explorador visual) contra la
    raíz configurada para ese tipo, e impide escapar de esa raíz (../../etc).
    Usa posixpath SIEMPRE, porque el servidor Pentaho remoto es Linux
    independientemente del sistema operativo donde corra este portal.
    """
    root = PROD_ROOTS.get(tipo, "/pentaho/project/")
    root = root.replace("\\", "/")
    root = root if root.endswith("/") else root + "/"
    subpath = (subpath or "").strip().strip("/").replace("\\", "/")
    candidato = posixpath.normpath(posixpath.join(root, subpath))
    root_norm = posixpath.normpath(root)
    if not (candidato + "/").startswith(root_norm + "/"):
        candidato = root_norm
    return candidato


@app.route("/deploy")
@login_required
def deploy_home():
    with _db() as conn:
        versiones = [dict(r) for r in conn.execute(
            "SELECT * FROM deploy_versiones ORDER BY id DESC").fetchall()]
        for v in versiones:
            fila = conn.execute("""
                SELECT COUNT(*) total, SUM(cumplido) hechos
                FROM deploy_checklist WHERE version_id=?
            """, (v["id"],)).fetchone()
            total = fila["total"] or 0
            hechos = fila["hechos"] or 0
            v["checklist_total"] = total
            v["checklist_hechos"] = hechos
            v["checklist_pct"] = round(100 * hechos / total) if total else 0
    return render_template("deploy.html", versiones=versiones,
                            prod_roots=PROD_ROOTS)


@app.route("/api/deploy/browse")
@login_required
def api_deploy_browse():
    """
    Explorador visual de carpetas remotas en PROD. Devuelve las subcarpetas
    de <root_del_tipo>/<path> para que el usuario elija dónde implementar,
    sin tener que escribir el path completo a mano.
    """
    tipo = (request.args.get("tipo") or "KTR").upper()
    subpath = request.args.get("path", "")
    root = PROD_ROOTS.get(tipo, "/pentaho/project/")
    actual = _normalizar_bajo_root(tipo, subpath)

    cmd = f'find "{actual}" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort'
    out, ok = _run(cmd)
    carpetas = []
    if ok and out.strip():
        carpetas = [posixpath.basename(p.strip()) for p in out.splitlines() if p.strip()]

    relativo = actual[len(posixpath.normpath(root)):].strip("/")
    return jsonify({"ok": True, "root": root, "actual": actual,
                     "relativo": relativo, "carpetas": carpetas})


@app.route("/api/deploy/check_existente")
@login_required
def api_deploy_check_existente():
    """
    Antes de subir: si ya existe el proceso, avisa (en vez de preguntar si se
    quiere sobreescribir) y sugiere un nombre de versión estándar, editable.
    """
    tipo = (request.args.get("tipo") or "").upper()
    nombre_proceso = (request.args.get("nombre_proceso") or "").strip()
    if tipo not in CHECKLIST_ITEMS or not nombre_proceso:
        return jsonify({"ok": True, "existe": False, "sugerido": "v1"})

    with _db() as conn:
        row = conn.execute("""
            SELECT MAX(version) mx, COUNT(*) c FROM deploy_versiones
            WHERE tipo=? AND nombre_proceso=?
        """, (tipo, nombre_proceso)).fetchone()

    ultima = row["mx"] or 0
    existe = (row["c"] or 0) > 0
    sugerido = f"v{ultima + 1}"
    return jsonify({"ok": True, "existe": existe, "ultima_version": ultima,
                     "sugerido": sugerido})


@app.route("/api/deploy/analisis_previo")
@login_required
def api_deploy_analisis_previo():
    """
    Consulta si este nombre_proceso ya fue analizado en Python & ML,
    y con que score/veredicto — para mostrarlo como badge en Deploy
    antes de aprobar el pase.
    """
    nombre_proceso = (request.args.get("nombre_proceso") or "").strip()
    if not nombre_proceso:
        return jsonify({"ok": True, "encontrado": False})

    row = _ultimo_analisis_aprobado(nombre_proceso)
    if not row:
        return jsonify({"ok": True, "encontrado": False})

    return jsonify({
        "ok": True, "encontrado": True,
        "score": row["score"], "veredicto_label": row["veredicto_label"],
        "aprobado": bool(row["aprobado"]), "tipo": row["tipo"],
        "origen": row["origen"], "timestamp": row["timestamp"],
        "responsable_proyecto": row["responsable_proyecto"] if "responsable_proyecto" in row.keys() else None,
    })


@app.route("/api/deploy/check_destino")
@login_required
def api_deploy_check_destino():
    """
    Verifica si YA existe, en la carpeta de PROD elegida, un archivo con el
    mismo nombre que el que se va a subir. Si existe, ese archivo (no el
    nombre_proceso que se escribió) es el que define la próxima versión,
    porque es a ese archivo al que se va a reemplazar.
    """
    tipo = (request.args.get("tipo") or "").upper()
    destino_dir = request.args.get("destino_dir", "")
    archivo_nombre = (request.args.get("archivo_nombre") or "").strip()
    if not destino_dir or not archivo_nombre:
        return jsonify({"ok": True, "existe_en_prod": False, "sugerido": "v1"})

    destino_dir = _normalizar_bajo_root(tipo or "KTR", destino_dir) if not destino_dir.startswith("/") else destino_dir
    ruta_prod = f"{destino_dir.rstrip('/')}/{archivo_nombre}"

    out, ok = _run(f'test -f "{ruta_prod}" && echo EXISTE || echo NOEXISTE')
    existe_en_prod = ok and "EXISTE" in out and "NOEXISTE" not in out

    with _db() as conn:
        row = conn.execute("""
            SELECT MAX(version) mx, COUNT(*) c FROM deploy_versiones
            WHERE destino_dir=? AND archivo_nombre=?
        """, (destino_dir, archivo_nombre)).fetchone()
    ultima_local = row["mx"] or 0
    tiene_historial_local = (row["c"] or 0) > 0

    if tiene_historial_local:
        sugerido = f"v{ultima_local + 1}"
    elif existe_en_prod:
        # Ya hay un archivo con ese nombre en PROD, pero no versionado por este portal.
        sugerido = "v2"
    else:
        sugerido = "v1"

    return jsonify({"ok": True, "existe_en_prod": existe_en_prod, "ruta_prod": ruta_prod,
                     "ultima_version_local": ultima_local, "sugerido": sugerido})


def _chequear_md_completo(ruta_doc):
    """
    Control básico de calidad del .md subido — no bloquea la subida, pero
    devuelve tips si detecta que probablemente quedó a medio completar.
    """
    tips = []
    try:
        contenido = Path(ruta_doc).read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ["No se pudo leer el .md para revisarlo."]

    texto = contenido.strip()
    if len(texto) < 150:
        tips.append("El .md parece muy corto — revisá que esté completo, no solo el título.")

    # Restos típicos de la plantilla sin completar
    if re.search(r'\[Nombre del proceso\]', contenido, re.IGNORECASE):
        tips.append("El título todavía dice '[Nombre del proceso]' — falta completarlo.")
    placeholders = re.findall(r'\*\([^)]{0,80}\)\*', contenido)
    if placeholders:
        tips.append(f"Quedan {len(placeholders)} sección(es) con el instructivo entre *(paréntesis)* sin completar.")
    if re.search(r'\|\s*\|\s*\|', contenido):
        tips.append("Hay filas de alguna tabla que parecen vacías (sin completar).")

    secciones_clave = ["Necesidad que cubre", "Responsable"]
    for sec in secciones_clave:
        if sec.lower() not in contenido.lower():
            tips.append(f"No se encontró la sección \"{sec}\" — revisá que esté en el .md.")

    return tips


@app.route("/api/deploy/documentacion/<int:vid>")
@login_required
def api_deploy_ver_documentacion(vid):
    """Sirve el .md de documentación de una versión, para verlo o descargarlo."""
    with _db() as conn:
        v = conn.execute("SELECT ruta_documentacion, nombre_proceso, version_tag FROM deploy_versiones WHERE id=?",
                          (vid,)).fetchone()
    if not v or not v["ruta_documentacion"] or not os.path.isfile(v["ruta_documentacion"]):
        abort(404)
    nombre_descarga = f"{v['nombre_proceso']}_{v['version_tag']}.md"
    return send_file(v["ruta_documentacion"], mimetype="text/markdown",
                      as_attachment=False, download_name=nombre_descarga)


@app.route("/api/deploy/nueva_version", methods=["POST"])
@login_required
def api_deploy_nueva_version():
    """
    Sube una nueva versión (KTR, JOB o PY) al portal. Espera multipart/form-data:
      tipo            'KTR' | 'JOB' | 'PY'
      nombre_proceso  nombre lógico del proceso (ej. 'carga_segmentacion_cliente')
      id_hu           ID de la HU en Azure DevOps
      destino_dir     subcarpeta elegida en el explorador visual (relativa a la raíz del tipo)
      version_tag     opcional — si no se edita, se usa el estándar 'v{n}'
      archivo         uno o más archivos (o una carpeta completa, con rutas
                       relativas en el nombre). Si es un único .zip, se usa tal
                       cual; si son varios archivos o una carpeta, se empaquetan
                       automáticamente en un .zip nuevo.
      documentacion   opcional — el .md de documentación, SEPARADO del entregable.
                       Se guarda en una carpeta propia (DOCUMENTACION_DIR), que
                       espeja tipo/nombre_proceso/version, en vez de vivir
                       adentro del mismo .zip que se implementa.
    """
    tipo = (request.form.get("tipo") or "").upper().strip()
    if tipo not in CHECKLIST_ITEMS:
        return jsonify({"ok": False, "error": "tipo debe ser KTR, JOB o PY"}), 400

    nombre_proceso = (request.form.get("nombre_proceso") or "").strip()
    id_hu = (request.form.get("id_hu") or "").strip()
    if not nombre_proceso:
        return jsonify({"ok": False, "error": "Falta nombre_proceso"}), 400

    archivos = [f for f in request.files.getlist("archivo") if f and f.filename]
    if not archivos:
        return jsonify({"ok": False, "error": "No se recibió ningún archivo"}), 400

    version = _siguiente_version(tipo, nombre_proceso)
    version_tag = (request.form.get("version_tag") or "").strip() or f"v{version}"
    destino_dir = _normalizar_bajo_root(tipo, request.form.get("destino_dir", ""))
    folder = _deploy_folder(tipo, nombre_proceso, version)

    if len(archivos) == 1 and archivos[0].filename.lower().endswith(
            (".zip", ".ktr", ".kjb", ".py")):
        # Un solo archivo suelto (o ya viene como .zip armado): se guarda tal cual.
        archivo = archivos[0]
        archivo_nombre = os.path.basename(archivo.filename.replace("\\", "/"))
        ruta_local = folder / archivo_nombre
        archivo.save(str(ruta_local))
    else:
        # Varios archivos o una carpeta completa (rutas relativas en el nombre):
        # se empaquetan en un único .zip nuevo, preservando la estructura.
        safe_proc = re.sub(r'[^\w\-\.]', '_', nombre_proceso)
        archivo_nombre = f"{safe_proc}_{version_tag}.zip"
        ruta_local = folder / archivo_nombre
        with zipfile.ZipFile(ruta_local, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in archivos:
                rel = f.filename.replace("\\", "/").lstrip("/")
                zf.writestr(rel, f.read())

    file_hash = _file_hash(ruta_local)

    # El .md va a una carpeta APARTE, que espeja tipo/nombre_proceso/version,
    # en vez de ir adentro del mismo .zip que se sube a PROD.
    ruta_documentacion = None
    tips_md = []
    doc_file = request.files.get("documentacion")
    if doc_file and doc_file.filename:
        safe_proc = re.sub(r'[^\w\-\.]', '_', nombre_proceso)
        carpeta_doc = DOCUMENTACION_DIR / tipo / safe_proc
        carpeta_doc.mkdir(parents=True, exist_ok=True)
        nombre_doc = f"{version_tag}.md"
        ruta_doc = carpeta_doc / nombre_doc
        doc_file.save(str(ruta_doc))
        ruta_documentacion = str(ruta_doc)
        tips_md = _chequear_md_completo(ruta_doc)

    # Líder de proyecto y analista/desarrollador asignado, tomados de Azure
    # DevOps al momento de crear la versión (no solo mostrados en pantalla:
    # quedan guardados junto con la versión para consultar más adelante).
    lider_proyecto = None
    analista_asignado = None
    if id_hu:
        try:
            resumen_azure = _azure_resumen_item(id_hu)
            if resumen_azure.get("ok"):
                res = resumen_azure["resumen"]
                lider_proyecto = res.get("lider_proyecto") or None
                analista_asignado = res.get("desarrollador_asignado") or None
                # Si es una Tarea sin esos datos propios, usa los de la HU padre.
                if res.get("hu_padre"):
                    lider_proyecto = lider_proyecto or res["hu_padre"].get("lider_proyecto")
                    analista_asignado = analista_asignado or res["hu_padre"].get("desarrollador_asignado")
        except Exception as e:
            app.logger.warning("No se pudo traer líder/analista de Azure DevOps para %s: %s", id_hu, e)

    responsable = session.get("usuario", "desconocido")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO deploy_versiones
            (tipo, nombre_proceso, id_hu, version, version_tag, archivo_nombre,
             ruta_local, destino_dir, hash_sha256, responsable, fecha, timestamp,
             estado, ruta_documentacion, lider_proyecto, analista_asignado)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'borrador',?,?,?)
        """, (tipo, nombre_proceso, id_hu, version, version_tag, archivo_nombre,
              str(ruta_local), destino_dir, file_hash, responsable, ts[:10], ts,
              ruta_documentacion, lider_proyecto, analista_asignado))
        vid = cur.lastrowid
        # Inicializa el checklist correspondiente. Si ya se adjuntó el .md acá
        # mismo, el ítem "md_creado" se marca solo (no hace falta tildarlo a
        # mano en el checklist después).
        for criterio, _desc in CHECKLIST_ITEMS[tipo]:
            cumplido = 1 if (criterio == "md_creado" and ruta_documentacion) else 0
            conn.execute("""
                INSERT INTO deploy_checklist (version_id, criterio, cumplido, marcado_por, fecha)
                VALUES (?,?,?,?,?)
            """, (vid, criterio, cumplido,
                  responsable if cumplido else None, ts if cumplido else None))
        conn.commit()

    return jsonify({"ok": True, "version_id": vid, "version": version,
                     "version_tag": version_tag, "destino_dir": destino_dir,
                     "ruta_documentacion": ruta_documentacion, "tips_md": tips_md,
                     "lider_proyecto": lider_proyecto, "analista_asignado": analista_asignado})


@app.route("/api/deploy/checklist/<int:vid>", methods=["GET"])
@login_required
def api_deploy_checklist_get(vid):
    with _db() as conn:
        v = conn.execute("SELECT * FROM deploy_versiones WHERE id=?", (vid,)).fetchone()
        if not v:
            return jsonify({"ok": False, "error": "Versión no encontrada"}), 404
        items = [dict(r) for r in conn.execute(
            "SELECT * FROM deploy_checklist WHERE version_id=?", (vid,)).fetchall()]
    descripciones = dict(CHECKLIST_ITEMS[v["tipo"]])
    for it in items:
        it["descripcion"] = descripciones.get(it["criterio"], it["criterio"])
    return jsonify({"ok": True, "version": dict(v), "checklist": items})


@app.route("/api/deploy/checklist/<int:vid>", methods=["POST"])
@login_required
def api_deploy_checklist_post(vid):
    """Guarda las marcas del checklist. Body: {"criterio1": true, "criterio2": false, ...}"""
    data = request.get_json(force=True) or {}
    usuario = session.get("usuario", "desconocido")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with _db() as conn:
        for criterio, cumplido in data.items():
            conn.execute("""
                UPDATE deploy_checklist SET cumplido=?, marcado_por=?, fecha=?
                WHERE version_id=? AND criterio=?
            """, (int(bool(cumplido)), usuario, ts, vid, criterio))
        conn.commit()
        pendientes = conn.execute("""
            SELECT COUNT(*) c FROM deploy_checklist WHERE version_id=? AND cumplido=0
        """, (vid,)).fetchone()["c"]
        if pendientes == 0:
            conn.execute("UPDATE deploy_versiones SET estado='listo_prod' WHERE id=? AND estado='borrador'", (vid,))
            conn.commit()
    return jsonify({"ok": True, "pendientes": pendientes})


UMBRAL_CHECKLIST_IMPLEMENTAR = 55  # % mínimo de checklist cumplido para poder implementar

def _checklist_estado(vid, tipo):
    """Devuelve (pct, hechos, total, [descripciones de los items pendientes])."""
    with _db() as conn:
        filas = conn.execute("""
            SELECT criterio, cumplido FROM deploy_checklist WHERE version_id=?
        """, (vid,)).fetchall()
    descripciones = dict(CHECKLIST_ITEMS.get(tipo, []))
    total = len(filas)
    hechos = sum(1 for f in filas if f["cumplido"])
    pendientes = [descripciones.get(f["criterio"], f["criterio"]) for f in filas if not f["cumplido"]]
    pct = round(100 * hechos / total) if total else 0
    return pct, hechos, total, pendientes


def _archivar_copia_en_versionado(remote_path, tipo, version_tag):
    """
    Guarda una copia del archivo YA IMPLEMENTADO dentro de 'Versionado', para
    que quede un historial completo desde la primera vez que se implementa
    (no solo cuando se reemplaza algo que ya existía).
    """
    root = PROD_ROOTS.get(tipo, "/pentaho/project/").rstrip("/")
    carpeta_remota = posixpath.dirname(remote_path)
    rel_dir = carpeta_remota[len(root):].strip("/") if carpeta_remota.startswith(root) else carpeta_remota.strip("/")
    nombre = posixpath.basename(remote_path)
    base, ext = posixpath.splitext(nombre)
    nombre_archivo = f"{base}_{version_tag}{ext}"
    carpeta_destino = posixpath.join(VERSIONADO_ROOT, rel_dir) if rel_dir else VERSIONADO_ROOT
    ruta_destino = posixpath.join(carpeta_destino, nombre_archivo)
    _, ok = _run(f'mkdir -p "{carpeta_destino}" && cp -p "{remote_path}" "{ruta_destino}"')
    return ruta_destino if ok else None


@app.route("/api/deploy/implementar/<int:vid>", methods=["POST"])
@login_required
def api_deploy_implementar(vid):
    """
    Sube la versión a PROD por SFTP, a la carpeta elegida visualmente
    (destino_dir), pero SOLO si:
      1. El checklist técnico llega al menos al umbral mínimo (55% cumplido).
      2. La HU (o su HU padre, si es una Tarea) en Azure DevOps tiene el OK
         del Scrum Master y la autorización del PO.
    Si falta algo, rechaza y devuelve el detalle de qué items faltan.
    """
    with _db() as conn:
        v = conn.execute("SELECT * FROM deploy_versiones WHERE id=?", (vid,)).fetchone()
        if not v:
            return jsonify({"ok": False, "error": "Versión no encontrada"}), 404
        v = dict(v)

    motivos = []

    pct, hechos, total, pendientes = _checklist_estado(vid, v["tipo"])
    if pct < UMBRAL_CHECKLIST_IMPLEMENTAR:
        lista = "; ".join(pendientes) if pendientes else "revisar el checklist"
        motivos.append(
            f"Checklist en {pct}% ({hechos}/{total}) — se necesita al menos "
            f"{UMBRAL_CHECKLIST_IMPLEMENTAR}% para implementar. Falta: {lista}."
        )

    gate = {"ok": False}
    if v.get("id_hu"):
        gate = _azure_gate(v["id_hu"])
        if not gate.get("ok"):
            motivos.append(gate.get("motivo", "No se pudo validar la HU en Azure DevOps."))
    else:
        motivos.append("La versión no tiene un ID de HU asociado.")

    if motivos:
        return jsonify({"ok": False, "rechazado": True, "motivos": motivos,
                         "checklist_pct": pct, "checklist_pendientes": pendientes,
                         "nota": "El incumplimiento de estos criterios implica el rechazo "
                                 "de la puesta en producción hasta la próxima HU."}), 409

    destino_dir = v.get("destino_dir") or PROD_ROOTS.get(v["tipo"], "/pentaho/project/")
    remote_path = f"{destino_dir.rstrip('/')}/{v['archivo_nombre']}"

    version_tag = v.get("version_tag") or f"v{v['version']}"

    out_test, ok_test = _run(f'test -f "{remote_path}" && echo EXISTE || echo NOEXISTE')
    ya_existia = ok_test and "EXISTE" in out_test and "NOEXISTE" not in out_test

    resp_ok, ruta_respaldo, resp_err = _respaldar_original_si_existe(remote_path, v["tipo"], version_tag)
    if not resp_ok:
        return jsonify({"ok": False, "error": resp_err}), 500

    ok, err = _sftp_put(v["ruta_local"], remote_path)

    es_nuevo = ok and not ya_existia
    if es_nuevo:
        # No existía nada antes en PROD: esta es la primera vez que se
        # implementa este archivo. Igual se archiva en Versionado, como
        # línea base (v1 o la que corresponda), para llevar el historial
        # completo desde el principio.
        ruta_respaldo = _archivar_copia_en_versionado(remote_path, v["tipo"], version_tag)

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    usuario = session.get("usuario", "desconocido")
    with _db() as conn:
        if es_nuevo:
            detalle_accion = f"Archivo nuevo (no existía en PROD). Primera versión archivada en Versionado: {ruta_respaldo}"
        elif ruta_respaldo:
            detalle_accion = f"Original respaldado en: {ruta_respaldo}"
        else:
            detalle_accion = None
        if err:
            detalle_accion = f"{detalle_accion} | {err}" if detalle_accion else err

        conn.execute("""
            INSERT INTO deploy_historial_acciones (version_id, accion, usuario, fecha, resultado, detalle)
            VALUES (?, 'implementar', ?, ?, ?, ?)
        """, (vid, usuario, ts, "ok" if ok else "error", detalle_accion))
        if ok:
            conn.execute("""
                UPDATE deploy_versiones
                SET estado='en_prod', ruta_prod=?, fecha_implementacion=?, ruta_respaldo_original=?
                WHERE id=?
            """, (remote_path, ts, ruta_respaldo, vid))
        conn.commit()

    if not ok:
        return jsonify({"ok": False, "error": f"Fallo el SFTP hacia PROD: {err}"}), 500

    return jsonify({"ok": True, "ruta_prod": remote_path, "ruta_respaldo_original": ruta_respaldo,
                     "es_nuevo": es_nuevo, "checklist_pct": pct, "checklist_pendientes": pendientes,
                     "azure_gate": gate})


@app.route("/api/deploy/bajar/<int:vid>", methods=["GET"])
@login_required
def api_deploy_bajar(vid):
    """
    Descarga desde PROD hacia la máquina local del usuario, vía el navegador.
      ?modo=archivo (default) -> baja solo el archivo implementado.
      ?modo=carpeta           -> baja TODA la carpeta destino en PROD, comprimida en .zip.
    """
    modo = (request.args.get("modo") or "archivo").lower()

    with _db() as conn:
        v = conn.execute("SELECT * FROM deploy_versiones WHERE id=?", (vid,)).fetchone()
        if not v:
            return jsonify({"ok": False, "error": "Versión no encontrada"}), 404
        v = dict(v)

    if not v.get("ruta_prod"):
        return jsonify({"ok": False, "error": "Esta versión todavía no fue implementada en PROD."}), 400

    safe_nombre = re.sub(r'[^\w\-\.]', '_', v["nombre_proceso"])
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    usuario = session.get("usuario", "desconocido")

    if modo == "carpeta":
        carpeta_remota = v.get("destino_dir") or posixpath.dirname(v["ruta_prod"])
        nombre_zip = f"{safe_nombre}_v{v['version']}"
        zip_path, error_detalle = _zip_carpeta_remota(carpeta_remota, nombre_zip)

        with _db() as conn:
            conn.execute("""
                INSERT INTO deploy_historial_acciones (version_id, accion, usuario, fecha, resultado, detalle)
                VALUES (?, 'bajar_carpeta', ?, ?, ?, ?)
            """, (vid, usuario, ts, "ok" if zip_path else "error", error_detalle or ""))
            conn.commit()

        if not zip_path:
            return jsonify({"ok": False, "error": f"Fallo al bajar la carpeta desde PROD: {error_detalle}"}), 500

        return send_file(zip_path, as_attachment=True, download_name=f"{nombre_zip}.zip")

    # modo == "archivo": solo el archivo implementado
    destino_local = DESCARGAS_DIR / v["tipo"] / safe_nombre
    destino_local.mkdir(parents=True, exist_ok=True)
    local_file = destino_local / v["archivo_nombre"]

    ok, err = _sftp_get(v["ruta_prod"], local_file)

    with _db() as conn:
        conn.execute("""
            INSERT INTO deploy_historial_acciones (version_id, accion, usuario, fecha, resultado, detalle)
            VALUES (?, 'bajar', ?, ?, ?, ?)
        """, (vid, usuario, ts, "ok" if ok else "error", err))
        conn.commit()

    if not ok:
        return jsonify({"ok": False, "error": f"Fallo el SFTP desde PROD: {err}"}), 500

    return send_file(str(local_file), as_attachment=True, download_name=v["archivo_nombre"])


@app.route("/api/deploy/historial")
@login_required
def api_deploy_historial():
    with _db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM deploy_versiones ORDER BY id DESC LIMIT 200").fetchall()]
    return jsonify({"ok": True, "versiones": rows})


def _query_historial_acciones(desde=None, hasta=None, q=None, limit=500):
    sql = """
        SELECT ha.id, ha.accion, ha.usuario, ha.fecha, ha.resultado, ha.detalle, ha.nota_manual,
               v.id AS version_id, v.tipo, v.nombre_proceso, v.version_tag, v.id_hu, v.destino_dir,
               v.ruta_prod, v.ruta_documentacion
        FROM deploy_historial_acciones ha
        JOIN deploy_versiones v ON v.id = ha.version_id
        WHERE 1=1
    """
    params = []
    if desde:
        sql += " AND ha.fecha >= ?"
        params.append(f"{desde} 00:00:00")
    if hasta:
        sql += " AND ha.fecha <= ?"
        params.append(f"{hasta} 23:59:59")
    if q:
        sql += """ AND (ha.usuario LIKE ? OR v.nombre_proceso LIKE ? OR v.tipo LIKE ?
                        OR v.id_hu LIKE ? OR ha.detalle LIKE ? OR ha.nota_manual LIKE ?)"""
        like = f"%{q}%"
        params += [like, like, like, like, like, like]
    sql += " ORDER BY ha.id DESC LIMIT ?"
    params.append(limit)
    with _db() as conn:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]


def _etiqueta_accion(accion, resultado):
    """Texto legible: si ya se implementó (resultado ok), se muestra en pasado."""
    if accion == "implementar":
        return "Implementado" if resultado == "ok" else "Falló la implementación"
    if accion == "bajar":
        return "Descargado" if resultado == "ok" else "Falló la descarga"
    if accion == "bajar_carpeta":
        return "Carpeta descargada" if resultado == "ok" else "Falló la descarga de carpeta"
    return accion


def _etiqueta_resultado(resultado):
    return "Productivo" if resultado == "ok" else "Error"


@app.route("/api/deploy/historial_acciones")
@login_required
def api_deploy_historial_acciones():
    """
    Historial completo de implementaciones y descargas (quién, cuándo, qué
    resultado), guardado en el mismo historial_pbix.db que el resto del portal.
    Soporta filtros: ?desde=YYYY-MM-DD&hasta=YYYY-MM-DD&q=texto
    """
    desde = request.args.get("desde", "").strip()
    hasta = request.args.get("hasta", "").strip()
    q = request.args.get("q", "").strip()
    rows = _query_historial_acciones(desde or None, hasta or None, q or None)
    for r in rows:
        pct, hechos, total_items, pendientes = _checklist_estado(r["version_id"], r["tipo"])
        r["checklist_pct"] = pct
        r["checklist_hechos"] = hechos
        r["checklist_total"] = total_items
        r["checklist_pendientes"] = pendientes
        r["accion_texto"] = _etiqueta_accion(r["accion"], r["resultado"])
        r["resultado_texto"] = _etiqueta_resultado(r["resultado"])
    return jsonify({"ok": True, "acciones": rows})


@app.route("/api/deploy/historial_acciones/<int:aid>")
@login_required
def api_deploy_historial_detalle_uno(aid):
    """Detalle completo de una acción puntual del historial, para mostrar en el modal de nota."""
    with _db() as conn:
        row = conn.execute("""
            SELECT ha.id, ha.accion, ha.usuario, ha.fecha, ha.resultado, ha.detalle, ha.nota_manual,
                   v.tipo, v.nombre_proceso, v.version_tag, v.id_hu, v.destino_dir, v.ruta_prod,
                   v.ruta_documentacion, v.lider_proyecto, v.analista_asignado
            FROM deploy_historial_acciones ha
            JOIN deploy_versiones v ON v.id = ha.version_id
            WHERE ha.id = ?
        """, (aid,)).fetchone()
    if not row:
        return jsonify({"ok": False, "error": "No se encontró ese registro"}), 404
    return jsonify({"ok": True, "accion": dict(row)})


@app.route("/api/deploy/historial_acciones/<int:aid>/nota", methods=["POST"])
@login_required
def api_deploy_historial_nota(aid):
    """Guarda un comentario/detalle manual sobre una acción del historial."""
    data = request.get_json(force=True) or {}
    nota = (data.get("nota") or "").strip()
    with _db() as conn:
        cur = conn.execute("UPDATE deploy_historial_acciones SET nota_manual=? WHERE id=?", (nota, aid))
        conn.commit()
        if cur.rowcount == 0:
            return jsonify({"ok": False, "error": "No se encontró ese registro"}), 404
    return jsonify({"ok": True})


@app.route("/api/deploy/historial_acciones/export_pdf")
@login_required
def api_deploy_historial_export_pdf():
    """Exporta a PDF el historial de implementaciones: documento profesional
    y auditable, con metadata de generación, filtros aplicados, y pie de
    página con numeración y autoría en cada hoja."""
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.units import cm
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.pdfgen import canvas as _canvas_mod
    except ImportError:
        return jsonify({"ok": False, "error": "Falta instalar 'reportlab' en el servidor. "
                         "Corré: pip install -r requirements.txt --break-system-packages "
                         "y reiniciá el servicio."}), 500

    desde = request.args.get("desde", "").strip()
    hasta = request.args.get("hasta", "").strip()
    q = request.args.get("q", "").strip()
    rows = _query_historial_acciones(desde or None, hasta or None, q or None, limit=2000)

    try:
        NAVY = colors.HexColor("#1e3a5f")
        CORAL = colors.HexColor("#cc785c")
        LIGHT_BG = colors.HexColor("#f7f4f0")
        GRID_GRAY = colors.HexColor("#e4e0da")

        styles = getSampleStyleSheet()
        celda_style = ParagraphStyle("celda", parent=styles["Normal"], fontSize=7.5, leading=9.5)
        celda_bold = ParagraphStyle("celda_bold", parent=celda_style, fontName="Helvetica-Bold", textColor=colors.white)
        meta_label = ParagraphStyle("meta_label", parent=styles["Normal"], fontSize=7.7,
                                     textColor=colors.HexColor("#7a746c"))
        meta_valor = ParagraphStyle("meta_valor", parent=styles["Normal"], fontSize=8.3,
                                     fontName="Helvetica-Bold", textColor=NAVY)
        banner_title = ParagraphStyle("banner_title", parent=styles["Normal"], fontSize=20,
                                       fontName="Helvetica-Bold", textColor=colors.white, leading=24)
        banner_sub = ParagraphStyle("banner_sub", parent=styles["Normal"], fontSize=9.5,
                                     textColor=colors.HexColor("#cbd5e1"))
        kpi_num_style = ParagraphStyle("kpi_num", parent=styles["Normal"], fontSize=20, leading=24,
                                        fontName="Helvetica-Bold", alignment=1)
        kpi_label_style = ParagraphStyle("kpi_label", parent=styles["Normal"], fontSize=8, leading=10,
                                          textColor=colors.HexColor("#5c574f"), alignment=1)
        checklist_style = ParagraphStyle("checklist", parent=styles["Normal"], fontSize=7.5, leading=9.5)
        pendientes_style = ParagraphStyle("pendientes", parent=styles["Normal"], fontSize=7,
                                           leading=8.5, textColor=colors.HexColor("#9a6700"))

        ahora = datetime.now()
        usuario_actual = session.get("nombre") or session.get("usuario") or "desconocido"
        id_reporte = f"RPT-{ahora.strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6].upper()}"

        rango = f"{desde or 'sin límite'} — {hasta or 'sin límite'}" if (desde or hasta) else "Todas las fechas"
        filtro_texto = q if q else "Sin filtro de texto"

        # ── Datos útiles: estadísticas del período reportado ──────
        total = len(rows)
        ok_count = sum(1 for r in rows if r["resultado"] == "ok")
        error_count = total - ok_count
        con_md = sum(1 for r in rows if r.get("ruta_documentacion"))
        sin_md = total - con_md
        por_tipo = {}
        for r in rows:
            por_tipo[r["tipo"]] = por_tipo.get(r["tipo"], 0) + 1
        usuarios_unicos = len({r["usuario"] for r in rows if r.get("usuario")})

        ancho_pagina_pts = landscape(A4)[0]
        ancho_util_cm = (ancho_pagina_pts / cm) - 2.6  # menos los márgenes izq/der

        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=landscape(A4),
                                 leftMargin=1.3*cm, rightMargin=1.3*cm, topMargin=1.1*cm, bottomMargin=1.6*cm,
                                 title="Historial de implementaciones — ETL Governance Portal",
                                 author="Willian Arce — Gobierno de Datos, Banco Continental")

        # ── Banner de encabezado, con color en vez de texto negro plano ──
        banner = Table([[
            Paragraph("ETL GOVERNANCE PORTAL &nbsp;·&nbsp; BANCO CONTINENTAL", banner_sub),
        ], [
            Paragraph("Historial de Implementaciones", banner_title),
        ], [
            Paragraph(f"Período: {rango} &nbsp;·&nbsp; Generado el {ahora.strftime('%Y-%m-%d %H:%M')} por {usuario_actual}", banner_sub),
        ]], colWidths=[ancho_util_cm*cm])
        banner.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), NAVY),
            ("LEFTPADDING", (0, 0), (-1, -1), 16),
            ("RIGHTPADDING", (0, 0), (-1, -1), 16),
            ("TOPPADDING", (0, 0), (-1, 0), 10),
            ("BOTTOMPADDING", (0, 0), (-1, 0), 2),
            ("TOPPADDING", (0, 1), (-1, 1), 2),
            ("BOTTOMPADDING", (0, 1), (-1, 1), 4),
            ("TOPPADDING", (0, 2), (-1, 2), 2),
            ("BOTTOMPADDING", (0, 2), (-1, 2), 10),
        ]))

        elementos = [banner, Spacer(1, 12)]

        # ── Tarjetas de KPI: datos útiles de un vistazo ───────────
        def _tarjeta(numero, etiqueta, color_fondo, color_texto):
            t = Table([[Paragraph(str(numero), ParagraphStyle("n", parent=kpi_num_style, textColor=color_texto))],
                       [Paragraph(etiqueta, kpi_label_style)]], colWidths=[ancho_util_cm/6*cm])
            t.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), color_fondo),
                ("TOPPADDING", (0, 0), (-1, 0), 10),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 2),
                ("TOPPADDING", (0, 1), (-1, 1), 0),
                ("BOTTOMPADDING", (0, 1), (-1, 1), 10),
                ("BOX", (0, 0), (-1, -1), 0.5, GRID_GRAY),
            ]))
            return t

        tarjetas = Table([[
            _tarjeta(total, "Total registros", LIGHT_BG, NAVY),
            _tarjeta(ok_count, "Exitosas (ok)", colors.HexColor("#eaf3ec"), colors.HexColor("#3a7d52")),
            _tarjeta(error_count, "Con error", colors.HexColor("#faece8"), colors.HexColor("#b3492f")),
            _tarjeta(con_md, "Con .md", colors.HexColor("#eaf3ec"), colors.HexColor("#3a7d52")),
            _tarjeta(sin_md, "Sin .md", colors.HexColor("#fdf3e3"), colors.HexColor("#9a6700")),
            _tarjeta(usuarios_unicos, "Usuarios distintos", LIGHT_BG, NAVY),
        ]], colWidths=[ancho_util_cm/6*cm]*6)
        tarjetas.setStyle(TableStyle([
            ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        elementos += [tarjetas, Spacer(1, 10)]

        # ── Distribución por tipo de proceso ──────────────────────
        if por_tipo:
            partes = " &nbsp;&nbsp; ".join(
                f'<font color="#1e3a5f"><b>{t}</b></font>: {c}' for t, c in sorted(por_tipo.items()))
            elementos += [Paragraph(f"Por tipo de proceso: {partes}", meta_valor), Spacer(1, 10)]

        # ── Metadata compacta (auditoría) ─────────────────────────
        meta_tabla = Table([
            [Paragraph("ID de reporte", meta_label), Paragraph(id_reporte, meta_valor),
             Paragraph("Filtro de texto", meta_label), Paragraph(filtro_texto, meta_valor)],
        ], colWidths=[2.6*cm, ancho_util_cm/2*cm - 2.6*cm, 2.8*cm, ancho_util_cm/2*cm - 2.8*cm])
        meta_tabla.setStyle(TableStyle([
            ("BOX", (0, 0), (-1, -1), 0.5, GRID_GRAY),
            ("BACKGROUND", (0, 0), (-1, -1), LIGHT_BG),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ]))
        elementos += [meta_tabla, Spacer(1, 14)]

        encabezado = ["Fecha", "Acción", "Usuario", "Tipo", "Proceso", "Versión", "HU",
                       "Resultado", ".md", "Checklist", "Detalle", "Nota", "Pendientes de checklist"]
        data_tabla = [[Paragraph(h, celda_bold) for h in encabezado]]

        for r in rows:
            fecha_dos_lineas = (r["fecha"] or "").replace(" ", "<br/>")
            tiene_md = bool(r.get("ruta_documentacion"))
            doc_txt = "✔" if tiene_md else "✗ sin .md"
            doc_estilo = celda_style if tiene_md else ParagraphStyle(
                "sin_md", parent=celda_style, textColor=colors.HexColor("#b3492f"))
            resultado_estilo = celda_style if r["resultado"] == "ok" else ParagraphStyle(
                "res_err", parent=celda_style, textColor=colors.HexColor("#b3492f"), fontName="Helvetica-Bold")

            pct, hechos, total_items, pendientes = _checklist_estado(r["version_id"], r["tipo"])
            checklist_txt = f"{pct}% ({hechos}/{total_items})"
            checklist_estilo = checklist_style if pct == 100 else ParagraphStyle(
                "chk_incompleto", parent=checklist_style,
                textColor=colors.HexColor("#3a7d52") if pct >= 55 else colors.HexColor("#b3492f"))
            # Lista real (una línea por ítem, con viñeta), no todo pegado en un párrafo corrido.
            pendientes_txt = "Completo" if not pendientes else "<br/>".join(f"• {p}" for p in pendientes)

            data_tabla.append([
                Paragraph(fecha_dos_lineas, celda_style),
                Paragraph(_etiqueta_accion(r["accion"], r["resultado"]), celda_style),
                Paragraph(r["usuario"] or "", celda_style),
                Paragraph(r["tipo"] or "", celda_style),
                Paragraph(r["nombre_proceso"] or "", celda_style),
                Paragraph(r.get("version_tag") or "", celda_style),
                Paragraph(r.get("id_hu") or "", celda_style),
                Paragraph(_etiqueta_resultado(r["resultado"]), resultado_estilo),
                Paragraph(doc_txt, doc_estilo),
                Paragraph(checklist_txt, checklist_estilo),
                Paragraph((r.get("detalle") or "-")[:250], celda_style),
                Paragraph((r.get("nota_manual") or "-")[:200], celda_style),
                Paragraph(pendientes_txt[:400], pendientes_style if pendientes else celda_style),
            ])

        tabla = Table(data_tabla, repeatRows=1,
                       colWidths=[1.6*cm, 2.0*cm, 1.6*cm, 1.1*cm, 2.4*cm, 1.2*cm, 1.2*cm,
                                  1.7*cm, 1.4*cm, 1.6*cm, 3.2*cm, 2.6*cm, 3.9*cm])
        tabla.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), CORAL),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.4, GRID_GRAY),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_BG]),
            ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        elementos.append(tabla)

        if not rows:
            elementos.append(Spacer(1, 10))
            elementos.append(Paragraph("No se encontraron registros para los filtros aplicados.", styles["Normal"]))

        # ── Pie de página en cada hoja: autoría + numeración ──────
        class _CanvasConPie(_canvas_mod.Canvas):
            def __init__(self, *args, **kwargs):
                _canvas_mod.Canvas.__init__(self, *args, **kwargs)
                self._paginas = []

            def showPage(self):
                self._paginas.append(dict(self.__dict__))
                self._startPage()

            def save(self):
                total_pag = len(self._paginas)
                for estado in self._paginas:
                    self.__dict__.update(estado)
                    self._dibujar_pie(total_pag)
                    _canvas_mod.Canvas.showPage(self)
                _canvas_mod.Canvas.save(self)

            def _dibujar_pie(self, total_paginas):
                ancho_pagina = landscape(A4)[0]
                self.setStrokeColor(GRID_GRAY)
                self.setLineWidth(0.5)
                self.line(1.3*cm, 1.15*cm, ancho_pagina - 1.3*cm, 1.15*cm)
                self.setFont("Helvetica", 7.5)
                self.setFillColor(colors.HexColor("#767676"))
                self.drawString(1.3*cm, 0.9*cm, "Desarrollado por Willian Arce — © " + str(ahora.year))
                self.drawCentredString(ancho_pagina/2, 0.9*cm,
                                       f"ETL Governance Portal — Banco Continental — {id_reporte}")
                self.drawRightString(ancho_pagina - 1.3*cm, 0.9*cm,
                                      f"Página {self._pageNumber} de {total_paginas}")

        doc.build(elementos, canvasmaker=_CanvasConPie)
        buf.seek(0)
    except Exception as e:
        app.logger.error("Error generando PDF: %s", e)
        return jsonify({"ok": False, "error": f"Error generando el PDF: {e}"}), 500

    nombre = f"historial_implementaciones_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    return send_file(buf, mimetype="application/pdf", as_attachment=True, download_name=nombre)


# ════════════════════════════════════════════════════════
#  AZURE DEVOPS — User Stories Gobierno de Datos
# ════════════════════════════════════════════════════════

def _ora():
    """Conexión Oracle para consultar Azure DevOps HUs."""
    import oracledb
    return oracledb.connect(user="DASHBOARD", password="DASHBOARD", dsn="10.1.1.2:1521/DWHPROD")


def _azure_get(url):
    resp = requests.get(url, auth=("", AZURE_PAT), timeout=15)
    resp.raise_for_status()
    return resp.json()


def _azure_project_encoded():
    """Codifica el nombre del proyecto (puede tener espacios) para usarlo en la URL."""
    from urllib.parse import quote
    return quote(AZURE_PROJECT, safe="")


def _azure_info_basica(id_hu):
    """Trae solo título y estado de una HU — no depende de los campos de aprobación."""
    if not (AZURE_ORG and AZURE_PROJECT and AZURE_PAT):
        return {"ok": False, "error": "Azure DevOps no está configurado (falta ORG/PROJECT/PAT)."}
    try:
        url = (f"https://dev.azure.com/{AZURE_ORG}/{_azure_project_encoded()}/_apis/wit/workitems/"
               f"{id_hu}?fields=System.Title,System.State&api-version=7.1")
        data = _azure_get(url)
        f = data.get("fields", {})
        return {"ok": True, "titulo": f.get("System.Title", ""), "estado": f.get("System.State", "")}
    except Exception as e:
        return {"ok": False, "error": f"No se encontró la HU o falló la consulta: {e}"}


def _azure_display_name(valor):
    """Los campos de identidad de Azure DevOps a veces vienen como dict
    ({'displayName':..., 'uniqueName':...}) y a veces como texto plano,
    según el tipo de campo. Normaliza a un string simple."""
    if isinstance(valor, dict):
        return valor.get("displayName", "") or valor.get("uniqueName", "")
    return valor or ""


def _azure_desarrollador_por_tipo(campos, tipo_work_item):
    """Misma lógica condicional que ya usás en el notebook de reporte:
    el campo de 'desarrollador/analista asignado' cambia según el tipo de work item."""
    if tipo_work_item == "User Story Desarrollo":
        return _azure_display_name(campos.get(AZURE_FIELD_DESARROLLADOR_HU))
    elif tipo_work_item == "Bug":
        return _azure_display_name(campos.get(AZURE_FIELD_DESARROLLADOR_BUG))
    elif tipo_work_item == "User Story Datos":
        return _azure_display_name(campos.get(AZURE_FIELD_ANALISTA_DATOS))
    else:
        return _azure_display_name(campos.get(AZURE_FIELD_DESARROLLADOR_OTRO))


def _azure_obtener_workitem(id_hu, con_relaciones=False):
    """Trae un work item completo (todos sus campos). Si con_relaciones=True,
    incluye también sus relaciones (necesario para poder encontrar el padre)."""
    expand = "&$expand=relations" if con_relaciones else ""
    url = (f"https://dev.azure.com/{AZURE_ORG}/{_azure_project_encoded()}/_apis/wit/workitems/"
           f"{id_hu}?api-version=7.1{expand}")
    return _azure_get(url)


def _azure_resumen_item(id_hu, con_padre=True):
    """
    Devuelve un resumen de una HU/Tarea/Bug: tipo de work item, título, estado,
    líder de proyecto y desarrollador asignado (con la lógica condicional según
    el tipo). Si es una Tarea y con_padre=True, además resuelve y agrega el
    resumen de la HU padre (porque una Tarea no siempre tiene cargados los
    mismos campos que sí tiene la HU madre).
    """
    if not (AZURE_ORG and AZURE_PROJECT and AZURE_PAT):
        return {"ok": False, "error": "Azure DevOps no está configurado (falta ORG/PROJECT/PAT)."}
    try:
        data = _azure_obtener_workitem(id_hu, con_relaciones=con_padre)
    except Exception as e:
        return {"ok": False, "error": f"No se encontró el ítem {id_hu} o falló la consulta: {e}"}

    f = data.get("fields", {})
    tipo = f.get("System.WorkItemType", "")
    resumen = {
        "id": str(id_hu),
        "titulo": f.get("System.Title", ""),
        "estado": f.get("System.State", ""),
        "tipo": tipo,
        "lider_proyecto": _azure_display_name(f.get(AZURE_FIELD_LIDER_PROYECTO)),
        "desarrollador_asignado": _azure_desarrollador_por_tipo(f, tipo),
        "hu_padre": None,
    }

    es_tarea = tipo.strip().lower() in ("task", "tarea")
    if con_padre and es_tarea:
        parent_id = None
        for rel in data.get("relations", []) or []:
            if rel.get("rel") == "System.LinkTypes.Hierarchy-Reverse":
                parent_id = rel["url"].rstrip("/").split("/")[-1]
                break
        if parent_id:
            padre = _azure_resumen_item(parent_id, con_padre=False)
            if padre.get("ok"):
                resumen["hu_padre"] = padre["resumen"]

    return {"ok": True, "resumen": resumen}


@app.route("/api/azure/resumen/<id_hu>")
@login_required
def api_azure_resumen(id_hu):
    """
    Resumen completo de una HU/Tarea/Bug para mostrar en el formulario de
    Deploy: tipo de work item, líder de proyecto, desarrollador asignado, y
    si es una Tarea, también el resumen de la HU padre.
    """
    return jsonify(_azure_resumen_item(id_hu))


def _azure_gate(id_hu):
    """
    Valida en vivo contra la API de Azure DevOps que la HU (o, si el ítem es
    una Tarea, su HU padre — porque los campos de aprobación viven ahí, no en
    la Tarea) tenga:
      - Comentario de Aprobación del Scrum Master (no vacío)
      - Autorización del Product Owner (no vacía)
    Devuelve {"ok": bool, "motivo": str, "detalle": {...}} sin bloquear si
    AZURE_PAT / AZURE_ORG no están configurados: en ese caso avisa en vez de fallar en falso.
    """
    if not (AZURE_ORG and AZURE_PROJECT and AZURE_PAT):
        return {"ok": False, "motivo": "Azure DevOps no está configurado (falta ORG/PROJECT/PAT)."}

    if not (AZURE_FIELD_SCRUM and AZURE_FIELD_PO):
        basica = _azure_info_basica(id_hu)
        motivo = ("Faltan configurar los reference names de los campos de aprobación "
                   "(correr /api/azure/discover_fields).")
        if basica.get("ok"):
            return {"ok": False, "motivo": motivo,
                    "detalle": {"titulo": basica["titulo"], "estado": basica["estado"]}}
        return {"ok": False, "motivo": basica.get("error", motivo)}

    try:
        data = _azure_obtener_workitem(id_hu, con_relaciones=True)
    except Exception as e:
        return {"ok": False, "motivo": f"Error consultando Azure DevOps: {e}"}

    f = data.get("fields", {})
    tipo = f.get("System.WorkItemType", "")
    titulo = f.get("System.Title", "")
    estado = f.get("System.State", "")
    es_tarea = tipo.strip().lower() in ("task", "tarea")

    # Por default, se valida sobre el mismo ítem consultado.
    campos_aprobacion = f
    validado_via_padre = None

    if es_tarea:
        parent_id = None
        for rel in data.get("relations", []) or []:
            if rel.get("rel") == "System.LinkTypes.Hierarchy-Reverse":
                parent_id = rel["url"].rstrip("/").split("/")[-1]
                break
        if not parent_id:
            return {"ok": False, "motivo": "Es una Tarea sin HU padre vinculada — no se puede validar la aprobación.",
                     "detalle": {"titulo": titulo, "estado": estado, "tipo": tipo}}
        try:
            data_padre = _azure_obtener_workitem(parent_id)
        except Exception as e:
            return {"ok": False, "motivo": f"No se pudo consultar la HU padre ({parent_id}): {e}",
                     "detalle": {"titulo": titulo, "estado": estado, "tipo": tipo}}
        campos_aprobacion = data_padre.get("fields", {})
        validado_via_padre = parent_id

    scrum_ok = bool((campos_aprobacion.get(AZURE_FIELD_SCRUM) or "").strip())
    po_ok    = bool((campos_aprobacion.get(AZURE_FIELD_PO) or "").strip())
    detalle  = {
        "titulo": titulo, "estado": estado, "tipo": tipo,
        "comentario_scrum": campos_aprobacion.get(AZURE_FIELD_SCRUM),
        "autorizacion_po": campos_aprobacion.get(AZURE_FIELD_PO),
        "validado_via_hu_padre": validado_via_padre,
    }

    faltantes = []
    if not scrum_ok:
        faltantes.append("el Comentario de Aprobación del Scrum Master")
    if not po_ok:
        faltantes.append("la Autorización del Product Owner")

    sujeto = f"en la HU padre ({validado_via_padre})" if validado_via_padre else "en la HU"
    if faltantes:
        motivo = "Falta " + " y falta ".join(faltantes) + f" {sujeto}."
        return {"ok": False, "motivo": motivo, "detalle": detalle}

    ok_msg = None
    if validado_via_padre:
        ok_msg = f"Aprobado vía HU padre {validado_via_padre}."
    return {"ok": True, "detalle": detalle, "motivo": ok_msg}


@app.route("/api/azure/info/<id_hu>")
@login_required
def api_azure_info(id_hu):
    """Título y estado de una HU — para mostrar en vivo mientras se escribe el ID."""
    return jsonify(_azure_info_basica(id_hu))


@app.route("/api/azure/detalle/<id_hu>")
@login_required
def api_azure_detalle(id_hu):
    """Trae título, estado y el estado de las dos aprobaciones para una HU puntual."""
    gate = _azure_gate(id_hu)
    return jsonify(gate)


@app.route("/api/azure/discover_fields")
@login_required
def api_azure_discover_fields():
    """
    Ayuda de una sola vez: lista los campos de Azure DevOps cuyo nombre visible
    contenga 'Aprobaci' o 'Autorizaci', para identificar el referenceName real
    y cargarlo en AZURE_FIELD_SCRUM / AZURE_FIELD_PO (variables de entorno).
    """
    if not (AZURE_ORG and AZURE_PAT):
        return jsonify({"ok": False, "error": "Falta configurar AZURE_DEVOPS_ORG / AZURE_DEVOPS_PAT"}), 400
    try:
        url = f"https://dev.azure.com/{AZURE_ORG}/_apis/wit/fields?api-version=7.1"
        data = _azure_get(url)
        matches = [f for f in data.get("value", [])
                   if "aprobaci" in f.get("name", "").lower()
                   or "autorizaci" in f.get("name", "").lower()]
        return jsonify({"ok": True, "matches": matches})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/azure")
@login_required
def azure_hus():
    return render_template("azure_hus.html")

@app.route("/api/azure/hus")
@login_required
def api_azure_hus():
    """Retorna las HUs de Gobierno de Datos desde DASHBOARD.AZURE_CABECERA."""
    try:
        conn = _ora()
        cur = conn.cursor()
        cur.execute("""
            SELECT
                ac.ID_HU,
                ac.TITULO,
                ac.DESCRIPCION,
                ac.ESTADO,
                ac.RAZON,
                ac.AREA,
                ac.TEAM_PROJECT,
                ac.SPRING,
                ac.TIPO,
                ac.ASIGNADO_A,
                ac.CREADO_POR,
                ac.CAMBIADO_POR,
                ac.FECHA_CREACION,
                ac.FECHA_CAMBIO,
                ac.FECHA_CIERRE,
                ac.FECHA_CAMBIO_ESTADO,
                ac.FECHA_NEW,
                ac.FECHA_ACTIVE,
                ac.FECHA_CLOSED,
                ac.FECHA_POSTPRODUCCION,
                ac.FECHAESTIMATIVA,
                ac.TAGS,
                ac.ACTIVITY,
                ac.DESARROLLADORASIGNADO,
                ac.LIDERTECNICO,
                ac.LIDER_PROYECTO,
                ac.ESTADO_PRUEBA_ACEPTACION,
                ac.GRADO_DE_CONFORMIDAD,
                ac.NRO_SERVICE_DESK,
                ac.COMENTARIO
            FROM DASHBOARD.AZURE_CABECERA ac
            WHERE UPPER(ac.AREA) LIKE '%GOBIERNO%DATO%'
               OR UPPER(ac.AREA) LIKE '%LABORATORIO%DATO%'
               OR UPPER(ac.AREA) LIKE '%GOBERNANZA%'
            ORDER BY ac.ID_HU DESC
        """)
        cols = [d[0] for d in cur.description]
        rows = []
        date_cols = ('FECHA_CREACION','FECHA_CAMBIO','FECHA_CIERRE',
                     'FECHA_CAMBIO_ESTADO','FECHA_NEW','FECHA_ACTIVE',
                     'FECHA_CLOSED','FECHA_POSTPRODUCCION','FECHAESTIMATIVA',
                     'FECHA_INSERT')
        for r in cur.fetchall():
            row = dict(zip(cols, r))
            # Convertir LOBs (CLOB/BLOB) a string
            for k, v in row.items():
                if hasattr(v, 'read'):
                    row[k] = v.read()
            for k in date_cols:
                if row.get(k):
                    row[k] = row[k].isoformat() if hasattr(row[k], 'isoformat') else str(row[k])
            rows.append(row)
        cur.close()
        conn.close()
        return jsonify({"ok": True, "data": rows, "count": len(rows)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e), "data": []})


if __name__ == "__main__":
    print("\n  ETL Governance Portal — Banco Continental")
    print("  http://localhost:5000\n")
    app.run(host="0.0.0.0", port=5000, debug=False)
