# Módulo de Deploy — Versionado, Implementar, Bajar

Este módulo se agregó a `server.py` sobre tu portal existente, en `/deploy`.

## Qué hace

1. **Nueva versión** (KTR, JOB o Python): subís un `.zip` (script + dependencias + `.md`), con el nombre del proceso y el ID de la HU en Azure DevOps.
2. **Explorador visual de carpetas**: en vez de escribir el path completo, elegís desde el portal la subcarpeta exacta dentro de la raíz configurada (`/pentaho/project/` por defecto) navegando visualmente — igual que un explorador de archivos. La raíz se define una sola vez en `.env`; el resto se navega con clics.
3. **Nombre de versión**: si el proceso ya existe, el portal **te avisa** ("Ya existe este proceso, ¿deseás versionar?") y te sugiere el nombre estándar siguiente (`v2`, `v3`, …) precargado y editable. Si no tocás el campo, se guarda con ese estándar; si lo editás, se guarda con lo que pongas.
4. **Checklist**: cada versión nace con el checklist de la HU (los mismos criterios de aceptación de Job, KTR o Python).
5. **Implementar**: sube el `.zip` a la carpeta elegida en PROD, por SFTP, **solo si**:
   - el checklist está 100% marcado, **y**
   - la HU en Azure DevOps tiene el Comentario de Aprobación del Scrum Master y la Autorización del Product Owner completos (consultado en vivo vía API).
   Si falta algo, rechaza y lista los motivos.
6. **Bajar**: descarga directo a tu máquina (vía el navegador), con dos modos:
   - **Bajar archivo**: solo el `.zip` implementado.
   - **Bajar carpeta**: toda la carpeta de destino en PROD, comprimida en un `.zip` nuevo, para revisar todo lo que hay ahí (incluido lo que no subiste vos).
7. **Python & ML**: cada script guardado en `/python` tiene un botón "Enviar a Deploy", que lo empaqueta automáticamente y lo mete en el mismo flujo (checklist → carpeta → implementar) que KTR y JOB, usando la misma raíz configurable.

## Configuración pendiente de tu lado

1. Copiá `.env.example` a `.env` (o cargá las variables en tu entorno) y completá:
   - `PENTAHO_PROD_KTR_PATH` / `PENTAHO_PROD_JOB_PATH` / `PENTAHO_PROD_PY_PATH`: la carpeta **raíz** en el servidor Pentaho (ya viene precargada como `/pentaho/project/`). No hace falta poner la ruta completa: el resto se elige visualmente en `/deploy`.
   - `AZURE_DEVOPS_ORG`, `AZURE_DEVOPS_PROJECT`, `AZURE_DEVOPS_PAT`: ya cargados con los datos que me pasaste.

   ⚠️ **Importante:** el PAT que me compartiste quedó pegado en esta conversación. Por las dudas, te recomiendo regenerarlo en Azure DevOps (`User settings → Personal access tokens`) y usar el nuevo en tu `.env`, en vez del que ya circuló acá.

2. **Una sola vez**, con el portal corriendo y logueado, entrá a:
   ```
   GET /api/azure/discover_fields
   ```
   Te devuelve la lista de campos cuyo nombre contiene "Aprobaci" o "Autorizaci", con su `referenceName` real (algo tipo `Custom.XXXX`). Copiá los dos que correspondan a:
   - "Comentario de Aprobación del Scrum Master"
   - "Autorización del Product Owner"

   y pegalos en `AZURE_FIELD_SCRUM` / `AZURE_FIELD_PO` en tu `.env`.
3. Instalá la dependencia nueva: `pip install -r requirements.txt --break-system-packages` (se agregó `requests`).
4. Nunca subas `.env` al repositorio — agregalo a `.gitignore` si no está.
5. Reiniciá el servicio del portal.

## Nuevas rutas

| Ruta | Método | Qué hace |
|---|---|---|
| `/deploy` | GET | Pantalla de versionado, con explorador visual de carpetas |
| `/api/deploy/browse` | GET | Lista subcarpetas de la raíz configurada, para elegir destino sin escribir el path |
| `/api/deploy/check_existente` | GET | Avisa si el proceso ya existe y sugiere el nombre de versión estándar |
| `/api/deploy/nueva_version` | POST | Sube una nueva versión (.zip) a una carpeta destino elegida |
| `/api/deploy/checklist/<id>` | GET/POST | Lee o marca el checklist |
| `/api/deploy/implementar/<id>` | POST | Valida checklist + gate de Azure y sube a la carpeta elegida en PROD |
| `/api/deploy/bajar/<id>?modo=archivo\|carpeta` | GET | Descarga a tu máquina el archivo, o toda la carpeta de PROD comprimida |
| `/api/deploy/historial` | GET | Lista todas las versiones |
| `/api/python/enviar_a_deploy/<sid>` | POST | Empaqueta un script de Python guardado y lo manda al flujo de Deploy |
| `/api/azure/detalle/<id_hu>` | GET | Título, estado y aprobaciones de una HU |
| `/api/azure/discover_fields` | GET | Ayuda única para encontrar los reference names |

## Nota de seguridad

El PAT y las credenciales SSH nunca deben quedar en el código ni en el repositorio — solo en `.env` (que debe estar en `.gitignore`).

