/* ============================================================
   ETL Governance Portal — Paginador reutilizable
   Uso:
     const pag = crearPaginador({
       porPagina: 10,
       contenedorPagerId: "miPagerId",
       render: (itemsDeEstaPagina, paginaActual, totalPaginas) => { ... pintar filas ... }
     });
     pag.actualizarDatos(nuevoArray);   // reemplaza datos y vuelve a página 1
     pag.irA(3);                        // ir a una página puntual
   ============================================================ */

function crearPaginador({ datos = [], porPagina = 10, contenedorPagerId, render }) {
  let _datos = datos;
  let paginaActual = 1;

  function totalPaginas() {
    return Math.max(1, Math.ceil(_datos.length / porPagina));
  }

  function irA(pagina) {
    paginaActual = Math.min(Math.max(1, pagina), totalPaginas());
    const inicio = (paginaActual - 1) * porPagina;
    const slice = _datos.slice(inicio, inicio + porPagina);
    render(slice, paginaActual, totalPaginas(), _datos.length);
    dibujarPager();
  }

  function dibujarPager() {
    const cont = document.getElementById(contenedorPagerId);
    if (!cont) return;
    const tp = totalPaginas();
    if (_datos.length === 0) { cont.innerHTML = ""; return; }
    if (tp <= 1) {
      cont.innerHTML = `<div class="pager"><span class="pager-info">${_datos.length} registro${_datos.length===1?"":"s"}</span></div>`;
      return;
    }
    const ventana = 1;
    let botones = "";
    for (let p = 1; p <= tp; p++) {
      const esBorde   = p === 1 || p === tp;
      const esCercano = Math.abs(p - paginaActual) <= ventana;
      if (esBorde || esCercano) {
        botones += `<button class="pager-btn ${p===paginaActual?"active":""}" onclick="window.__pag_${contenedorPagerId}.irA(${p})">${p}</button>`;
      } else if (Math.abs(p - paginaActual) === ventana + 1) {
        botones += `<span class="pager-dots">…</span>`;
      }
    }
    cont.innerHTML = `
      <div class="pager">
        <button class="pager-btn" ${paginaActual===1?"disabled":""} onclick="window.__pag_${contenedorPagerId}.irA(${paginaActual-1})">‹ Anterior</button>
        ${botones}
        <button class="pager-btn" ${paginaActual===tp?"disabled":""} onclick="window.__pag_${contenedorPagerId}.irA(${paginaActual+1})">Siguiente ›</button>
        <span class="pager-info">Página ${paginaActual} de ${tp} — ${_datos.length} registro${_datos.length===1?"":"s"}</span>
      </div>`;
  }

  const api = {
    irA,
    actualizarDatos(nuevo) { _datos = nuevo || []; irA(1); },
    datosActuales: () => _datos,
    paginaActual: () => paginaActual,
  };
  window[`__pag_${contenedorPagerId}`] = api;
  irA(1);
  return api;
}

/** Filas "skeleton" (placeholder animado) para mostrar mientras carga una tabla. */
function filasEsqueleto(colspan, cantidad = 5) {
  let html = "";
  for (let i = 0; i < cantidad; i++) {
    html += `<tr class="skeleton-row">`;
    for (let c = 0; c < colspan; c++) html += `<td><div class="skeleton-block"></div></td>`;
    html += `</tr>`;
  }
  return html;
}

/**
 * Anima un número dentro de un elemento, de 0 (o su valor actual) hasta valorFinal.
 * Uso: animarNumero(document.getElementById("miCard"), 128, {sufijo: "%"});
 */
function animarNumero(el, valorFinal, { duracion = 650, sufijo = "", decimales = 0 } = {}) {
  if (!el) return;
  const inicio = 0;
  const t0 = performance.now();
  function paso(ahora) {
    const p = Math.min(1, (ahora - t0) / duracion);
    const suavizado = 1 - Math.pow(1 - p, 3); // ease-out cúbico
    const actual = inicio + (valorFinal - inicio) * suavizado;
    el.textContent = actual.toFixed(decimales) + sufijo;
    if (p < 1) requestAnimationFrame(paso);
    else el.textContent = valorFinal.toFixed(decimales) + sufijo;
  }
  requestAnimationFrame(paso);
}

/**
 * Activa la transición CSS de las barras de progreso (.cumpl-bar) dentro de un contenedor.
 * Se llama después de insertar el HTML de las filas en el DOM.
 */
function animarBarras(selector = ".cumpl-bar") {
  requestAnimationFrame(() => {
    document.querySelectorAll(selector).forEach(barra => {
      const objetivo = barra.dataset.ancho || "0";
      requestAnimationFrame(() => { barra.style.width = objetivo + "%"; });
    });
  });
}
