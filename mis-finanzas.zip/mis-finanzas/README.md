# Mi Libreta de Cuentas

Aplicación web de finanzas personales: ingresos, egresos, ahorros y gastos hormiga,
con buenas prácticas financieras. Backend en **Flask**, base de datos **SQLite**,
gráficos con **Chart.js** (incluido localmente, sin dependencias externas de CDN).

Multiusuario: cada persona crea su cuenta y ve únicamente sus propios movimientos.

## Estructura

```
mis-finanzas/
├── app.py              # Factory de la app Flask
├── config.py            # Configuración (lee variables de entorno)
├── database.py          # Conexión y creación de la base SQLite
├── schema.sql            # Esquema de tablas
├── auth.py               # Blueprint: registro, login, logout
├── finanzas.py            # Blueprint: resumen, movimientos, ahorros, hormiga, consejos
├── templates/              # Vistas Jinja2
├── static/
│   ├── css/style.css        # Diseño (tema "libreta de cuentas")
│   └── js/
│       ├── app.js              # Modales y toasts
│       ├── resumen.js            # Gráficos del dashboard
│       └── vendor/chart.umd.min.js  # Chart.js vendorizado (sin CDN)
├── instance/                # Se crea sola: aquí vive finanzas.db
├── requirements.txt
└── .env.example
```

## Instalación

Requisitos: Python 3.10 o superior.

```bash
cd mis-finanzas

# 1. Crear entorno virtual
python3 -m venv venv
source venv/bin/activate        # En Windows: venv\Scripts\activate

# 2. Instalar dependencias
pip install -r requirements.txt

# 3. Configurar variables de entorno
cp .env.example .env
# Editá .env y poné una SECRET_KEY propia, por ejemplo con:
python3 -c "import secrets; print(secrets.token_hex(32))"
```

## Ejecutar

**Modo desarrollo** (recarga automática):

```bash
export FLASK_APP=app        # En Windows (PowerShell): $env:FLASK_APP="app"
export FLASK_DEBUG=1
flask run
```

**O directamente:**

```bash
python app.py
```

La app queda disponible en `http://127.0.0.1:5000`. La base de datos SQLite
(`instance/finanzas.db`) y sus tablas se crean automáticamente la primera vez
que se ejecuta — no hace falta ningún paso manual de migración.

## Ejecutar en producción (referencia rápida)

Para un entorno interno de banco/empresa, lo recomendable es correrlo detrás de
un servidor WSGI real en vez de `flask run`:

```bash
pip install gunicorn        # Linux/Mac
gunicorn -w 4 -b 0.0.0.0:8000 "app:create_app()"
```

En Windows, `waitress` es una alternativa a gunicorn:

```bash
pip install waitress
waitress-serve --port=8000 "app:create_app()"
```

Recordá:
- Cambiar `SECRET_KEY` por un valor propio y mantenerlo fuera del control de versiones.
- Hacer backups periódicos del archivo `instance/finanzas.db` (es un único archivo, fácil de copiar).
- Si se despliega en un servidor compartido, poner la app detrás de un proxy (nginx/IIS) con HTTPS.

## Notas de diseño

- Todo el front (fuentes, iconos, gráficos) funciona **sin conexión a internet**,
  pensado para redes corporativas restringidas.
- Las contraseñas se guardan con hash (`werkzeug.security`), nunca en texto plano.
- Los montos están en guaraníes (Gs.) por defecto; se puede cambiar el sufijo de
  moneda con la variable `MONEDA_SUFIJO` en `.env`.
