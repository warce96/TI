import functools

from flask import (
    Blueprint, flash, g, redirect, render_template, request, session, url_for
)
from werkzeug.security import check_password_hash, generate_password_hash

from database import get_db

bp = Blueprint("auth", __name__, url_prefix="/auth")


def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.get("usuario") is None:
            return redirect(url_for("auth.login", next=request.path))
        return view(**kwargs)
    return wrapped_view


@bp.before_app_request
def load_logged_in_user():
    usuario_id = session.get("usuario_id")
    if usuario_id is None:
        g.usuario = None
    else:
        db = get_db()
        g.usuario = db.execute(
            "SELECT * FROM usuarios WHERE id = ?", (usuario_id,)
        ).fetchone()


@bp.route("/registro", methods=("GET", "POST"))
def registro():
    if g.usuario:
        return redirect(url_for("finanzas.resumen"))

    if request.method == "POST":
        nombre_usuario = request.form.get("nombre_usuario", "").strip()
        nombre_completo = request.form.get("nombre_completo", "").strip()
        password = request.form.get("password", "")
        password2 = request.form.get("password2", "")

        error = None
        if not nombre_usuario or not nombre_completo or not password:
            error = "Completá todos los campos."
        elif len(password) < 6:
            error = "La contraseña debe tener al menos 6 caracteres."
        elif password != password2:
            error = "Las contraseñas no coinciden."

        if error is None:
            db = get_db()
            existente = db.execute(
                "SELECT id FROM usuarios WHERE nombre_usuario = ?", (nombre_usuario,)
            ).fetchone()
            if existente:
                error = f"El usuario '{nombre_usuario}' ya existe."
            else:
                db.execute(
                    "INSERT INTO usuarios (nombre_usuario, nombre_completo, password_hash) "
                    "VALUES (?, ?, ?)",
                    (nombre_usuario, nombre_completo, generate_password_hash(password)),
                )
                usuario_id = db.execute(
                    "SELECT id FROM usuarios WHERE nombre_usuario = ?", (nombre_usuario,)
                ).fetchone()["id"]
                db.execute(
                    "INSERT INTO metas_ahorro (usuario_id, meta) VALUES (?, ?)",
                    (usuario_id, 0),
                )
                db.commit()
                flash("Cuenta creada. Ya podés iniciar sesión.", "success")
                return redirect(url_for("auth.login"))

        flash(error, "error")

    return render_template("registro.html")


@bp.route("/login", methods=("GET", "POST"))
def login():
    if g.usuario:
        return redirect(url_for("finanzas.resumen"))

    if request.method == "POST":
        nombre_usuario = request.form.get("nombre_usuario", "").strip()
        password = request.form.get("password", "")

        db = get_db()
        usuario = db.execute(
            "SELECT * FROM usuarios WHERE nombre_usuario = ?", (nombre_usuario,)
        ).fetchone()

        error = None
        if usuario is None or not check_password_hash(usuario["password_hash"], password):
            error = "Usuario o contraseña incorrectos."

        if error is None:
            session.clear()
            session["usuario_id"] = usuario["id"]
            return redirect(request.args.get("next") or url_for("finanzas.resumen"))

        flash(error, "error")

    return render_template("login.html")


@bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
