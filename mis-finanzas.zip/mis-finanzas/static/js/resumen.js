(async function () {
  const paletaCategorias = ['#9A3B24', '#B9860B', '#3B6E8F', '#6B7A5A', '#7A5C3E', '#5C6470', '#8B4A6B', '#4A6B5C'];

  const res = await fetch(`${window.MI_LIBRETA_API_RESUMEN}?mes=${encodeURIComponent(window.MI_LIBRETA_MES)}`);
  const data = await res.json();

  const fmtGs = (v) => new Intl.NumberFormat('es-PY', { maximumFractionDigits: 0 }).format(Math.round(v)) + ' Gs.';

  const ctxBarras = document.getElementById('chartBarras');
  if (ctxBarras) {
    new Chart(ctxBarras, {
      type: 'bar',
      data: {
        labels: data.barras.map((b) => b.mes),
        datasets: [
          { label: 'Ingresos', data: data.barras.map((b) => b.ingresos), backgroundColor: '#2F5233', borderRadius: 4 },
          { label: 'Egresos', data: data.barras.map((b) => b.egresos), backgroundColor: '#9A3B24', borderRadius: 4 },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          legend: { labels: { font: { size: 12 }, color: '#5C6470' } },
          tooltip: { callbacks: { label: (ctx) => `${ctx.dataset.label}: ${fmtGs(ctx.raw)}` } },
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#5C6470', font: { size: 12 } } },
          y: { grid: { color: '#D3CBAE' }, ticks: { color: '#5C6470', font: { size: 11 }, callback: (v) => fmtGs(v) } },
        },
      },
    });
  }

  const ctxTorta = document.getElementById('chartTorta');
  if (ctxTorta) {
    if (!data.por_categoria || data.por_categoria.length === 0) {
      ctxTorta.style.display = 'none';
      document.getElementById('chartTortaEmpty').style.display = 'block';
    } else {
      new Chart(ctxTorta, {
        type: 'doughnut',
        data: {
          labels: data.por_categoria.map((c) => c.categoria),
          datasets: [{
            data: data.por_categoria.map((c) => c.monto),
            backgroundColor: data.por_categoria.map((_, i) => paletaCategorias[i % paletaCategorias.length]),
            borderWidth: 0,
          }],
        },
        options: {
          responsive: true,
          plugins: {
            legend: { position: 'bottom', labels: { font: { size: 11 }, color: '#5C6470', boxWidth: 12 } },
            tooltip: { callbacks: { label: (ctx) => `${ctx.label}: ${fmtGs(ctx.raw)}` } },
          },
          cutout: '58%',
        },
      });
    }
  }
})();
