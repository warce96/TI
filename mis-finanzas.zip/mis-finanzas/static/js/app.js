// Cerrar modal al hacer clic fuera de la tarjeta
document.addEventListener('click', (e) => {
  if (e.target.classList && e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

// Cerrar modal con Escape
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach((m) => m.classList.remove('open'));
  }
});

// Quitar los toasts del DOM luego de que termina su animación de salida
document.querySelectorAll('.toast').forEach((toast) => {
  setTimeout(() => toast.remove(), 3700);
});
