from datetime import date, datetime

from flask import Blueprint, flash, g, jsonify, render_template, request

from auth import login_required
from database import get_db

bp = Blueprint("finanzas", __name__)

INGRESO_CATS = ["Salario", "Freelance / Independiente", "Ventas", "Otros ingresos"]
EGRESO_CATS = [
    "Alquiler / Vivienda", "Servicios", "Alimentación", "Transporte",
    "Salud", "Educación", "Entretenimiento", "Ropa", "Otros",
]

TIPS = [
    ("Regla 50/30/20", "Destiná el 50% de tus ingresos a necesidades, 30% a deseos y 20% a ahorro o pago de deudas. Es un punto de partida simple para armar tu presupuesto."),
    ("Pagate a vos mismo primero", "Apenas cobrés, separá el porcentaje de ahorro antes de gastar en cualquier otra cosa. Lo que no ves en la cuenta corriente, no lo gastás."),
    ("Armá un fondo de emergencia", "Guardá entre 3 y 6 meses de tus gastos básicos en una cuenta separada y de fácil acceso, para imprevistos como pérdida de trabajo o salud."),
    ("Vigilá los gastos hormiga", "El café, el delivery o las apps que se cobran solas parecen montos chicos, pero suman fuerte al mes. Revisalos cada semana."),
    ("Evitá pagar solo el mínimo de la tarjeta", "Pagar el mínimo de la tarjeta de crédito genera intereses que crecen rápido y pueden convertirse en una deuda difícil de cerrar."),
    ("Presupuestá antes del mes, no durante", "Planificá cuánto vas a gastar en cada categoría antes de que empiece el mes, no cuando ya gastaste de más."),
    ("Automatizá tu ahorro", "Programá una transferencia automática a tu cuenta de ahorro el mismo día que cobrás, así no depende de tu fuerza de voluntad."),
    ("Revisá tus suscripciones", "Muchas apps se renuevan solas y se olvidan. Repasá una vez al mes cuáles seguís usando de verdad."),
]

MESES_ES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]


def month_key(fecha_iso):
    return fecha_iso[:7]


def month_label(mk):
    y, m = mk.split("-")
    return f"{MESES_ES[int(m) - 1]} {y[2:]}"


def current_month():
    return date.today().strftime("%Y-%m")


def last_n_months(n=6):
    months = []
    d = date.today()
    for i in range(n - 1, -1, -1):
        y = d.year
        m = d.month - i
        while m <= 0:
            m += 12
            y -= 1
        months.append(f"{y:04d}-{m:02d}")
    return months


def available_months(usuario_id, db):
    rows = db.execute(
        "SELECT DISTINCT substr(fecha, 1, 7) AS mk FROM transacciones WHERE usuario_id = ? ORDER BY mk DESC",
        (usuario_id,),
    ).fetchall()
    meses = [r["mk"] for r in rows]
    if current_month() not in meses:
        meses.insert(0, current_month())
    return sorted(set(meses), reverse=True)


@bp.route("/")
@login_required
def resumen():
    db = get_db()
    usuario_id = g.usuario["id"]
    mes = request.args.get("mes", current_month())

    tx_mes = db.execute(
        "SELECT * FROM transacciones WHERE usuario_id = ? AND substr(fecha,1,7) = ? ORDER BY fecha DESC",
        (usuario_id, mes),
    ).fetchall()

    ingresos = sum(t["monto"] for t in tx_mes if t["tipo"] == "ingreso")
    egresos = sum(t["monto"] for t in tx_mes if t["tipo"] == "egreso")
    hormiga = sum(t["monto"] for t in tx_mes if t["tipo"] == "egreso" and t["es_hormiga"])
    saldo = ingresos - egresos
    tasa_ahorro = (saldo / ingresos * 100) if ingresos > 0 else 0

    return render_template(
        "resumen.html",
        mes=mes,
        meses=available_months(usuario_id, db),
        month_label=month_label,
        ingresos=ingresos,
        egresos=egresos,
        hormiga=hormiga,
        saldo=saldo,
        tasa_ahorro=tasa_ahorro,
    )


@bp.route("/api/resumen")
@login_required
def api_resumen():
    db = get_db()
    usuario_id = g.usuario["id"]
    mes = request.args.get("mes", current_month())

    tx_mes = db.execute(
        "SELECT categoria, monto FROM transacciones WHERE usuario_id = ? AND tipo = 'egreso' AND substr(fecha,1,7) = ?",
        (usuario_id, mes),
    ).fetchall()
    por_categoria = {}
    for t in tx_mes:
        por_categoria[t["categoria"]] = por_categoria.get(t["categoria"], 0) + t["monto"]

    meses6 = last_n_months(6)
    barras = []
    for mk in meses6:
        rows = db.execute(
            "SELECT tipo, SUM(monto) AS total FROM transacciones "
            "WHERE usuario_id = ? AND substr(fecha,1,7) = ? GROUP BY tipo",
            (usuario_id, mk),
        ).fetchall()
        totales = {r["tipo"]: r["total"] for r in rows}
        barras.append({
            "mes": month_label(mk),
            "ingresos": totales.get("ingreso", 0),
            "egresos": totales.get("egreso", 0),
        })

    return jsonify({
        "por_categoria": [{"categoria": k, "monto": v} for k, v in por_categoria.items()],
        "barras": barras,
    })


@bp.route("/movimientos")
@login_required
def movimientos():
    db = get_db()
    usuario_id = g.usuario["id"]
    mes = request.args.get("mes", current_month())

    tx_mes = db.execute(
        "SELECT * FROM transacciones WHERE usuario_id = ? AND substr(fecha,1,7) = ? ORDER BY fecha DESC, id DESC",
        (usuario_id, mes),
    ).fetchall()

    return render_template(
        "movimientos.html",
        mes=mes,
        meses=available_months(usuario_id, db),
        month_label=month_label,
        transacciones=tx_mes,
        ingreso_cats=INGRESO_CATS,
        egreso_cats=EGRESO_CATS,
        hoy=date.today().isoformat(),
    )


@bp.route("/movimientos/agregar", methods=["POST"])
@login_required
def agregar_movimiento():
    db = get_db()
    usuario_id = g.usuario["id"]

    tipo = request.form.get("tipo")
    categoria = request.form.get("categoria", "").strip()
    monto_raw = request.form.get("monto", "")
    descripcion = request.form.get("descripcion", "").strip()
    fecha = request.form.get("fecha") or date.today().isoformat()
    es_hormiga = 1 if request.form.get("es_hormiga") == "on" and tipo == "egreso" else 0

    try:
        monto = float(monto_raw)
        if monto <= 0:
            raise ValueError
    except (TypeError, ValueError):
        flash("Ingresá un monto válido, mayor a cero.", "error")
        return redirect_movimientos(fecha)

    if tipo not in ("ingreso", "egreso") or not categoria:
        flash("Completá el tipo y la categoría del movimiento.", "error")
        return redirect_movimientos(fecha)

    db.execute(
        "INSERT INTO transacciones (usuario_id, tipo, categoria, monto, descripcion, fecha, es_hormiga) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (usuario_id, tipo, categoria, monto, descripcion, fecha, es_hormiga),
    )
    db.commit()
    flash("Movimiento guardado.", "success")
    return redirect_movimientos(fecha)


@bp.route("/movimientos/<int:tx_id>/eliminar", methods=["POST"])
@login_required
def eliminar_movimiento(tx_id):
    db = get_db()
    usuario_id = g.usuario["id"]
    fila = db.execute(
        "SELECT fecha FROM transacciones WHERE id = ? AND usuario_id = ?", (tx_id, usuario_id)
    ).fetchone()
    db.execute("DELETE FROM transacciones WHERE id = ? AND usuario_id = ?", (tx_id, usuario_id))
    db.commit()
    flash("Movimiento eliminado.", "success")
    mes = month_key(fila["fecha"]) if fila else current_month()
    return redirect_movimientos(mes + "-01")


def redirect_movimientos(fecha_referencia):
    from flask import redirect, url_for
    mes = month_key(fecha_referencia)
    return redirect(url_for("finanzas.movimientos", mes=mes))


@bp.route("/gastos-hormiga")
@login_required
def gastos_hormiga():
    db = get_db()
    usuario_id = g.usuario["id"]
    mes = request.args.get("mes", current_month())

    tx_hormiga = db.execute(
        "SELECT * FROM transacciones WHERE usuario_id = ? AND es_hormiga = 1 AND substr(fecha,1,7) = ? "
        "ORDER BY fecha DESC",
        (usuario_id, mes),
    ).fetchall()
    total_hormiga = sum(t["monto"] for t in tx_hormiga)

    return render_template(
        "hormiga.html",
        mes=mes,
        meses=available_months(usuario_id, db),
        month_label=month_label,
        transacciones=tx_hormiga,
        total_hormiga=total_hormiga,
    )


@bp.route("/ahorros")
@login_required
def ahorros():
    db = get_db()
    usuario_id = g.usuario["id"]

    meta_row = db.execute("SELECT meta FROM metas_ahorro WHERE usuario_id = ?", (usuario_id,)).fetchone()
    meta = meta_row["meta"] if meta_row else 0

    aportes = db.execute(
        "SELECT * FROM aportes_ahorro WHERE usuario_id = ? ORDER BY fecha DESC, id DESC", (usuario_id,)
    ).fetchall()
    total_ahorrado = sum(a["monto"] for a in aportes)

    return render_template(
        "ahorro.html",
        meta=meta,
        aportes=aportes,
        total_ahorrado=total_ahorrado,
        hoy=date.today().isoformat(),
    )


@bp.route("/ahorros/meta", methods=["POST"])
@login_required
def actualizar_meta():
    db = get_db()
    usuario_id = g.usuario["id"]
    try:
        meta = float(request.form.get("meta", ""))
        if meta < 0:
            raise ValueError
    except (TypeError, ValueError):
        flash("Ingresá un monto de meta válido.", "error")
        return redirect_ahorros()

    existe = db.execute("SELECT 1 FROM metas_ahorro WHERE usuario_id = ?", (usuario_id,)).fetchone()
    if existe:
        db.execute("UPDATE metas_ahorro SET meta = ? WHERE usuario_id = ?", (meta, usuario_id))
    else:
        db.execute("INSERT INTO metas_ahorro (usuario_id, meta) VALUES (?, ?)", (usuario_id, meta))
    db.commit()
    flash("Meta de ahorro actualizada.", "success")
    return redirect_ahorros()


@bp.route("/ahorros/aporte", methods=["POST"])
@login_required
def agregar_aporte():
    db = get_db()
    usuario_id = g.usuario["id"]
    fecha = request.form.get("fecha") or date.today().isoformat()
    try:
        monto = float(request.form.get("monto", ""))
        if monto <= 0:
            raise ValueError
    except (TypeError, ValueError):
        flash("Ingresá un monto de aporte válido, mayor a cero.", "error")
        return redirect_ahorros()

    db.execute(
        "INSERT INTO aportes_ahorro (usuario_id, monto, fecha) VALUES (?, ?, ?)",
        (usuario_id, monto, fecha),
    )
    db.commit()
    flash("Aporte registrado.", "success")
    return redirect_ahorros()


@bp.route("/ahorros/aporte/<int:aporte_id>/eliminar", methods=["POST"])
@login_required
def eliminar_aporte(aporte_id):
    db = get_db()
    usuario_id = g.usuario["id"]
    db.execute("DELETE FROM aportes_ahorro WHERE id = ? AND usuario_id = ?", (aporte_id, usuario_id))
    db.commit()
    flash("Aporte eliminado.", "success")
    return redirect_ahorros()


def redirect_ahorros():
    from flask import redirect, url_for
    return redirect(url_for("finanzas.ahorros"))


@bp.route("/consejos")
@login_required
def consejos():
    return render_template("consejos.html", tips=TIPS)
