from datetime import datetime

from flask import Flask

from config import Config
from database import init_db

MESES_ES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]


def create_app():
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(Config)

    init_db(app)

    @app.template_filter("gs")
    def gs_filter(valor):
        try:
            n = round(float(valor))
        except (TypeError, ValueError):
            n = 0
        texto = f"{n:,}".replace(",", ".")
        return f"{texto} {app.config['MONEDA_SUFIJO']}"

    @app.template_filter("fecha_larga")
    def fecha_larga_filter(fecha_iso):
        try:
            d = datetime.strptime(fecha_iso, "%Y-%m-%d")
        except (TypeError, ValueError):
            return fecha_iso
        return f"{d.day:02d} {MESES_ES[d.month - 1]} {d.year}"

    import auth
    import finanzas
    app.register_blueprint(auth.bp)
    app.register_blueprint(finanzas.bp)

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, host="127.0.0.1", port=5000)
