@echo off
title Ejecutar App Python

echo Iniciando aplicacion...
echo.

REM Activar entorno virtual (opcional)
REM call venv\Scripts\activate

REM Ejecutar la app en segundo plano
start cmd /k python app.py

REM Esperar unos segundos para que levante el servidor
timeout /t 3 > nul

REM Abrir navegador
start http://localhost:5000

echo.
echo App ejecutandose en http://localhost:5000
pause