def calcular_total_credito(monto, interes):
    """Calcula el total a cobrar con interes simple sobre el capital."""
    total = float(monto) * (1 + float(interes) / 100)
    return round(total, 2)


def calcular_ganancia_credito(monto, interes):
    """Ganancia estimada del credito: total a cobrar menos capital entregado."""
    ganancia = calcular_total_credito(monto, interes) - float(monto)
    return round(ganancia, 2)


def calcular_cuota(monto, interes, plazo):
    total = calcular_total_credito(monto, interes)
    cuota = total / int(plazo)
    return round(cuota, 2)


def generar_cuotero(monto, interes, plazo, fecha_base=None):
    """Genera un cuotero simple mensual para mostrar antes de otorgar el credito."""
    from datetime import datetime
    from utils.fechas import sumar_meses, hoy

    plazo = int(plazo)
    cuota = calcular_cuota(monto, interes, plazo)
    total = calcular_total_credito(monto, interes)
    saldo = total

    if fecha_base is None:
        fecha_base = hoy()

    cuotas = []
    for nro in range(1, plazo + 1):
        saldo = max(0, round(saldo - cuota, 2))
        cuotas.append({
            "nro": nro,
            "vencimiento": sumar_meses(fecha_base, nro),
            "cuota": cuota,
            "saldo": saldo,
        })
    return cuotas


def calcular_descuento_cheque(monto, porcentaje):
    descuento = float(monto) * float(porcentaje) / 100
    monto_cliente = float(monto) - descuento
    return round(monto_cliente, 2)


def calcular_mora(cuota, dias):
    mora = float(cuota) * 0.02 * int(dias)
    return round(mora, 2)


def calcular_monto_costo(monto, iva_pct, monto_costo_manual):
    """Determina el 'monto costo': la base real sobre la que se calcula el
    interés/cuotero de un préstamo o refinanciación, en vez del monto que pidió
    o quedó adeudando el cliente.

    - Si se ingresa un monto costo manual (monto_costo_manual > 0), se usa tal
      cual, sin ningún cálculo.
    - Si no, y se ingresó un % de IVA, el monto costo se calcula agregando ese
      porcentaje al monto: monto * (1 + iva_pct/100).
    - Si no se ingresó ninguno de los dos, el monto costo es el mismo monto
      (sin cambios respecto al comportamiento anterior).
    """
    monto = float(monto or 0)
    monto_costo_manual = float(monto_costo_manual or 0)
    iva_pct = float(iva_pct or 0)

    if monto_costo_manual > 0:
        return round(monto_costo_manual, 2)
    if iva_pct > 0:
        return round(monto * (1 + iva_pct / 100), 2)
    return round(monto, 2)


MAX_CUOTAS = 360  # tope de seguridad, igual al usado en el front-end


def calcular_plazo_y_cuota(monto_a_financiar, monto_fijo_cuota, plazo_manual):
    """Determina (plazo, cuota, error) para una operación en cuotas.

    - Si monto_a_financiar <= 0: no quedan cuotas por cobrar (ej. entrega inicial
      cubrió el 100%) -> plazo=1, cuota=0.
    - Si monto_fijo_cuota > 0 (modo "monto fijo"): el usuario indica cuánto quiere
      pagar por cuota y el plazo se calcula dividiendo lo que queda por financiar
      entre ese monto fijo, con la última cuota absorbiendo el remanente.
    - En otro caso (modo "dinámico"): se usa plazo_manual tal cual, dividiendo el
      monto a financiar en partes iguales.

    Retorna (plazo, cuota, error). `error` es None salvo que el monto fijo
    implique más cuotas que MAX_CUOTAS, en cuyo caso se informa un mensaje.
    """
    import math

    monto_a_financiar = max(0.0, round(float(monto_a_financiar or 0), 2))
    monto_fijo_cuota   = float(monto_fijo_cuota or 0)
    plazo_manual       = int(plazo_manual or 0)

    if monto_a_financiar <= 0:
        return 1, 0.0, None

    if monto_fijo_cuota > 0:
        plazo_estim = math.ceil(monto_a_financiar / monto_fijo_cuota)
        if plazo_estim > MAX_CUOTAS:
            return None, None, (
                f"El monto fijo ingresado es muy bajo: implicaría {plazo_estim} cuotas. "
                f"Ingrese un monto mayor (máx. {MAX_CUOTAS} cuotas)."
            )
        plazo = max(1, plazo_estim)
        cuota = monto_fijo_cuota if plazo > 1 else monto_a_financiar
        return plazo, round(cuota, 2), None

    plazo = max(1, plazo_manual)
    cuota = monto_a_financiar / plazo if plazo > 0 else monto_a_financiar
    return plazo, round(cuota, 2), None
