from datetime import datetime, timedelta
import calendar


def hoy():
    return datetime.now().strftime("%Y-%m-%d")


def sumar_meses(fecha_iso, meses):
    fecha = datetime.strptime(fecha_iso, "%Y-%m-%d").date()
    mes_total = fecha.month - 1 + int(meses)
    anio = fecha.year + mes_total // 12
    mes = mes_total % 12 + 1
    dia = min(fecha.day, calendar.monthrange(anio, mes)[1])
    return fecha.replace(year=anio, month=mes, day=dia).strftime("%Y-%m-%d")


def fecha_vencimiento(meses=1, desde=None):
    """Calcula la fecha de vencimiento sumando meses desde una fecha base (default: hoy)."""
    base = desde if desde else hoy()
    return sumar_meses(base, meses)


def sumar_dias(fecha_iso, dias):
    fecha = datetime.strptime(fecha_iso, "%Y-%m-%d").date()
    return (fecha + timedelta(days=int(dias))).strftime("%Y-%m-%d")


def _dia_semana_js(fecha_iso):
    """Día de la semana estilo JS (domingo=0 ... sábado=6), igual al usado en el preview del navegador."""
    fecha = datetime.strptime(fecha_iso, "%Y-%m-%d").date()
    return (fecha.weekday() + 1) % 7  # Python: lunes=0 → JS: lunes=1 ... domingo(py=6)→js=0


def proximo_dia_semana(fecha_iso, dia_js):
    """Próxima fecha (siempre posterior, nunca la misma fecha) cuyo día de semana
    (estilo JS: domingo=0) coincida con dia_js. Replica proximoDiaV() del front-end."""
    actual = _dia_semana_js(fecha_iso)
    diff = dia_js - actual
    if diff <= 0:
        diff += 7
    return sumar_dias(fecha_iso, diff)


_DIA_MAP = {"lunes": 1, "domingo": 0, "viernes": 5}


def parse_dias_fijos(dias_fijos_mes):
    """Convierte '5' o '14,28' en una lista ordenada de enteros 1-31 sin duplicados."""
    if not dias_fijos_mes:
        return []
    dias = []
    for parte in str(dias_fijos_mes).split(","):
        parte = parte.strip()
        if not parte:
            continue
        try:
            d = int(parte)
        except ValueError:
            continue
        if 1 <= d <= 31:
            dias.append(d)
    return sorted(set(dias))


def vencimiento_cuota_fija(fecha_inicio, nro, dias_fijos):
    """Calcula el vencimiento de la cuota N cuando la periodicidad usa día(s) fijos
    del mes (ej.: mensual el día 5, o quincenal los días 14 y 28). `dias_fijos` es
    una lista de enteros 1-31 (ya ordenada/parseada con parse_dias_fijos). Recorre
    mes a mes desde fecha_inicio generando una fecha candidata por cada día
    configurado (ajustando a fin de mes si el mes es más corto), descarta las
    candidatas que caen en o antes de fecha_inicio, y devuelve la candidata
    número `nro` en orden cronológico. Sirve tanto para 1 día (mensual fijo)
    como para 2+ días (quincenal con fechas fijas) con el mismo código."""
    dias_fijos = sorted(set(int(d) for d in dias_fijos if 1 <= int(d) <= 31))
    if not dias_fijos:
        return sumar_meses(fecha_inicio, nro)

    fecha_ini = datetime.strptime(fecha_inicio, "%Y-%m-%d").date()
    anio, mes = fecha_ini.year, fecha_ini.month
    encontrados = 0
    # Límite de seguridad: no debería hacer falta recorrer más de ~50 años.
    for _ in range(600):
        for d in dias_fijos:
            dia_real = min(d, calendar.monthrange(anio, mes)[1])
            candidata = fecha_ini.replace(year=anio, month=mes, day=dia_real)
            if candidata > fecha_ini:
                encontrados += 1
                if encontrados == nro:
                    return candidata.strftime("%Y-%m-%d")
        mes += 1
        if mes > 12:
            mes = 1
            anio += 1
    return sumar_meses(fecha_inicio, nro)


def vencimiento_cuota(fecha_inicio, nro, periodicidad="mensual", dias_periodo=30,
                       dia_inicio_semana="", dias_fijos_mes=""):
    """Calcula el vencimiento real de la cuota N según la periodicidad elegida al
    cargar la operación (mensual / quincenal / semanal / personalizado). Replica
    exactamente la lógica de simulación usada en el preview del formulario, para
    que el cuotero operativo (donde se cobra) coincida con lo que se mostró antes
    de guardar."""
    dias_fijos = parse_dias_fijos(dias_fijos_mes)
    if dias_fijos and periodicidad in ("mensual", "quincenal"):
        return vencimiento_cuota_fija(fecha_inicio, nro, dias_fijos)
    dias_periodo = int(dias_periodo or 30)
    if periodicidad == "semanal" and dia_inicio_semana in _DIA_MAP:
        primer_venc = proximo_dia_semana(fecha_inicio, _DIA_MAP[dia_inicio_semana])
        return sumar_dias(primer_venc, dias_periodo * (nro - 1))
    if dias_periodo and dias_periodo != 30:
        return sumar_dias(fecha_inicio, dias_periodo * nro)
    return sumar_meses(fecha_inicio, nro)
