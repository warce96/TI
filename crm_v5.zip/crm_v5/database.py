"""database.py — Capa SQLite unificada (FinanGest)"""
import os, sqlite3
from contextlib import contextmanager

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH  = os.path.join(BASE_DIR, "data", "gestor.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn; conn.commit()
    except Exception:
        conn.rollback(); raise
    finally:
        conn.close()

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
            nombre TEXT, rol TEXT DEFAULT 'operador',
            creado TEXT DEFAULT (date('now'))
        );
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL, cedula TEXT NOT NULL DEFAULT '',
            telefono TEXT DEFAULT '', email TEXT DEFAULT '',
            direccion TEXT DEFAULT '', barrio TEXT DEFAULT '',
            referencia TEXT DEFAULT '', observacion TEXT DEFAULT '',
            margen_pago REAL DEFAULT 0, limite_credito REAL DEFAULT 0,
            fecha TEXT DEFAULT (date('now'))
        );
        CREATE TABLE IF NOT EXISTS prestamos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente TEXT NOT NULL, monto REAL NOT NULL,
            interes REAL NOT NULL, plazo INTEGER NOT NULL,
            cuota REAL, vencimiento TEXT, total REAL, ganancia REAL,
            fecha TEXT DEFAULT (date('now')),
            estado TEXT DEFAULT 'ACTIVO',
            cuotas_pagadas INTEGER DEFAULT 0,
            tuvo_mora TEXT DEFAULT 'NO',
            dias_mora INTEGER DEFAULT 0,
            mora_acumulada REAL DEFAULT 0,
            fecha_refin TEXT DEFAULT '', ref_id TEXT DEFAULT '',
            periodicidad TEXT DEFAULT 'mensual',
            dias_periodo INTEGER DEFAULT 30
        );
        CREATE TABLE IF NOT EXISTS refinanciaciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente TEXT NOT NULL, deuda REAL NOT NULL,
            costo_admin REAL DEFAULT 0, interes REAL NOT NULL,
            plazo INTEGER NOT NULL, cuota REAL,
            ganancia REAL, total REAL, vencimiento TEXT,
            fecha TEXT DEFAULT (date('now')),
            observacion TEXT DEFAULT '',
            origen_tipo TEXT DEFAULT '', origen_id TEXT DEFAULT '',
            origen_descripcion TEXT DEFAULT '',
            cuotas_pagadas_origen INTEGER DEFAULT 0,
            tuvo_mora_origen TEXT DEFAULT 'NO',
            dias_mora_origen INTEGER DEFAULT 0,
            mora_acumulada_origen REAL DEFAULT 0,
            estado TEXT DEFAULT 'ACTIVO',
            cuotas_pagadas INTEGER DEFAULT 0,
            tuvo_mora TEXT DEFAULT 'NO',
            dias_mora INTEGER DEFAULT 0,
            mora_acumulada REAL DEFAULT 0,
            fecha_refin TEXT DEFAULT '', ref_id TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS ventas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente TEXT NOT NULL, producto TEXT NOT NULL,
            precio REAL NOT NULL, fecha TEXT DEFAULT (date('now')),
            estado TEXT DEFAULT 'ACTIVO',
            pagado REAL DEFAULT 0,
            interes REAL DEFAULT 0,
            plazo INTEGER DEFAULT 1,
            cuota REAL DEFAULT 0,
            total REAL DEFAULT 0,
            fecha_refin TEXT DEFAULT '', ref_id TEXT DEFAULT '',
            periodicidad TEXT DEFAULT 'mensual',
            dias_periodo INTEGER DEFAULT 30,
            monto_fijo_cuota REAL DEFAULT 0,
            costo REAL DEFAULT 0,
            ganancia REAL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS cheques (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente TEXT NOT NULL, monto REAL NOT NULL,
            descuento REAL NOT NULL, neto REAL,
            fecha TEXT DEFAULT (date('now'))
        );
        CREATE TABLE IF NOT EXISTS historial_mora (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente TEXT NOT NULL,
            tipo TEXT NOT NULL,
            operacion_id INTEGER NOT NULL,
            nro_cuota INTEGER NOT NULL,
            vencimiento TEXT NOT NULL,
            dias_atraso INTEGER NOT NULL,
            mora_aplicada REAL DEFAULT 0,
            periodo_gracia TEXT DEFAULT 'NO',
            fecha_registro TEXT DEFAULT (date('now'))
        );
        CREATE TABLE IF NOT EXISTS cobros (
            id TEXT PRIMARY KEY,
            fecha_pago TEXT NOT NULL, tipo TEXT NOT NULL,
            operacion_id INTEGER NOT NULL, nro_cuota INTEGER NOT NULL,
            cliente TEXT NOT NULL, monto REAL NOT NULL,
            vencimiento TEXT DEFAULT '',
            estado TEXT DEFAULT 'PAGADO',
            fecha_anulacion TEXT DEFAULT '',
            motivo_anulacion TEXT DEFAULT '',
            referencia TEXT DEFAULT '',
            medio_pago TEXT DEFAULT 'Efectivo',
            mora_aplicada REAL DEFAULT 0,
            periodo_gracia TEXT DEFAULT 'NO',
            dias_atraso INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS cuotas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo TEXT NOT NULL, operacion_id INTEGER NOT NULL, nro INTEGER NOT NULL,
            vencimiento TEXT NOT NULL, monto REAL NOT NULL,
            UNIQUE(tipo, operacion_id, nro)
        );
        CREATE INDEX IF NOT EXISTS idx_cuotas_op ON cuotas(tipo, operacion_id);
        CREATE INDEX IF NOT EXISTS idx_cuotas_venc ON cuotas(vencimiento);
        """)
        # Migraciones columnas nuevas
        for table, col, definition in [
            ("clientes",  "ciudad",        "TEXT DEFAULT ''"),
            ("ventas",    "interes",       "REAL DEFAULT 0"),
            ("ventas",    "plazo",         "INTEGER DEFAULT 1"),
            ("ventas",    "cuota",         "REAL DEFAULT 0"),
            ("ventas",    "total",         "REAL DEFAULT 0"),
            ("ventas",    "periodicidad",  "TEXT DEFAULT 'mensual'"),
            ("ventas",    "dias_periodo",  "INTEGER DEFAULT 30"),
            ("ventas",    "monto_fijo_cuota", "REAL DEFAULT 0"),
            ("ventas",    "costo",            "REAL DEFAULT 0"),
            ("ventas",    "ganancia",         "REAL DEFAULT 0"),
            ("ventas",    "dia_inicio_semana", "TEXT DEFAULT ''"),
            ("ventas",    "entrega_inicial", "REAL DEFAULT 0"),
            ("ventas",    "adelanto",        "REAL DEFAULT 0"),
            ("prestamos", "periodicidad",  "TEXT DEFAULT 'mensual'"),
            ("prestamos", "dias_periodo",  "INTEGER DEFAULT 30"),
            ("prestamos", "dia_inicio_semana", "TEXT DEFAULT ''"),
            ("prestamos", "adelanto",        "REAL DEFAULT 0"),
            ("prestamos", "monto_fijo_cuota", "REAL DEFAULT 0"),
            ("prestamos", "dias_fijos_mes",   "TEXT DEFAULT ''"),
            ("prestamos", "iva_pct",          "REAL DEFAULT 0"),
            ("prestamos", "monto_costo",      "REAL DEFAULT 0"),
            ("refinanciaciones", "iva_pct",      "REAL DEFAULT 0"),
            ("refinanciaciones", "monto_costo",  "REAL DEFAULT 0"),
            ("ventas",    "dias_fijos_mes",   "TEXT DEFAULT ''"),
            ("refinanciaciones", "adelanto", "REAL DEFAULT 0"),
            ("refinanciaciones", "periodicidad",     "TEXT DEFAULT 'mensual'"),
            ("refinanciaciones", "dias_periodo",     "INTEGER DEFAULT 30"),
            ("refinanciaciones", "dia_inicio_semana", "TEXT DEFAULT ''"),
            ("refinanciaciones", "monto_fijo_cuota", "REAL DEFAULT 0"),
            ("refinanciaciones", "dias_fijos_mes",   "TEXT DEFAULT ''"),
            ("cobros",    "mora_aplicada",  "REAL DEFAULT 0"),
            ("cobros",    "periodo_gracia", "TEXT DEFAULT 'NO'"),
            ("cobros",    "dias_atraso",    "INTEGER DEFAULT 0"),
        ]:
            try:
                db.execute(f"ALTER TABLE {table} ADD COLUMN {col} {definition}")
            except Exception:
                pass

# ── Usuarios ──────────────────────────────────────────────
def crear_usuario_inicial():
    from werkzeug.security import generate_password_hash
    with get_db() as db:
        if not db.execute("SELECT 1 FROM usuarios LIMIT 1").fetchone():
            db.execute("INSERT INTO usuarios (username,password,nombre,rol) VALUES (?,?,?,?)",
                       ("admin", generate_password_hash("admin123"), "Administrador", "admin"))

def get_usuario(username):
    with get_db() as db:
        return db.execute("SELECT * FROM usuarios WHERE username=?", (username,)).fetchone()

def get_todos_usuarios():
    with get_db() as db:
        return db.execute("SELECT id,username,nombre,rol,creado FROM usuarios ORDER BY id").fetchall()

def crear_usuario(username, pw_hash, nombre, rol="operador"):
    with get_db() as db:
        db.execute("INSERT INTO usuarios (username,password,nombre,rol) VALUES (?,?,?,?)",
                   (username, pw_hash, nombre, rol))

def eliminar_usuario(uid):
    with get_db() as db:
        db.execute("DELETE FROM usuarios WHERE id=?", (uid,))

# ── Clientes ──────────────────────────────────────────────
def get_clientes():
    with get_db() as db:
        return db.execute("SELECT * FROM clientes ORDER BY nombre").fetchall()

def get_cliente_por_nombre(nombre):
    with get_db() as db:
        return db.execute("SELECT * FROM clientes WHERE lower(nombre)=lower(?)", (nombre,)).fetchone()

def get_cliente(cid):
    with get_db() as db:
        return db.execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()

def buscar_clientes(q):
    """Busca clientes por nombre o cédula (búsqueda parcial)."""
    with get_db() as db:
        like = f"%{q.strip()}%"
        return db.execute(
            "SELECT * FROM clientes WHERE lower(nombre) LIKE lower(?) OR cedula LIKE ? ORDER BY nombre",
            (like, like)
        ).fetchall()

def insertar_cliente(nombre, cedula, telefono="", email="", direccion="",
                     barrio="", ciudad="", referencia="", observacion="",
                     margen_pago=0, limite_credito=0):
    with get_db() as db:
        db.execute("""INSERT INTO clientes
            (nombre,cedula,telefono,email,direccion,barrio,ciudad,referencia,observacion,margen_pago,limite_credito)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (nombre,cedula,telefono,email,direccion,barrio,ciudad,referencia,observacion,margen_pago,limite_credito))

def insertar_cliente_si_no_existe(nombre):
    if not get_cliente_por_nombre(nombre):
        with get_db() as db:
            db.execute("INSERT INTO clientes (nombre,cedula) VALUES (?,?)", (nombre,"—"))

def actualizar_credito_cliente(cid, margen_pago, limite_credito):
    with get_db() as db:
        db.execute(
            "UPDATE clientes SET margen_pago=?, limite_credito=? WHERE id=?",
            (margen_pago, limite_credito, cid)
        )

def actualizar_cliente(cid, nombre, cedula, telefono="", email="", direccion="",
                       barrio="", ciudad="", referencia="", observacion=""):
    """Actualiza los datos personales del cliente (no toca margen/límite).
    Si el nombre cambia, propaga el cambio a todas sus operaciones históricas,
    ya que el resto del sistema vincula préstamos/ventas/cobros por nombre."""
    with get_db() as db:
        actual = db.execute("SELECT nombre FROM clientes WHERE id=?", (cid,)).fetchone()
        nombre_anterior = actual["nombre"] if actual else None

        db.execute(
            """UPDATE clientes SET
                nombre=?, cedula=?, telefono=?, email=?, direccion=?,
                barrio=?, ciudad=?, referencia=?, observacion=?
               WHERE id=?""",
            (nombre, cedula, telefono, email, direccion,
             barrio, ciudad, referencia, observacion, cid)
        )

        if nombre_anterior and nombre_anterior.strip().lower() != nombre.strip().lower():
            for tabla in ("prestamos", "refinanciaciones", "ventas", "cobros", "historial_mora"):
                db.execute(f"UPDATE {tabla} SET cliente=? WHERE lower(cliente)=lower(?)",
                           (nombre, nombre_anterior))

def eliminar_cliente(cid):
    with get_db() as db:
        db.execute("DELETE FROM clientes WHERE id=?", (cid,))

# ── Préstamos ─────────────────────────────────────────────
def get_prestamos():
    with get_db() as db:
        return db.execute("SELECT * FROM prestamos ORDER BY id DESC").fetchall()

def get_prestamo(pid):
    with get_db() as db:
        return db.execute("SELECT * FROM prestamos WHERE id=?", (pid,)).fetchone()

def insertar_prestamo(cliente, monto, interes, plazo, cuota, vencimiento, total, ganancia,
                      fecha=None, periodicidad="mensual", dias_periodo=30, dia_inicio_semana="",
                      monto_fijo_cuota=0.0, dias_fijos_mes="", iva_pct=0.0, monto_costo=0.0):
    from utils.fechas import hoy as _h
    fecha_final = fecha or _h()
    with get_db() as db:
        cur = db.execute("""INSERT INTO prestamos
            (cliente,monto,interes,plazo,cuota,vencimiento,total,ganancia,fecha,periodicidad,dias_periodo,dia_inicio_semana,monto_fijo_cuota,dias_fijos_mes,iva_pct,monto_costo)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (cliente,monto,interes,plazo,cuota,vencimiento,total,ganancia,fecha_final,
             periodicidad, dias_periodo, dia_inicio_semana,
             round(float(monto_fijo_cuota or 0), 2), dias_fijos_mes or "",
             round(float(iva_pct or 0), 2), round(float(monto_costo or 0), 2)))
        pid = cur.lastrowid
    generar_cuotas("prestamo", pid, fecha_final, plazo, total, cuota,
                    periodicidad, dias_periodo, dia_inicio_semana, dias_fijos_mes)
    return pid

def actualizar_cuotas_prestamo(pid, cuotas_pagadas, estado):
    with get_db() as db:
        db.execute("UPDATE prestamos SET cuotas_pagadas=?, estado=? WHERE id=?",
                   (cuotas_pagadas, estado, pid))

def marcar_prestamo_refinanciado(pid, ref_id, cuotas_pagadas, tuvo_mora, dias_mora, mora_acumulada):
    from utils.fechas import hoy as _h
    with get_db() as db:
        db.execute("""UPDATE prestamos SET estado='REFINANCIADO',
            cuotas_pagadas=?,tuvo_mora=?,dias_mora=?,mora_acumulada=?,fecha_refin=?,ref_id=?
            WHERE id=?""", (cuotas_pagadas,tuvo_mora,dias_mora,mora_acumulada,_h(),ref_id,pid))

def eliminar_prestamo(pid):
    with get_db() as db:
        db.execute("DELETE FROM cobros WHERE tipo='prestamo' AND operacion_id=?", (pid,))
        db.execute("DELETE FROM cuotas WHERE tipo='prestamo' AND operacion_id=?", (pid,))
        db.execute("DELETE FROM prestamos WHERE id=?", (pid,))

# ── Refinanciaciones ──────────────────────────────────────
def get_refinanciaciones():
    with get_db() as db:
        return db.execute("SELECT * FROM refinanciaciones ORDER BY id DESC").fetchall()

def get_refinanciacion(rid):
    with get_db() as db:
        return db.execute("SELECT * FROM refinanciaciones WHERE id=?", (rid,)).fetchone()

def insertar_refinanciacion(cliente, deuda, costo_admin, interes, plazo, cuota,
                             ganancia, total, vencimiento, fecha, observacion,
                             origen_tipo, origen_id, origen_descripcion,
                             cp_origen, tm_origen, dm_origen, ma_origen,
                             periodicidad="mensual", dias_periodo=30, dia_inicio_semana="",
                             dias_fijos_mes="", monto_fijo_cuota=0.0,
                             iva_pct=0.0, monto_costo=0.0):
    with get_db() as db:
        cur = db.execute("""INSERT INTO refinanciaciones
            (cliente,deuda,costo_admin,interes,plazo,cuota,ganancia,total,
             vencimiento,fecha,observacion,origen_tipo,origen_id,origen_descripcion,
             cuotas_pagadas_origen,tuvo_mora_origen,dias_mora_origen,mora_acumulada_origen,
             periodicidad,dias_periodo,dia_inicio_semana,dias_fijos_mes,monto_fijo_cuota,
             iva_pct,monto_costo)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (cliente,deuda,costo_admin,interes,plazo,cuota,ganancia,total,
             vencimiento,fecha,observacion,origen_tipo,origen_id,origen_descripcion,
             cp_origen,tm_origen,dm_origen,ma_origen,
             periodicidad,dias_periodo,dia_inicio_semana,dias_fijos_mes or "",
             round(float(monto_fijo_cuota or 0), 2),
             round(float(iva_pct or 0), 2), round(float(monto_costo or 0), 2)))
        rid = cur.lastrowid
    generar_cuotas("refinanciacion", rid, fecha, plazo, total, cuota,
                    periodicidad, dias_periodo, dia_inicio_semana, dias_fijos_mes)
    return rid

def actualizar_cuotas_refinanciacion(rid, cuotas_pagadas, estado):
    with get_db() as db:
        db.execute("UPDATE refinanciaciones SET cuotas_pagadas=?, estado=? WHERE id=?",
                   (cuotas_pagadas, estado, rid))

def marcar_refinanciacion_refinanciada(rid, ref_id, cuotas_pagadas, tuvo_mora, dias_mora, mora_acumulada):
    from utils.fechas import hoy as _h
    with get_db() as db:
        db.execute("""UPDATE refinanciaciones SET estado='REFINANCIADO',
            cuotas_pagadas=?,tuvo_mora=?,dias_mora=?,mora_acumulada=?,fecha_refin=?,ref_id=?
            WHERE id=?""", (cuotas_pagadas,tuvo_mora,dias_mora,mora_acumulada,_h(),ref_id,rid))

def eliminar_refinanciacion(rid):
    with get_db() as db:
        db.execute("DELETE FROM cobros WHERE tipo='refinanciacion' AND operacion_id=?", (rid,))
        db.execute("DELETE FROM cuotas WHERE tipo='refinanciacion' AND operacion_id=?", (rid,))
        db.execute("DELETE FROM refinanciaciones WHERE id=?", (rid,))

# ── Ventas ────────────────────────────────────────────────
def get_ventas():
    with get_db() as db:
        return db.execute("SELECT * FROM ventas ORDER BY id DESC").fetchall()

def get_venta(vid):
    with get_db() as db:
        return db.execute("SELECT * FROM ventas WHERE id=?", (vid,)).fetchone()

def insertar_venta(cliente, producto, precio, fecha=None,
                   interes=0.0, plazo=1, cuota=0.0, total=0.0,
                   periodicidad="mensual", dias_periodo=30, monto_fijo_cuota=0.0,
                   costo=0.0, ganancia=0.0, dia_inicio_semana="", entrega_inicial=0.0,
                   dias_fijos_mes=""):
    from utils.fechas import hoy as _h
    if not total:
        total = precio * (1 + float(interes or 0) / 100) if plazo and int(plazo) > 1 else precio
    if not cuota:
        cuota = float(total) / int(plazo) if plazo and int(plazo) > 0 else float(total)
    fecha_final = fecha or _h()
    total_final  = round(float(total), 2)
    cuota_final  = round(float(cuota), 2)
    with get_db() as db:
        cur = db.execute(
            """INSERT INTO ventas
               (cliente,producto,precio,fecha,interes,plazo,cuota,total,periodicidad,dias_periodo,monto_fijo_cuota,costo,ganancia,dia_inicio_semana,entrega_inicial,dias_fijos_mes)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (cliente, producto, precio, fecha_final,
             float(interes or 0), int(plazo or 1),
             cuota_final, total_final,
             periodicidad, dias_periodo, round(float(monto_fijo_cuota or 0), 2),
             round(float(costo or 0), 2), round(float(ganancia or 0), 2), dia_inicio_semana,
             round(float(entrega_inicial or 0), 2), dias_fijos_mes or ""))
        vid = cur.lastrowid
    total_a_financiar = max(0.0, round(total_final - float(entrega_inicial or 0), 2))
    generar_cuotas("venta", vid, fecha_final, plazo, total_a_financiar, cuota_final,
                    periodicidad, dias_periodo, dia_inicio_semana, dias_fijos_mes)
    return vid

def actualizar_venta_pagado(vid, pagado, estado):
    with get_db() as db:
        db.execute("UPDATE ventas SET pagado=?, estado=? WHERE id=?", (pagado,estado,vid))

def marcar_venta_refinanciada(vid, ref_id, pagado):
    from utils.fechas import hoy as _h
    with get_db() as db:
        db.execute("UPDATE ventas SET estado='REFINANCIADO',pagado=?,fecha_refin=?,ref_id=? WHERE id=?",
                   (pagado,_h(),ref_id,vid))

def eliminar_venta(vid):
    with get_db() as db:
        db.execute("DELETE FROM cobros WHERE tipo='venta' AND operacion_id=?", (vid,))
        db.execute("DELETE FROM cuotas WHERE tipo='venta' AND operacion_id=?", (vid,))
        db.execute("DELETE FROM ventas WHERE id=?", (vid,))

# ── Cheques ───────────────────────────────────────────────
def get_cheques():
    with get_db() as db:
        return db.execute("SELECT * FROM cheques ORDER BY id DESC").fetchall()

def insertar_cheque(cliente, monto, descuento, neto):
    with get_db() as db:
        db.execute("INSERT INTO cheques (cliente,monto,descuento,neto) VALUES (?,?,?,?)",
                   (cliente,monto,descuento,neto))

def eliminar_cheque(cid):
    with get_db() as db:
        db.execute("DELETE FROM cheques WHERE id=?", (cid,))

# ── Cobros ────────────────────────────────────────────────
def siguiente_id_cobro():
    with get_db() as db:
        row = db.execute("SELECT id FROM cobros ORDER BY rowid DESC LIMIT 1").fetchone()
        if not row:
            return "P000001"
        try:
            n = int("".join(c for c in row["id"] if c.isdigit()))
            return f"P{n+1:06d}"
        except Exception:
            return "P000001"

def get_cobros_operacion(tipo, operacion_id, solo_activos=False):
    with get_db() as db:
        q = "SELECT * FROM cobros WHERE tipo=? AND operacion_id=?"
        if solo_activos:
            q += " AND estado='PAGADO'"
        q += " ORDER BY nro_cuota"
        return db.execute(q, (tipo, operacion_id)).fetchall()

def get_cobro_cuota(tipo, operacion_id, nro_cuota):
    with get_db() as db:
        return db.execute(
            "SELECT * FROM cobros WHERE tipo=? AND operacion_id=? AND nro_cuota=? AND estado='PAGADO'",
            (tipo, operacion_id, nro_cuota)).fetchone()

def get_cobros_cuota(tipo, operacion_id, nro_cuota):
    """Todos los cobros activos (no anulados) aplicados a esta cuota, en orden
    cronológico. Puede haber más de uno si la cuota se completó con pagos
    parciales sucesivos -- cada uno queda registrado como su propia fila."""
    with get_db() as db:
        return db.execute(
            "SELECT * FROM cobros WHERE tipo=? AND operacion_id=? AND nro_cuota=? AND estado='PAGADO' ORDER BY rowid",
            (tipo, operacion_id, nro_cuota)).fetchall()

def get_cobro_por_id(cobro_id):
    with get_db() as db:
        return db.execute("SELECT * FROM cobros WHERE id=?", (cobro_id,)).fetchone()

_TABLA_POR_TIPO = {"prestamo": "prestamos", "refinanciacion": "refinanciaciones", "venta": "ventas"}

def get_adelanto(tipo, operacion_id):
    """Saldo a favor (excedente de un pago que no alcanzó a completar otra cuota
    entera) que se aplica automáticamente en el próximo cobro de esa operación."""
    tabla = _TABLA_POR_TIPO.get(tipo)
    if not tabla:
        return 0.0
    with get_db() as db:
        row = db.execute(f"SELECT adelanto FROM {tabla} WHERE id=?", (operacion_id,)).fetchone()
        return float(row["adelanto"] or 0) if row else 0.0

def actualizar_adelanto(tipo, operacion_id, monto):
    tabla = _TABLA_POR_TIPO.get(tipo)
    if not tabla:
        return
    with get_db() as db:
        db.execute(f"UPDATE {tabla} SET adelanto=? WHERE id=?",
                   (round(float(monto or 0), 2), operacion_id))

def registrar_cobro(cobro_id, fecha_pago, tipo, operacion_id, nro_cuota,
                    cliente, monto, vencimiento, referencia, medio_pago,
                    mora_aplicada=0.0, periodo_gracia="NO", dias_atraso=0):
    with get_db() as db:
        db.execute("""INSERT INTO cobros
            (id,fecha_pago,tipo,operacion_id,nro_cuota,cliente,monto,
             vencimiento,estado,referencia,medio_pago,
             mora_aplicada,periodo_gracia,dias_atraso)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (cobro_id,fecha_pago,tipo,operacion_id,nro_cuota,
             cliente,monto,vencimiento,"PAGADO",referencia,medio_pago,
             mora_aplicada,periodo_gracia,dias_atraso))

def anular_cobro(cobro_id, motivo=""):
    from utils.fechas import hoy as _h
    with get_db() as db:
        db.execute("""UPDATE cobros SET estado='ANULADO',fecha_anulacion=?,motivo_anulacion=?
            WHERE id=?""", (_h(), motivo or "Anulado", cobro_id))

def resumen_cobros_operacion(tipo, operacion_id):
    cobros = get_cobros_operacion(tipo, operacion_id, solo_activos=True)
    return len(cobros), sum(float(c["monto"]) for c in cobros)

# ── Cuotas persistidas ─────────────────────────────────────
# El cronograma de cuotas (fechas de vencimiento + montos) se genera UNA VEZ al
# crear la operación y se guarda en `cuotas`, en vez de recalcularse en cada
# request. Esto evita que el calendario, las alertas y el cuotero operativo
# diverjan entre sí, y da estabilidad: si más adelante cambia la lógica de
# fechas, el historial ya generado no se mueve.
_TABLA_POR_TIPO_OP = {"prestamo": "prestamos", "refinanciacion": "refinanciaciones", "venta": "ventas"}


def generar_cuotas(tipo, operacion_id, fecha_inicio, plazo, total_a_financiar, cuota_base,
                    periodicidad="mensual", dias_periodo=30, dia_inicio_semana="",
                    dias_fijos_mes=""):
    """Genera y persiste el cronograma completo de cuotas de una operación
    (nueva o durante el backfill de operaciones ya existentes). Replica la
    regla histórica de que la última cuota absorbe el redondeo, y el caso
    especial de plazo<=1 (una sola cuota, sin periodicidad)."""
    from utils.fechas import vencimiento_cuota, sumar_meses

    plazo = max(1, int(plazo or 1))
    total_a_financiar = max(0.0, round(float(total_a_financiar or 0), 2))
    cuota_base = float(cuota_base) if cuota_base else (
        total_a_financiar / plazo if plazo else total_a_financiar)

    filas = []
    for nro in range(1, plazo + 1):
        monto = cuota_base
        if nro == plazo:
            monto = max(0.0, total_a_financiar - cuota_base * (plazo - 1))
        if plazo > 1:
            venc = vencimiento_cuota(
                fecha_inicio, nro, periodicidad=periodicidad, dias_periodo=dias_periodo,
                dia_inicio_semana=dia_inicio_semana, dias_fijos_mes=dias_fijos_mes,
            )
        elif tipo in ("prestamo", "refinanciacion"):
            venc = sumar_meses(fecha_inicio, nro)
        else:
            venc = fecha_inicio
        filas.append((tipo, operacion_id, nro, venc, round(monto, 2)))

    with get_db() as db:
        db.executemany(
            "INSERT OR IGNORE INTO cuotas (tipo,operacion_id,nro,vencimiento,monto) VALUES (?,?,?,?,?)",
            filas
        )


def get_cuotas_operacion(tipo, operacion_id):
    with get_db() as db:
        return db.execute(
            "SELECT * FROM cuotas WHERE tipo=? AND operacion_id=? ORDER BY nro",
            (tipo, operacion_id)
        ).fetchall()


def get_proximas_cuotas_pendientes(tipo):
    """Para cada operación activa del tipo dado, devuelve su próxima cuota
    pendiente de cobro (la de menor nro sin cobro 'PAGADO' asociado). Usado
    tanto por las alertas de vencimiento del dashboard como por las
    notificaciones del día."""
    tabla = _TABLA_POR_TIPO_OP.get(tipo)
    if not tabla:
        return []
    extra = "AND o.plazo > 1" if tipo == "venta" else ""
    with get_db() as db:
        return db.execute(f"""
            SELECT c.operacion_id AS operacion_id, c.nro AS nro,
                   c.vencimiento AS vencimiento, c.monto AS monto
            FROM cuotas c
            JOIN (
                SELECT c1.operacion_id AS oid, MIN(c1.nro) AS min_nro
                FROM cuotas c1
                JOIN {tabla} o ON o.id = c1.operacion_id
                LEFT JOIN cobros cb ON cb.tipo=c1.tipo AND cb.operacion_id=c1.operacion_id
                     AND cb.nro_cuota=c1.nro AND cb.estado='PAGADO'
                WHERE c1.tipo=? AND cb.id IS NULL AND o.estado NOT IN ('REFINANCIADO','CANCELADO') {extra}
                GROUP BY c1.operacion_id
            ) m ON m.oid = c.operacion_id AND m.min_nro = c.nro
            WHERE c.tipo = ?
        """, (tipo, tipo)).fetchall()


def backfill_cuotas():
    """Genera el cronograma de cuotas de operaciones que ya existían antes de
    que la tabla `cuotas` existiera, usando los valores YA GUARDADOS de cada
    operación (su propia periodicidad/dias_periodo/dia_inicio_semana/fecha),
    para que las fechas de vencimiento que el cliente ya conoce no se muevan.
    Es seguro llamarla en cada arranque: si una operación ya tiene filas en
    `cuotas` se salta."""
    with get_db() as db:
        con_cuotas = {(r["tipo"], r["operacion_id"]) for r in
                      db.execute("SELECT DISTINCT tipo, operacion_id FROM cuotas").fetchall()}
        prestamos = db.execute("SELECT * FROM prestamos").fetchall()
        refis     = db.execute("SELECT * FROM refinanciaciones").fetchall()
        ventas    = db.execute("SELECT * FROM ventas").fetchall()

    for p in prestamos:
        if ("prestamo", p["id"]) in con_cuotas:
            continue
        generar_cuotas("prestamo", p["id"], p["fecha"], p["plazo"], p["total"], p["cuota"],
                        p["periodicidad"] or "mensual", p["dias_periodo"] or 30,
                        p["dia_inicio_semana"] or "", p["dias_fijos_mes"] or "")

    for r in refis:
        if ("refinanciacion", r["id"]) in con_cuotas:
            continue
        periodicidad = r["periodicidad"] if "periodicidad" in r.keys() and r["periodicidad"] else "mensual"
        dias_periodo = r["dias_periodo"] if "dias_periodo" in r.keys() and r["dias_periodo"] else 30
        dia_inicio   = r["dia_inicio_semana"] if "dia_inicio_semana" in r.keys() and r["dia_inicio_semana"] else ""
        generar_cuotas("refinanciacion", r["id"], r["fecha"], r["plazo"], r["total"], r["cuota"],
                        periodicidad, dias_periodo, dia_inicio, "")

    for v in ventas:
        if ("venta", v["id"]) in con_cuotas:
            continue
        entrega = v["entrega_inicial"] if "entrega_inicial" in v.keys() and v["entrega_inicial"] else 0
        total_v = v["total"] if v["total"] else v["precio"]
        total_a_financiar = max(0.0, float(total_v or 0) - float(entrega or 0))
        generar_cuotas("venta", v["id"], v["fecha"], v["plazo"] or 1, total_a_financiar, v["cuota"],
                        v["periodicidad"] or "mensual", v["dias_periodo"] or 30,
                        v["dia_inicio_semana"] or "", v["dias_fijos_mes"] or "")


# ── Vencimientos calendario ───────────────────────────────
def get_vencimientos_mes(anio, mes):
    """Devuelve todas las cuotas con vencimiento en el mes dado, leyendo el
    cronograma ya persistido en `cuotas` en vez de recalcular fechas."""
    import calendar
    ultimo_dia = calendar.monthrange(anio, mes)[1]
    desde = f"{anio:04d}-{mes:02d}-01"
    hasta = f"{anio:04d}-{mes:02d}-{ultimo_dia:02d}"

    tipo_label = {"prestamo": "Préstamo", "refinanciacion": "Refinanciación", "venta": "Venta"}
    with get_db() as db:
        rows = db.execute("""
            SELECT c.vencimiento AS fecha, c.tipo AS tipo, c.nro AS nro_cuota, c.monto AS monto,
                   o.cliente AS cliente, o.estado AS estado, o.plazo AS plazo, c.operacion_id AS operacion_id,
                   cb.id AS cobro_id
            FROM cuotas c
            JOIN prestamos o ON o.id = c.operacion_id
            LEFT JOIN cobros cb ON cb.tipo=c.tipo AND cb.operacion_id=c.operacion_id
                 AND cb.nro_cuota=c.nro AND cb.estado='PAGADO'
            WHERE c.tipo='prestamo' AND c.vencimiento BETWEEN ? AND ?
              AND o.estado NOT IN ('REFINANCIADO','CANCELADO')
            UNION ALL
            SELECT c.vencimiento, c.tipo, c.nro, c.monto,
                   o.cliente, o.estado, o.plazo, c.operacion_id,
                   cb.id
            FROM cuotas c
            JOIN refinanciaciones o ON o.id = c.operacion_id
            LEFT JOIN cobros cb ON cb.tipo=c.tipo AND cb.operacion_id=c.operacion_id
                 AND cb.nro_cuota=c.nro AND cb.estado='PAGADO'
            WHERE c.tipo='refinanciacion' AND c.vencimiento BETWEEN ? AND ?
              AND o.estado NOT IN ('REFINANCIADO','CANCELADO')
            UNION ALL
            SELECT c.vencimiento, c.tipo, c.nro, c.monto,
                   o.cliente, o.estado, o.plazo, c.operacion_id,
                   cb.id
            FROM cuotas c
            JOIN ventas o ON o.id = c.operacion_id
            LEFT JOIN cobros cb ON cb.tipo=c.tipo AND cb.operacion_id=c.operacion_id
                 AND cb.nro_cuota=c.nro AND cb.estado='PAGADO'
            WHERE c.tipo='venta' AND c.vencimiento BETWEEN ? AND ?
              AND o.estado NOT IN ('REFINANCIADO','CANCELADO') AND o.plazo > 1
            ORDER BY fecha
        """, (desde, hasta, desde, hasta, desde, hasta)).fetchall()

    eventos = []
    for r in rows:
        eventos.append({
            "fecha": r["fecha"], "tipo": r["tipo"],
            "tipo_label": tipo_label.get(r["tipo"], r["tipo"].title()),
            "cliente": r["cliente"], "nro_cuota": r["nro_cuota"], "plazo": r["plazo"],
            "monto_fmt": _fmt_gs(r["monto"]),
            "operacion_id": int(r["operacion_id"]),
            "pagado": bool(r["cobro_id"]), "estado": r["estado"],
        })
    return eventos




# ── Scoring de comportamiento de pago ─────────────────────
"""
Scoring por módulo (prestamos / ventas / global):
  ★★★★★  EXCELENTE  — siempre paga a tiempo, sin mora (score 85-100)
  ★★★★☆  BUENO      — paga bien, alguna mora esporádica (score 65-84)
  ★★★☆☆  REGULAR    — demoras frecuentes, mora moderada (score 40-64)
  ★★☆☆☆  MALO       — muchas moras, pagos irregulares (score 20-39)
  ★☆☆☆☆  CRÍTICO    — muy mal historial (score 0-19)
"""

SCORING_NIVELES = [
    (85, "EXCELENTE", "★★★★★", "success",  "#166534", "#dcfce7", "#86efac"),
    (65, "BUENO",     "★★★★☆", "primary",  "#1e40af", "#dbeafe", "#93c5fd"),
    (40, "REGULAR",   "★★★☆☆", "warning",  "#92400e", "#fef3c7", "#fde68a"),
    (20, "MALO",      "★★☆☆☆", "danger",   "#991b1b", "#fee2e2", "#fca5a5"),
    (0,  "CRÍTICO",   "★☆☆☆☆", "dark",     "#1c1917", "#f5f5f4", "#d6d3d1"),
]

def _score_nivel(score: float) -> dict:
    for min_s, label, stars, bs, color, bg, border in SCORING_NIVELES:
        if score >= min_s:
            return {"label": label, "stars": stars, "bs": bs,
                    "color": color, "bg": bg, "border": border,
                    "score": round(score, 1)}
    return {"label": "SIN DATOS", "stars": "—", "bs": "secondary",
            "color": "#6b7280", "bg": "#f9fafb", "border": "#e5e7eb",
            "score": 0}


def calcular_scoring_cliente(nombre_cliente: str, tipo: str = "global") -> dict:
    """
    Calcula el scoring de comportamiento de pago de un cliente.

    tipo: 'prestamo' | 'venta' | 'refinanciacion' | 'global'

    Factores:
      - % de cuotas pagadas a tiempo (sin atraso)          → 50 pts
      - % de cuotas con período de gracia (leve retraso)   → 30 pts (penaliza levemente)
      - % de cuotas con mora aplicada (mal pagador)        → penaliza hasta -40 pts
      - Antigüedad / cantidad de operaciones               → hasta 10 pts bonus
    """
    tipos = ["prestamo", "venta", "refinanciacion"] if tipo == "global" else [tipo]

    total_cuotas    = 0
    a_tiempo        = 0
    con_gracia      = 0
    con_mora        = 0
    total_mora_gs   = 0.0
    total_cobrado   = 0.0
    n_operaciones   = 0

    with get_db() as db:
        for t in tipos:
            cobros = db.execute(
                """SELECT * FROM cobros
                   WHERE lower(cliente)=lower(?) AND tipo=? AND estado='PAGADO'""",
                (nombre_cliente, t)
            ).fetchall()
            for c in cobros:
                total_cuotas  += 1
                total_cobrado += float(c["monto"] or 0)
                mora = float(c["mora_aplicada"] or 0)
                gracia = (c["periodo_gracia"] or "NO") == "SI"
                dias_at = int(c["dias_atraso"] or 0)
                total_mora_gs += mora
                if mora > 0:
                    con_mora   += 1
                elif gracia:
                    con_gracia += 1
                else:
                    a_tiempo   += 1

        # Número de operaciones distintas para bonus antigüedad
        for t in tipos:
            tabla = {"prestamo":"prestamos","venta":"ventas","refinanciacion":"refinanciaciones"}.get(t,"prestamos")
            n = db.execute(
                f"SELECT COUNT(*) FROM {tabla} WHERE lower(cliente)=lower(?)",
                (nombre_cliente,)
            ).fetchone()[0]
            n_operaciones += n

    if total_cuotas == 0:
        return {**_score_nivel(0), "total_cuotas": 0, "a_tiempo": 0,
                "con_gracia": 0, "con_mora": 0, "total_mora_gs": 0,
                "total_mora_fmt": "Gs. 0", "n_operaciones": 0,
                "pct_tiempo": 0, "pct_gracia": 0, "pct_mora": 0,
                "tipo": tipo, "sin_datos": True}

    pct_tiempo = a_tiempo  / total_cuotas * 100
    pct_gracia = con_gracia / total_cuotas * 100
    pct_mora   = con_mora   / total_cuotas * 100

    # Score base: empieza en 100
    score = 100.0
    score -= pct_mora  * 0.9   # cada % de mora resta 0.9 pts
    score -= pct_gracia * 0.3  # cada % de gracia resta 0.3 pts
    # Bonus por antigüedad (hasta +5)
    bonus = min(5.0, n_operaciones * 1.0)
    score = max(0.0, min(100.0, score + bonus))

    nivel = _score_nivel(score)
    return {
        **nivel,
        "total_cuotas":  total_cuotas,
        "a_tiempo":      a_tiempo,
        "con_gracia":    con_gracia,
        "con_mora":      con_mora,
        "total_mora_gs": round(total_mora_gs, 2),
        "total_mora_fmt": _fmt_gs(total_mora_gs),
        "n_operaciones": n_operaciones,
        "pct_tiempo":    round(pct_tiempo, 1),
        "pct_gracia":    round(pct_gracia, 1),
        "pct_mora":      round(pct_mora, 1),
        "tipo":          tipo,
        "sin_datos":     False,
    }


def get_scoring_todos_clientes():
    """Devuelve scoring global y por módulo para todos los clientes."""
    result = []
    with get_db() as db:
        clientes = db.execute("SELECT nombre FROM clientes ORDER BY nombre").fetchall()
    for c in clientes:
        nombre = c["nombre"]
        result.append({
            "nombre":  nombre,
            "global":  calcular_scoring_cliente(nombre, "global"),
            "prestamo": calcular_scoring_cliente(nombre, "prestamo"),
            "venta":    calcular_scoring_cliente(nombre, "venta"),
        })
    return result


def get_alertas_hoy():
    """Cuotas que vencen HOY o están vencidas y pendientes (préstamos y
    refinanciaciones), leyendo el cronograma persistido en `cuotas`."""
    from utils.fechas import hoy as _h
    from datetime import datetime as _dt
    hoy_s = _h()
    hoy_d = _dt.strptime(hoy_s, "%Y-%m-%d").date()
    alertas = []
    labels = {"prestamo": ("prestamos", "Préstamo"),
              "refinanciacion": ("refinanciaciones", "Refinanciación")}

    for tipo, (tabla, label) in labels.items():
        pendientes = get_proximas_cuotas_pendientes(tipo)
        if not pendientes:
            continue
        with get_db() as db:
            clientes_map = {row["id"]: row["cliente"] for row in
                             db.execute(f"SELECT id, cliente FROM {tabla}").fetchall()}
        for r in pendientes:
            try:
                venc_d = _dt.strptime(r["vencimiento"], "%Y-%m-%d").date()
            except Exception:
                continue
            delta = (hoy_d - venc_d).days
            if delta < 0:
                continue
            alertas.append({
                "cliente": clientes_map.get(r["operacion_id"], ""),
                "tipo": label, "tipo_key": tipo,
                "operacion_id": int(r["operacion_id"]),
                "nro_cuota": r["nro"], "vencimiento": r["vencimiento"],
                "dias": delta, "estado": "HOY" if delta == 0 else "VENCIDA",
                "monto_fmt": _fmt_gs(r["monto"]),
            })

    return sorted(alertas, key=lambda a: (-a["dias"], a["cliente"]))

# ── Reportes de utilidad ──────────────────────────────────
def get_reporte_utilidades(anio=None, mes=None, cliente=None):
    """
    Calcula:
    - Utilidad ESTIMADA: suma de ganancia proyectada de todas las operaciones
    - Utilidad COBRADA: suma de mora + diferencia interes de cobros reales pagados
    - Por mes, por cliente, o global
    """
    from utils.fechas import hoy as _h
    from datetime import datetime as _dt

    hoy_str = _h()

    with get_db() as db:
        # ── Utilidad cobrada real (de cobros) ─────────────────
        # Un cobro incluye la cuota (capital + interes prorrateado) + mora
        # La ganancia real = mora_aplicada + (cuota - capital_por_cuota)
        # Simplificamos: utilidad cobrada = sum de mora_aplicada en cobros del período

        q_cobros = """
            SELECT c.*, p.interes AS tasa_p, p.monto AS capital_p, p.plazo AS plazo_p,
                   r.interes AS tasa_r, r.deuda AS capital_r, r.plazo AS plazo_r,
                   v.ganancia AS ganancia_v, v.plazo AS plazo_v
            FROM cobros c
            LEFT JOIN prestamos p ON c.tipo='prestamo' AND c.operacion_id=p.id
            LEFT JOIN refinanciaciones r ON c.tipo='refinanciacion' AND c.operacion_id=r.id
            LEFT JOIN ventas v ON c.tipo='venta' AND c.operacion_id=v.id
            WHERE c.estado='PAGADO'
        """
        params = []
        if anio and mes:
            q_cobros += " AND strftime('%Y-%m', c.fecha_pago) = ?"
            params.append(f"{anio:04d}-{mes:02d}")
        elif anio:
            q_cobros += " AND strftime('%Y', c.fecha_pago) = ?"
            params.append(f"{anio:04d}")
        if cliente:
            q_cobros += " AND lower(c.cliente) = lower(?)"
            params.append(cliente)

        cobros = db.execute(q_cobros, params).fetchall()

        utilidad_cobrada = 0.0
        mora_cobrada     = 0.0
        util_cobrada_prestamos = 0.0
        util_cobrada_refin     = 0.0
        util_cobrada_ventas    = 0.0
        cobros_por_mes   = {}
        cobros_por_cliente = {}

        for c in cobros:
            mora = float(c["mora_aplicada"] or 0)
            # Interes prorrateado por cuota
            tasa_p = float(c["tasa_p"] or 0)
            cap_p  = float(c["capital_p"] or 0)
            pla_p  = int(c["plazo_p"] or 1)
            tasa_r = float(c["tasa_r"] or 0)
            cap_r  = float(c["capital_r"] or 0)
            pla_r  = int(c["plazo_r"] or 1)
            gan_v  = float(c["ganancia_v"] or 0)
            pla_v  = int(c["plazo_v"] or 1)

            if c["tipo"] == "prestamo" and cap_p > 0 and pla_p > 0:
                ganancia_cuota = (cap_p * tasa_p / 100) / pla_p
            elif c["tipo"] == "refinanciacion" and cap_r > 0 and pla_r > 0:
                ganancia_cuota = (cap_r * tasa_r / 100) / pla_r
            elif c["tipo"] == "venta" and gan_v != 0 and pla_v > 0:
                # Ganancia de la venta (precio + interés - costo del producto) prorrateada por cuota
                ganancia_cuota = gan_v / pla_v
            else:
                ganancia_cuota = 0.0

            total_util = round(ganancia_cuota + mora, 2)
            utilidad_cobrada += total_util
            mora_cobrada     += mora

            if c["tipo"] == "prestamo":
                util_cobrada_prestamos += total_util
            elif c["tipo"] == "refinanciacion":
                util_cobrada_refin += total_util
            elif c["tipo"] == "venta":
                util_cobrada_ventas += total_util

            mes_key = c["fecha_pago"][:7] if c["fecha_pago"] else "?"
            cobros_por_mes.setdefault(mes_key, {"cobros":0,"monto":0,"utilidad":0,"mora":0})
            cobros_por_mes[mes_key]["cobros"]   += 1
            cobros_por_mes[mes_key]["monto"]    += float(c["monto"] or 0)
            cobros_por_mes[mes_key]["utilidad"] += total_util
            cobros_por_mes[mes_key]["mora"]     += mora

            cli = c["cliente"] or "—"
            cobros_por_cliente.setdefault(cli, {"cobros":0,"monto":0,"utilidad":0,"mora":0})
            cobros_por_cliente[cli]["cobros"]   += 1
            cobros_por_cliente[cli]["monto"]    += float(c["monto"] or 0)
            cobros_por_cliente[cli]["utilidad"] += total_util
            cobros_por_cliente[cli]["mora"]     += mora

        # ── Utilidad ESTIMADA (proyectada de operaciones activas) ──
        q_est = "SELECT * FROM prestamos WHERE estado='ACTIVO'"
        q_est_r = "SELECT * FROM refinanciaciones WHERE estado='ACTIVO'"
        prms_est = []
        if cliente:
            q_est   += " AND lower(cliente)=lower(?)"
            q_est_r += " AND lower(cliente)=lower(?)"
            prms_est = [cliente]

        util_est_prestamos = db.execute(
            f"SELECT COALESCE(SUM(ganancia),0) FROM prestamos WHERE estado='ACTIVO'" +
            (" AND lower(cliente)=lower(?)" if cliente else ""),
            ([cliente] if cliente else [])
        ).fetchone()[0] or 0

        util_est_refin = db.execute(
            f"SELECT COALESCE(SUM(ganancia),0) FROM refinanciaciones WHERE estado='ACTIVO'" +
            (" AND lower(cliente)=lower(?)" if cliente else ""),
            ([cliente] if cliente else [])
        ).fetchone()[0] or 0

        util_est_ventas = db.execute(
            f"SELECT COALESCE(SUM(ganancia),0) FROM ventas WHERE estado='ACTIVO'" +
            (" AND lower(cliente)=lower(?)" if cliente else ""),
            ([cliente] if cliente else [])
        ).fetchone()[0] or 0

        util_est_total = float(util_est_prestamos) + float(util_est_refin) + float(util_est_ventas)

        # Pendiente a cobrar (saldo de cobros futuros)
        total_cobrado_real = db.execute(
            "SELECT COALESCE(SUM(monto),0) FROM cobros WHERE estado='PAGADO'" +
            (" AND lower(cliente)=lower(?)" if cliente else ""),
            ([cliente] if cliente else [])
        ).fetchone()[0] or 0

    return {
        "utilidad_cobrada":       round(utilidad_cobrada, 2),
        "utilidad_cobrada_fmt":   _fmt_gs(utilidad_cobrada),
        "mora_cobrada":           round(mora_cobrada, 2),
        "mora_cobrada_fmt":       _fmt_gs(mora_cobrada),
        "utilidad_estimada":      round(util_est_total, 2),
        "utilidad_estimada_fmt":  _fmt_gs(util_est_total),
        "total_cobrado_real":     round(float(total_cobrado_real), 2),
        "total_cobrado_real_fmt": _fmt_gs(float(total_cobrado_real)),
        # Desglose por módulo (para que se vea el aporte de cada uno)
        "estimada_prestamos":     round(float(util_est_prestamos), 2),
        "estimada_prestamos_fmt": _fmt_gs(util_est_prestamos),
        "estimada_refin":         round(float(util_est_refin), 2),
        "estimada_refin_fmt":     _fmt_gs(util_est_refin),
        "estimada_ventas":        round(float(util_est_ventas), 2),
        "estimada_ventas_fmt":    _fmt_gs(util_est_ventas),
        "cobrada_prestamos":      round(util_cobrada_prestamos, 2),
        "cobrada_prestamos_fmt":  _fmt_gs(util_cobrada_prestamos),
        "cobrada_refin":          round(util_cobrada_refin, 2),
        "cobrada_refin_fmt":      _fmt_gs(util_cobrada_refin),
        "cobrada_ventas":         round(util_cobrada_ventas, 2),
        "cobrada_ventas_fmt":     _fmt_gs(util_cobrada_ventas),
        "por_mes":     {k: {**v,
                            "utilidad_fmt": _fmt_gs(v["utilidad"]),
                            "mora_fmt":     _fmt_gs(v["mora"]),
                            "monto_fmt":    _fmt_gs(v["monto"])}
                        for k, v in sorted(cobros_por_mes.items(), reverse=True)},
        "por_cliente": {k: {**v,
                            "utilidad_fmt": _fmt_gs(v["utilidad"]),
                            "mora_fmt":     _fmt_gs(v["mora"]),
                            "monto_fmt":    _fmt_gs(v["monto"])}
                        for k, v in sorted(cobros_por_cliente.items(),
                                           key=lambda x: -x[1]["utilidad"])},
    }


def _fmt_gs(v):
    try: return f"Gs. {float(v or 0):,.0f}".replace(",",".")
    except: return "Gs. 0"


def get_lista_clientes_nombres():
    with get_db() as db:
        return [r["nombre"] for r in db.execute("SELECT nombre FROM clientes ORDER BY nombre").fetchall()]


# ── Historial de mora ─────────────────────────────────────
def registrar_historial_mora(cliente, tipo, operacion_id, nro_cuota,
                              vencimiento, dias_atraso,
                              mora_aplicada=0.0, periodo_gracia="NO"):
    """Guarda registro de cuota con atraso en el historial."""
    if dias_atraso <= 0:
        return
    with get_db() as db:
        # Evitar duplicado: si ya hay un registro para esta cuota, actualizar
        exist = db.execute(
            "SELECT id FROM historial_mora WHERE tipo=? AND operacion_id=? AND nro_cuota=?",
            (tipo, operacion_id, nro_cuota)
        ).fetchone()
        if exist:
            db.execute("""UPDATE historial_mora
                SET dias_atraso=?, mora_aplicada=?, periodo_gracia=?, fecha_registro=date('now')
                WHERE id=?""",
                (dias_atraso, mora_aplicada, periodo_gracia, exist["id"]))
        else:
            db.execute("""INSERT INTO historial_mora
                (cliente, tipo, operacion_id, nro_cuota, vencimiento,
                 dias_atraso, mora_aplicada, periodo_gracia)
                VALUES (?,?,?,?,?,?,?,?)""",
                (cliente, tipo, operacion_id, nro_cuota, vencimiento,
                 dias_atraso, mora_aplicada, periodo_gracia))


def get_historial_mora_cliente(nombre_cliente):
    """Devuelve el historial de mora de un cliente."""
    with get_db() as db:
        return db.execute(
            """SELECT * FROM historial_mora WHERE lower(cliente)=lower(?)
               ORDER BY fecha_registro DESC""",
            (nombre_cliente,)
        ).fetchall()


def get_historial_mora_operacion(tipo, operacion_id):
    """Devuelve el historial de mora de una operación específica."""
    with get_db() as db:
        return db.execute(
            """SELECT * FROM historial_mora WHERE tipo=? AND operacion_id=?
               ORDER BY nro_cuota""",
            (tipo, operacion_id)
        ).fetchall()

# ── Stats ─────────────────────────────────────────────────
def get_ganancia_consolidada():
    """Ganancia YA COBRADA (realizada), a diferencia de la 'utilidad estimada' que
    proyecta el total de todas las operaciones aunque no se hayan cobrado todavía.
    Se calcula proporcionalmente a lo efectivamente pagado en cada operación:
    (cobrado / total_operación) * ganancia_operación. La mora no se cuenta como
    ganancia del producto/crédito, se resta del monto cobrado antes de prorratear."""
    with get_db() as db:
        rows = db.execute("""
            SELECT tipo, operacion_id, SUM(monto - COALESCE(mora_aplicada,0)) AS cobrado
            FROM cobros
            WHERE estado='PAGADO'
            GROUP BY tipo, operacion_id
        """).fetchall()

        total_prestamos = total_refin = total_ventas = 0.0
        for r in rows:
            tipo, oid, cobrado = r["tipo"], r["operacion_id"], float(r["cobrado"] or 0)
            if cobrado <= 0:
                continue
            if tipo == "prestamo":
                op = db.execute("SELECT total, ganancia FROM prestamos WHERE id=?", (oid,)).fetchone()
            elif tipo == "refinanciacion":
                op = db.execute("SELECT total, ganancia FROM refinanciaciones WHERE id=?", (oid,)).fetchone()
            elif tipo == "venta":
                op = db.execute("SELECT total, ganancia FROM ventas WHERE id=?", (oid,)).fetchone()
            else:
                op = None
            if not op:
                continue
            total_op = float(op["total"] or 0)
            gan_op   = float(op["ganancia"] or 0)
            if total_op <= 0 or gan_op == 0:
                continue
            proporcion = min(1.0, cobrado / total_op)
            realizada  = proporcion * gan_op
            if tipo == "prestamo":
                total_prestamos += realizada
            elif tipo == "refinanciacion":
                total_refin += realizada
            elif tipo == "venta":
                total_ventas += realizada

        return dict(
            consolidada_prestamos=round(total_prestamos, 2),
            consolidada_refin=round(total_refin, 2),
            consolidada_ventas=round(total_ventas, 2),
            consolidada_total=round(total_prestamos + total_refin + total_ventas, 2),
        )


def get_stats():
    with get_db() as db:
        nc   = db.execute("SELECT COUNT(*) FROM clientes").fetchone()[0]
        np   = db.execute("SELECT COUNT(*) FROM prestamos").fetchone()[0]
        nr   = db.execute("SELECT COUNT(*) FROM refinanciaciones").fetchone()[0]
        nv   = db.execute("SELECT COUNT(*) FROM ventas").fetchone()[0]
        cap  = db.execute("SELECT COALESCE(SUM(monto),0) FROM prestamos").fetchone()[0]
        capr = db.execute("SELECT COALESCE(SUM(deuda),0) FROM refinanciaciones").fetchone()[0]
        up   = db.execute("SELECT COALESCE(SUM(ganancia),0) FROM prestamos").fetchone()[0]
        ur   = db.execute("SELECT COALESCE(SUM(ganancia),0) FROM refinanciaciones").fetchone()[0]
        uv   = db.execute("SELECT COALESCE(SUM(ganancia),0) FROM ventas").fetchone()[0]
        venc = db.execute("SELECT COUNT(*) FROM prestamos WHERE vencimiento<date('now') AND estado='ACTIVO'").fetchone()[0]
        uc   = db.execute("SELECT * FROM clientes ORDER BY id DESC LIMIT 5").fetchall()
        up5  = db.execute("SELECT * FROM prestamos ORDER BY id DESC LIMIT 5").fetchall()
        ur5  = db.execute("SELECT * FROM refinanciaciones ORDER BY id DESC LIMIT 5").fetchall()
    return dict(n_clientes=nc,n_prestamos=np,n_refinanciaciones=nr,n_ventas=nv,
                cap_prestamos=cap,cap_refin=capr,util_prestamos=up,util_refin=ur,util_ventas=uv,
                util_total=up+ur+uv,vencidos=venc,
                ult_clientes=uc,ult_prestamos=up5,ult_refin=ur5)
