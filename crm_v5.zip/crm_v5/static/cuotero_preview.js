/**
 * cuotero_preview.js — FinanGest
 * Simulación del cuotero en el navegador (antes de guardar), compartida por
 * los formularios de Préstamos, Ventas y Refinanciaciones. Replica EXACTAMENTE
 * la lógica de utils/fechas.py (vencimiento_cuota / vencimiento_cuota_fija) y
 * utils/calculos.py (calcular_plazo_y_cuota) para que el preview coincida con
 * lo que el backend termina persistiendo en la tabla `cuotas`.
 */
window.CuoteroPreview = (function () {

    function pad2(n) { return String(n).padStart(2, '0'); }

    function toISO(d) {
        return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
    }

    function fromISO(s) {
        const [y, m, d] = s.split('-').map(Number);
        return new Date(y, m - 1, d);
    }

    function diasEnMes(anio, mesIdx) {
        // mesIdx: 0-11 (como Date). Día 0 del mes siguiente = último día del mes actual.
        return new Date(anio, mesIdx + 1, 0).getDate();
    }

    function sumarMeses(fechaISO, meses) {
        const base = fromISO(fechaISO);
        const mesTotal = base.getMonth() + meses;
        const anio = base.getFullYear() + Math.floor(mesTotal / 12);
        const mes  = ((mesTotal % 12) + 12) % 12;
        const dia  = Math.min(base.getDate(), diasEnMes(anio, mes));
        return toISO(new Date(anio, mes, dia));
    }

    function sumarDias(fechaISO, dias) {
        const d = fromISO(fechaISO);
        d.setDate(d.getDate() + dias);
        return toISO(d);
    }

    // Próxima fecha (siempre posterior) cuyo día de semana (Date.getDay(): dom=0)
    // coincide con diaJs. Replica utils/fechas.py:proximo_dia_semana.
    function proximoDiaSemana(fechaISO, diaJs) {
        const actual = fromISO(fechaISO).getDay();
        let diff = diaJs - actual;
        if (diff <= 0) diff += 7;
        return sumarDias(fechaISO, diff);
    }

    // Parsea "5" o "14,28" a una lista ordenada de enteros 1-31 sin duplicados.
    function parseDiasFijos(diasFijosMes) {
        if (!diasFijosMes) return [];
        const dias = String(diasFijosMes).split(',')
            .map(s => parseInt(s.trim(), 10))
            .filter(n => Number.isInteger(n) && n >= 1 && n <= 31);
        return Array.from(new Set(dias)).sort((a, b) => a - b);
    }

    // Vencimiento de la cuota N cuando la periodicidad usa día(s) fijos del mes
    // (mensual: 1 día; quincenal con fechas fijas: 2 días). Replica
    // utils/fechas.py:vencimiento_cuota_fija.
    function vencimientoCuotaFija(fechaInicioISO, nro, diasFijos) {
        if (!diasFijos.length) return sumarMeses(fechaInicioISO, nro);
        const fechaIni = fromISO(fechaInicioISO);
        let anio = fechaIni.getFullYear(), mes = fechaIni.getMonth();
        let encontrados = 0;
        for (let i = 0; i < 600; i++) {
            for (const d of diasFijos) {
                const diaReal = Math.min(d, diasEnMes(anio, mes));
                const candidata = new Date(anio, mes, diaReal);
                if (candidata > fechaIni) {
                    encontrados++;
                    if (encontrados === nro) return toISO(candidata);
                }
            }
            mes++;
            if (mes > 11) { mes = 0; anio++; }
        }
        return sumarMeses(fechaInicioISO, nro);
    }

    const DIA_MAP = { lunes: 1, domingo: 0, viernes: 5 };

    // Replica utils/fechas.py:vencimiento_cuota.
    function vencimientoCuota(fechaInicioISO, nro, periodicidad, diasPeriodo, diaInicioSemana, diasFijosMes) {
        const diasFijos = parseDiasFijos(diasFijosMes);
        if (diasFijos.length && (periodicidad === 'mensual' || periodicidad === 'quincenal')) {
            return vencimientoCuotaFija(fechaInicioISO, nro, diasFijos);
        }
        const dp = parseInt(diasPeriodo, 10) || 30;
        if (periodicidad === 'semanal' && diaInicioSemana in DIA_MAP) {
            const primerVenc = proximoDiaSemana(fechaInicioISO, DIA_MAP[diaInicioSemana]);
            return sumarDias(primerVenc, dp * (nro - 1));
        }
        if (dp && dp !== 30) {
            return sumarDias(fechaInicioISO, dp * nro);
        }
        return sumarMeses(fechaInicioISO, nro);
    }

    // Replica utils/calculos.py:calcular_monto_costo.
    function calcularMontoCosto(monto, ivaPct, montoCostoManual) {
        monto = monto || 0;
        montoCostoManual = montoCostoManual || 0;
        ivaPct = ivaPct || 0;
        if (montoCostoManual > 0) return Math.round(montoCostoManual * 100) / 100;
        if (ivaPct > 0) return Math.round(monto * (1 + ivaPct / 100) * 100) / 100;
        return Math.round(monto * 100) / 100;
    }

    const MAX_CUOTAS = 360;

    // Replica utils/calculos.py:calcular_plazo_y_cuota.
    function calcularPlazoYCuota(montoAFinanciar, montoFijoCuota, plazoManual) {
        montoAFinanciar = Math.max(0, Math.round((montoAFinanciar || 0) * 100) / 100);
        montoFijoCuota = montoFijoCuota || 0;
        plazoManual = parseInt(plazoManual, 10) || 0;

        if (montoAFinanciar <= 0) return { plazo: 1, cuota: 0, error: null };

        if (montoFijoCuota > 0) {
            const plazoEstim = Math.ceil(montoAFinanciar / montoFijoCuota);
            if (plazoEstim > MAX_CUOTAS) {
                return {
                    plazo: null, cuota: null,
                    error: `El monto fijo ingresado es muy bajo: implicaría ${plazoEstim} cuotas. ` +
                           `Ingrese un monto mayor (máx. ${MAX_CUOTAS} cuotas).`,
                };
            }
            const plazo = Math.max(1, plazoEstim);
            const cuota = plazo > 1 ? montoFijoCuota : montoAFinanciar;
            return { plazo, cuota: Math.round(cuota * 100) / 100, error: null };
        }

        const plazo = Math.max(1, plazoManual);
        const cuota = montoAFinanciar / plazo;
        return { plazo, cuota: Math.round(cuota * 100) / 100, error: null };
    }

    // Genera las filas del cuotero (nro, vencimiento, monto, saldo) igual que
    // database.py:generar_cuotas -- última cuota absorbe el redondeo. `tipo`
    // es 'prestamo' | 'refinanciacion' | 'venta': cuando plazo<=1, préstamos y
    // refinanciaciones vencen 1 mes después (sumarMeses), pero una venta al
    // contado (plazo=1) vence el mismo día de la operación.
    function generarCuotero(fechaInicioISO, plazo, totalAFinanciar, cuotaBase,
                             periodicidad, diasPeriodo, diaInicioSemana, diasFijosMes, tipo) {
        plazo = Math.max(1, parseInt(plazo, 10) || 1);
        totalAFinanciar = Math.max(0, Math.round((totalAFinanciar || 0) * 100) / 100);
        cuotaBase = cuotaBase || (totalAFinanciar / plazo);

        const filas = [];
        let saldo = totalAFinanciar;
        for (let nro = 1; nro <= plazo; nro++) {
            let monto = cuotaBase;
            if (nro === plazo) monto = Math.max(0, totalAFinanciar - cuotaBase * (plazo - 1));
            let venc;
            if (plazo > 1) {
                venc = vencimientoCuota(fechaInicioISO, nro, periodicidad, diasPeriodo, diaInicioSemana, diasFijosMes);
            } else if (tipo === 'prestamo' || tipo === 'refinanciacion') {
                venc = sumarMeses(fechaInicioISO, nro);
            } else {
                venc = fechaInicioISO;
            }
            saldo = Math.max(0, Math.round((saldo - monto) * 100) / 100);
            filas.push({ nro, vencimiento: venc, monto: Math.round(monto * 100) / 100, saldo });
        }
        return filas;
    }

    return {
        sumarMeses, sumarDias, proximoDiaSemana,
        parseDiasFijos, vencimientoCuotaFija, vencimientoCuota,
        calcularPlazoYCuota, calcularMontoCosto, generarCuotero,
    };
})();
