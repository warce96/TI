-- Create table
create table DATOS.CONSOLIDADO_CAVAPY
(
  id_registro         NUMBER,
  lote                NUMBER,
  fecha               DATE not null,
  rut                 VARCHAR2(20) not null,
  tipo_persona        VARCHAR2(100),
  nombre_apellido     VARCHAR2(300),
  tipo_documento      VARCHAR2(100),
  nro_identidad       VARCHAR2(50),
  nacionalidad        VARCHAR2(100),
  moneda              VARCHAR2(10),
  total_cant_acciones NUMBER,
  total_capital_int   NUMBER,
  total_pct_partic    NUMBER(10,5),
  total_cant_votos    NUMBER,
  total_pct_votos     NUMBER(10,5),
  fecha_carga         DATE not null,
  usuario_carga       VARCHAR2(100) not null
)
tablespace DATOS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate indexes 
create index IDX_CONSC_FECHA on DATOS.CONSOLIDADO_CAVAPY (FECHA)
  tablespace INDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index IDX_CONSC_FECHA_CARGA on DATOS.CONSOLIDADO_CAVAPY (FECHA_CARGA)
  tablespace INDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index IDX_CONSC_RUT on DATOS.CONSOLIDADO_CAVAPY (RUT)
  tablespace INDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table DATOS.CONSOLIDADO_CAVAPY
  add constraint PK_CONSOLIDADO_CAVAPY primary key (ID_REGISTRO)
  using index
  tablespace DATOS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
