-- Create table
create table DATOS.DEPOSITANTES_CAVAPY
(
  cod_depositante          NUMBER(10) not null,
  nombre_depositante       VARCHAR2(100) not null,
  fecha_ult_modificacion   DATE not null,
  usuario_ult_modificacion VARCHAR2(100) not null
)
tablespace DATOS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
