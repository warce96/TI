-- Create table
create table DATOS.TRANSACCIONES_CAVAPY
(
  id_registro                  NUMBER,
  referencia_transaccion       VARCHAR2(100) not null,
  fecha                        DATE not null,
  emisor                       VARCHAR2(200),
  isin                         VARCHAR2(50),
  codigo_operacion             VARCHAR2(100),
  remitente                    VARCHAR2(200),
  nro_cuenta_valores_remitente VARCHAR2(100),
  nombre_cliente_remitente     VARCHAR2(300),
  parte_receptora              VARCHAR2(200),
  nro_cuenta_valores_receptora VARCHAR2(100),
  nombre_cliente_receptor      VARCHAR2(300),
  cantidad                     NUMBER,
  monto_nominal                NUMBER,
  moneda                       VARCHAR2(10),
  fecha_vencimiento_operacion  DATE,
  juzgado                      VARCHAR2(200),
  fecha_carga                  DATE not null,
  usuario_carga                VARCHAR2(100) not null
)
tablespace DATOS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate indexes 
create index IDX_TRANSCAV_FECHA on DATOS.TRANSACCIONES_CAVAPY (FECHA)
  tablespace INDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index IDX_TRANSCAV_FECHA_CARGA on DATOS.TRANSACCIONES_CAVAPY (FECHA_CARGA)
  tablespace INDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
create index IDX_TRANSCAV_ISIN on DATOS.TRANSACCIONES_CAVAPY (ISIN)
  tablespace INDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table DATOS.TRANSACCIONES_CAVAPY
  add constraint PK_TRANSACCIONES_CAVAPY primary key (ID_REGISTRO)
  using index
  tablespace DATOS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table DATOS.TRANSACCIONES_CAVAPY
  add constraint UQ_TRANSCAV_REFERENCIA unique (REFERENCIA_TRANSACCION)
  using index
  tablespace DATOS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
