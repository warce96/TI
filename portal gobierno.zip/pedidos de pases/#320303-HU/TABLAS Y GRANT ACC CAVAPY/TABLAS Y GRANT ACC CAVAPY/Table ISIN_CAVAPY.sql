-- Create table
create table DATOS.ISIN_CAVAPY
(
  id_isin        NUMBER,
  key_acc        CHAR(4),
  nro_isin       VARCHAR2(20) not null,
  emisor         VARCHAR2(30) not null,
  fecha_emision  DATE default SYSDATE not null,
  estado         VARCHAR2(30) not null,
  usuario        VARCHAR2(3),
  fecha_creacion DATE default SYSDATE not null,
  fecha_ult_mod  DATE
)
tablespace DATOS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 384K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate indexes 
create index DATOS.IDX_ISIN_CAVAPY_01 on DATOS.ISIN_CAVAPY (ID_ISIN)
  tablespace INDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table DATOS.ISIN_CAVAPY
  add constraint PK_ISIN_CAVAPY primary key (NRO_ISIN)
  using index
  tablespace DATOS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
