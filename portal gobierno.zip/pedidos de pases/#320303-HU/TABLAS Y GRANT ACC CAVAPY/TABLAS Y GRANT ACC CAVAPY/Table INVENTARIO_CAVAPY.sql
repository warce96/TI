-- Create table
create table DATOS.INVENTARIO_CAVAPY
(
  lote                     NUMBER,
  fecha_alta               DATE,
  numero_depositante       VARCHAR2(100),
  depositante              VARCHAR2(100),
  rut                      NUMBER,
  numero_cuenta            NUMBER,
  tipo_persona             VARCHAR2(100),
  nombre_apellido          VARCHAR2(200),
  tipo_documento           VARCHAR2(100),
  nro_identidad            VARCHAR2(20),
  direccion                VARCHAR2(200),
  estado_residencia        VARCHAR2(100),
  fecha_nacimiento         DATE,
  correo_electronico       VARCHAR2(200),
  numero_telefono          VARCHAR2(20),
  isin                     VARCHAR2(20),
  tipo_accion              VARCHAR2(100),
  clase                    CHAR(1),
  cant_votos               NUMBER,
  disponibles              NUMBER,
  pendiente_canje          NUMBER,
  congelado                NUMBER,
  prenda                   NUMBER,
  repo                     NUMBER,
  no_disponibles           NUMBER,
  total                    NUMBER,
  valor_nominal_individual NUMBER,
  capital_integrado        NUMBER,
  porcentaje_participacion VARCHAR2(100),
  total_votos              NUMBER
)
tablespace DATOS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
