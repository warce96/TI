grant select, delete, update, insert on DATOS.ACCIONES_ESCRITURALES_CAVAPY to ogd_pentaho;

grant select, delete, update, insert on DATOS.ISIN_CAVAPY to ogd_pentaho;

grant select, delete, update, insert on DATOS.INVENTARIO_CAVAPY to ogd_pentaho;

grant select, delete, update, insert on DATOS.CONSOLIDADO_CAVAPY to ogd_pentaho;

grant select, delete, update, insert on DATOS.TRANSACCIONES_CAVAPY to ogd_pentaho;

grant select, delete, update, insert on DATOS.DEPOSITANTES_CAVAPY to ogd_pentaho;
