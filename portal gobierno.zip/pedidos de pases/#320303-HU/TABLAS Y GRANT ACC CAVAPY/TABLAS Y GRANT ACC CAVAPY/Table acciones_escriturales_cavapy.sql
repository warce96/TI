-- Create table
create table DATOS.ACCIONES_ESCRITURALES_CAVAPY
(
  rut                  NUMBER(15) not null,
  cuenta_titular       NUMBER(15) not null,
  nro_isin             VARCHAR2(20) not null,
  cantidad             FLOAT,
  depositante          VARCHAR2(30),
  estado               VARCHAR2(30),
  prima_emision        FLOAT,
  id_clase_original    CHAR(4),
  usuario              VARCHAR2(3),
  fecha_creacion       DATE default SYSDATE not null,
  fecha_ult_mod        DATE,
  cant_disponible      FLOAT default 0,
  cant_pendiente_canje FLOAT default 0,
  cant_congelado       FLOAT default 0,
  cant_prenda          FLOAT default 0,
  cant_repo            FLOAT default 0,
  cant_no_disponible   FLOAT default 0
)
tablespace DATOS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Add comments to the table 
comment on table DATOS.ACCIONES_ESCRITURALES_CAVAPY
  is 'Registro de posiciones de acciones escriturales en CAVAPY por titular y cuenta';
-- Add comments to the columns 
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.rut
  is 'Identificador unico del titular';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.cuenta_titular
  is 'Numero de cuenta del titular';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.nro_isin
  is 'Codigo ISIN';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.cantidad
  is 'Cantidad total de acciones registradas';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.depositante
  is 'Entidad depositante de las acciones';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.estado
  is 'Estado del registro';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.prima_emision
  is 'Valor de la prima de emision heredada';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.id_clase_original
  is 'Identificador de la clase original';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.usuario
  is 'Usuario que realizo la operacion';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.fecha_creacion
  is 'Fecha de creacion del registro';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.fecha_ult_mod
  is 'Fecha de ultima modificacion del registro';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.cant_disponible
  is 'Cantidad de acciones disponibles para operacion';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.cant_pendiente_canje
  is 'Cantidad de acciones pendientes de canje';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.cant_congelado
  is 'Cantidad de acciones congeladas o bloqueadas';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.cant_prenda
  is 'Cantidad de acciones en prenda';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.cant_repo
  is 'Cantidad de acciones en operaciones de repo';
comment on column DATOS.ACCIONES_ESCRITURALES_CAVAPY.cant_no_disponible
  is 'Cantidad total de acciones no disponibles para operacion';
-- Create/Recreate indexes 
create index DATOS.IDX_ACC_ESC_CAVAPY_01 on DATOS.ACCIONES_ESCRITURALES_CAVAPY (RUT)
  tablespace INDX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
