"""
server.py — ETL Governance Portal (Unificado)
Banco Continental — Gobierno de Datos

Integra:
  - Pentaho Explorer (KTR / KJB / PY)
  - Power BI Validator (.pbix) con historial SQLite
  - Historial de validaciones consultable por fecha / nombre

python server.py → http://localhost:5000
"""

import io, json, os, re, ast as pyast, shutil, sqlite3, tempfile
import traceback, xml.etree.ElementTree as ET, time, zipfile
import subprocess, threading, uuid, textwrap, hashlib, posixpath, tarfile
from datetime import datetime, timedelta
from functools import wraps
from collections import defaultdict
from pathlib import Path
from flask import (Flask, render_template, request, jsonify, abort, send_file,
                    session, redirect, url_for)
from werkzeug.security import generate_password_hash, check_password_hash
import paramiko
import requests
from dotenv import load_dotenv
load_dotenv()  # lee el archivo .env que está junto a server.py, si existe

app  = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024
app.secret_key = os.environ.get("PORTAL_SECRET_KEY", "banco-continental-gobierno-datos-CAMBIAR-EN-PRODUCCION")
BASE = Path(__file__).parent

# ════════════════════════════════════════════════════════
#  AUTENTICACIÓN — login con base de datos (SQLite)
# ════════════════════════════════════════════════════════

def init_auth_db():
    """Crea la tabla de usuarios y siembra un usuario admin si no existe ninguno."""
    with _db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario       TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                nombre        TEXT,
                rol           TEXT DEFAULT 'usuario',
                activo        INTEGER DEFAULT 1,
                creado        TEXT,
                ultimo_login  TEXT
            )
        """)
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(usuarios)").fetchall()}
        if "activo" not in cols:
            conn.execute("ALTER TABLE usuarios ADD COLUMN activo INTEGER DEFAULT 1")
        if "debe_cambiar_password" not in cols:
            conn.execute("ALTER TABLE usuarios ADD COLUMN debe_cambiar_password INTEGER DEFAULT 0")

        conn.execute("""
            CREATE TABLE IF NOT EXISTS usuario_permisos (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id  INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
                pagina      TEXT NOT NULL,
                permitido   INTEGER DEFAULT 0,
                UNIQUE(usuario_id, pagina)
            )
        """)

        total = conn.execute("SELECT COUNT(*) c FROM usuarios").fetchone()["c"]
        if total == 0:
            conn.execute("""
                INSERT INTO usuarios (usuario, password_hash, nombre, rol, activo, creado)
                VALUES (?,?,?,?,1,?)
            """, ("admin", generate_password_hash("CambiarPassword123"),
                  "Administrador", "admin",
                  datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()


# Pantallas disponibles para asignar permisos granulares.
# clave -> (etiqueta visible, prefijos de ruta que cubre)
PAGINAS = {
    "pentaho":   ("Pentaho ETL",        ["/", "/api/tree", "/search", "/open", "/catalog",
                                          "/api/descargar_remoto", "/api/descargar_local"]),
    "powerbi":   ("Power BI",           ["/powerbi", "/api/powerbi"]),
    "etl":       ("Tareas",             ["/etl", "/api/etl"]),
    "crontab":   ("Programación",       ["/crontab", "/api/crontab"]),
    "reporte":   ("Reporte de estados", ["/reporte", "/api/reporte"]),
    "compare":   ("Comparar",           ["/compare"]),
    "python":    ("Python & ML",        ["/python", "/api/python"]),
    "azure":     ("Azure HUs",          ["/azure", "/api/azure"]),
    "deploy":    ("Deploy",             ["/deploy", "/api/deploy"]),
    "auditoria": ("Auditoría",          ["/auditoria", "/api/auditoria"]),
    "usuarios":  ("Usuarios",           ["/usuarios", "/api/usuarios"]),
}

def _resolver_pagina(path):
    """Devuelve la clave de PAGINAS a la que pertenece un path, o None si no está mapeado."""
    mejor, mejor_len = None, -1
    for clave, (_etq, prefijos) in PAGINAS.items():
        for pre in prefijos:
            if path == pre or path.startswith(pre.rstrip("/") + "/") or (pre == "/" and path == "/"):
                if len(pre) > mejor_len:
                    mejor, mejor_len = clave, len(pre)
    return mejor

def _tiene_permiso(usuario_id, pagina):
    with _db() as conn:
        row = conn.execute("""
            SELECT permitido FROM usuario_permisos WHERE usuario_id=? AND pagina=?
        """, (usuario_id, pagina)).fetchone()
    return bool(row and row["permitido"])

def _paginas_permitidas(usuario_id, rol):
    """Set de claves de páginas visibles para un usuario, para armar el menú."""
    if rol == "admin":
        return set(PAGINAS.keys())
    with _db() as conn:
        rows = conn.execute("""
            SELECT pagina FROM usuario_permisos WHERE usuario_id=? AND permitido=1
        """, (usuario_id,)).fetchall()
    return {r["pagina"] for r in rows}

def login_required(f):
    """Decorador: exige sesión iniciada. Redirige a /login si no hay usuario."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("usuario"):
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    """Decorador: exige rol admin. Devuelve 403 si no lo es."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("usuario"):
            return redirect(url_for("login", next=request.path))
        if session.get("rol") != "admin":
            abort(403)
        return f(*args, **kwargs)
    return wrapper

_RUTAS_SIN_CHEQUEO = ("/login", "/logout", "/static", "/usuarios", "/api/usuarios")

@app.before_request
def _chequear_sesion_y_permisos():
    if any(request.path == r or request.path.startswith(r + "/") for r in _RUTAS_SIN_CHEQUEO):
        return None
    if not session.get("usuario"):
        return None  # login_required de cada ruta se encarga de redirigir

    # Si el usuario fue desactivado mientras tenía la sesión abierta, se lo saca.
    with _db() as conn:
        row = conn.execute("SELECT activo FROM usuarios WHERE id=?",
                            (session.get("usuario_id"),)).fetchone()
    if row is not None and not row["activo"]:
        session.clear()
        return redirect(url_for("login"))

    # Contraseña temporal sin cambiar: no se deja avanzar a ninguna otra pantalla
    # hasta que la cambie desde /usuarios (que ya está exceptuada arriba).
    if session.get("debe_cambiar_password"):
        return redirect(url_for("usuarios_home"))

    if session.get("rol") == "admin":
        return None  # el admin ve todo, sin restricciones de pantalla

    pagina = _resolver_pagina(request.path)
    if pagina is None:
        return None  # ruta no mapeada a ninguna pantalla (ej. asset genérico): se permite
    if not _tiene_permiso(session.get("usuario_id"), pagina):
        if request.path.startswith("/api/"):
            return jsonify({"ok": False, "error": "No tenés permiso para acceder a esta sección."}), 403
        return render_template("sin_permiso.html", pagina=PAGINAS.get(pagina, (pagina,))[0]), 403

@app.context_processor
def inject_usuario_actual():
    paginas = set()
    if session.get("usuario"):
        paginas = _paginas_permitidas(session.get("usuario_id"), session.get("rol"))
    return dict(usuario_actual=session.get("usuario"),
                nombre_actual=session.get("nombre"),
                rol_actual=session.get("rol"),
                paginas_permitidas=paginas)

@app.template_filter("fromjson")
def fromjson_filter(s):
    try: return json.loads(s) if s else []
    except: return []

@app.context_processor
def inject_visual_maps():
    return dict(visual_types=VISUAL_TYPES, visual_colors=VISUAL_COLORS)

# ── Config SSH / Pentaho ─────────────────────────────
_H        = "10.1.1.3"
_U        = "sysadmin"
_P        = "a.123456"
_LOG      = "/var/pentaho/logs/REGISTRO_CARGA.log"
_CRONTAB  = "/etc/crontab"
_PROOT    = "/pentaho/project"
LOG_TAIL_LINES = 60000   # límite de líneas al leer el log ETL, para que el portal cargue rápido

LOCAL_PATH        = r"C:\Users\willian.arce\Desktop\pentaho viejo\exe\proceso restante"
ALLOWED_EXT       = (".ktr", ".kjb", ".xml", ".py")
IGNORE_DIRS       = {"logs","backup",".git","__pycache__",".venv","venv"}
MAX_RESULTS       = 200
PREVIEW_MAX_CHARS = 250_000

# ── Config Versionado / Implementar / Bajar (Pentaho PROD) ──────────
# Mismo servidor que ya usás para Hadoop (10.1.1.3). Estas son las carpetas
# RAÍZ dentro de las cuales vas a poder elegir visualmente, desde el portal,
# la subcarpeta exacta donde implementar (no hace falta escribir el path completo acá).
PROD_KTR_PATH = os.environ.get("PENTAHO_PROD_KTR_PATH", "/pentaho/project/")
PROD_JOB_PATH = os.environ.get("PENTAHO_PROD_JOB_PATH", "/pentaho/project/")
PROD_PY_PATH  = os.environ.get("PENTAHO_PROD_PY_PATH",  os.environ.get("PENTAHO_PROD_KTR_PATH", "/pentaho/project/"))

PROD_ROOTS = {"KTR": PROD_KTR_PATH, "JOB": PROD_JOB_PATH, "PY": PROD_PY_PATH}

# Carpeta remota donde se guarda una copia del archivo ORIGINAL que había en
# PROD antes de que "Implementar" lo reemplace, espejando la misma estructura
# de carpetas y con el nombre + tag de la versión que lo reemplazó.
# Ej: /pentaho/project/OGD/Oracle/PROCESOS_1/JOB_PROCESOS_1.kjb ya existente
# se respalda como:
# /pentaho/project/Versionado/OGD/Oracle/PROCESOS_1/JOB_PROCESOS_1_v2.kjb
VERSIONADO_ROOT = os.environ.get("PENTAHO_VERSIONADO_PATH", "/pentaho/project/Versionado")

# Carpeta local donde se guarda cada versión subida desde el portal
# (una copia por versión, para poder diffear contra PROD antes de implementar)
DEPLOY_DIR = BASE / "deploy_versiones"
DEPLOY_DIR.mkdir(exist_ok=True)

# Carpeta local donde caen los archivos "bajados" (descargados) desde PROD
DESCARGAS_DIR = BASE / "descargas_prod"
DESCARGAS_DIR.mkdir(exist_ok=True)

# Carpeta SEPARADA para la documentación (.md) de cada versión — no vive
# junto al .zip/archivo que se implementa, pero se organiza espejando la
# misma estructura tipo/nombre_proceso/version, para encontrarla fácil.
DOCUMENTACION_DIR = BASE / "documentacion_md"
DOCUMENTACION_DIR.mkdir(exist_ok=True)

# Checklist de criterios de aceptación por tipo — deben marcarse 100% antes
# de habilitar "Implementar". Coincide con los criterios de aceptación de la HU.
CHECKLIST_ITEMS = {
    "JOB": [
        ("configurado_probado",   "El job fue configurado y probado en el ambiente correspondiente."),
        ("dia_hora_dependencias", "Se verificó día, hora y dependencias con otros procesos antes de la puesta en marcha."),
        ("alertas_configuradas",  "Se configuraron alertas ante fallo de ejecución."),
        ("catalogo_registrado",   "El job quedó registrado en el catálogo o listado de jobs vigentes."),
        ("md_creado",             "Se creó un .md del job, explicando la necesidad que cubre y el responsable a cargo."),
        ("zip_adjuntado",         "Se adjuntó el entregable en .zip, con carpeta nombrada según el estándar, con script, dependencias y documentación."),
    ],
    "KTR": [
        ("versionado_repo",       "El archivo KTR está versionado en el repositorio correspondiente."),
        ("no_duplicado",          "Se verificó que no existiera ya un KTR equivalente con otro responsable asignado."),
        ("carga_completa_incremental", "Se probó con carga completa y con carga incremental."),
        ("logs_sin_errores",      "Se revisaron los logs de ejecución sin errores pendientes."),
        ("mapeo_columnas",        "El mapeo de columnas entre origen y destino está documentado."),
        ("md_creado",             "Se creó un .md del KTR, explicando la necesidad que cubre y el responsable a cargo."),
        ("zip_adjuntado",         "Se adjuntó el entregable en .zip, con carpeta nombrada según el estándar, con script, dependencias y documentación."),
    ],
    # Alineado con "Pase a Producción — Ciencia de Datos" (estructura mínima +
    # buenas prácticas obligatorias + testeo previo con gate de puntaje).
    "PY": [
        ("estructura_minima",       "El entregable tiene la estructura mínima: script.py, requirements.txt, .md, modelo serializado (si aplica) y tests/."),
        ("sin_credenciales",        "Sin credenciales hardcodeadas: usuario/contraseña/tokens van por variable de entorno."),
        ("manejo_excepciones",      "Manejo de excepciones específico (sin except genérico sin registrar el motivo)."),
        ("logging_no_print",       "Usa logging en vez de print() suelto, para trazabilidad en producción."),
        ("variables_entorno",      "Configuración (rutas, hosts, tablas) por variable de entorno, no hardcodeada."),
        ("testeo_previo",          "Se probó en desarrollo/staging con datos reales, con reproducibilidad verificada."),
        ("puntaje_minimo",         "Alcanzó el puntaje mínimo de 70/100 en el análisis automático del portal (Python & ML)."),
        ("cero_errores",           "Cero errores no controlados en la corrida de prueba."),
        ("md_creado",              "Se creó un .md explicando la necesidad que cubre y el responsable a cargo."),
        ("zip_adjuntado",          "Se adjuntó el entregable en .zip, con carpeta nombrada según el estándar, con script, dependencias y documentación."),
    ],
}

# ── Config Azure DevOps (gate de aprobación Scrum Master / Product Owner) ──
# El PAT se pasa por variable de entorno, NUNCA hardcodeado en el archivo.
#   export AZURE_DEVOPS_ORG="tuorganizacion"
#   export AZURE_DEVOPS_PROJECT="tuproyecto"
#   export AZURE_DEVOPS_PAT="xxxxxxxxxxxxxxxxxxxxx"
AZURE_ORG     = os.environ.get("AZURE_DEVOPS_ORG", "")
AZURE_PROJECT = os.environ.get("AZURE_DEVOPS_PROJECT", "")
AZURE_PAT     = os.environ.get("AZURE_DEVOPS_PAT", "")

# Reference names de los campos personalizados. Los nombres visibles son:
#   "Comentario de Aprobación del Scrum Master"  (grupo/área: Datos)
#   "Autorización del Product Owner"             (grupo/área: Datos)
# El referenceName real (algo tipo "Custom.XXXX") depende de cómo se creó el
# campo en tu proceso de Azure DevOps. Se puede fijar acá una vez identificado
# con /api/azure/discover_fields, o dejarlo en variable de entorno.
AZURE_FIELD_SCRUM = os.environ.get("AZURE_FIELD_SCRUM", "")  # ej: "Custom.ComentarioDeAprobacionDelScrumMasterDatos"
AZURE_FIELD_PO    = os.environ.get("AZURE_FIELD_PO", "")     # ej: "Custom.AutorizacionDelProductOwnerDatos"

# Campos ya identificados en el proceso de Azure DevOps de Gobierno de Datos
# (confirmados directamente desde el volcado de campos de una HU real).
AZURE_FIELD_LIDER_PROYECTO = "Custom.887c504b-751f-4b5d-81cc-42d2d67d446e"
AZURE_FIELD_DESARROLLADOR_HU = "Custom.DesarrolladorHU"          # cuando WorkItemType == "User Story Desarrollo"
AZURE_FIELD_DESARROLLADOR_BUG = "Custom.DesarrolladorAsignado"   # cuando WorkItemType == "Bug"
AZURE_FIELD_ANALISTA_DATOS = "Custom.AnalistaAsignadoDatos"      # cuando WorkItemType == "User Story Datos"
AZURE_FIELD_DESARROLLADOR_OTRO = "Custom.8378a712-6ec9-4f34-aed6-c05b8b09079d"  # Tareas y otros tipos

# ── Reglas Power BI ──────────────────────────────────
REGLAS_DEFAULT = {
    "fuentes_prohibidas":  ["LocalFile","Excel","CSV","Folder","Text/Csv","Csv","Json","Xml","Pdf"],
    "fuentes_permitidas":  ["Oracle","SQL Server","OData","SharePoint","Web","ODBC","AnalysisServices"],
    "tablas_criticas_rls": ["CLIENTES","CREDITOS","OPERACIONES","SCORING","ALERTAS_PLD","TRANSACCIONES"],
    "columnas_sensibles":  ["CEDULA","CI","RUC","TELEFONO","EMAIL","CORREO","SALARIO","SUELDO","INGRESO","PASSWORD"],
    "limite_tablas": 40, "limite_columnas": 400,
    "limite_medidas": 150, "limite_paginas": 20, "max_mb": 200,
}
REGLAS = dict(REGLAS_DEFAULT)
_rp = BASE / "reglas_banco.json"
if _rp.exists():
    try: REGLAS.update(json.loads(_rp.read_text("utf-8")))
    except: pass

VISUAL_TYPES = {
    "barChart":"Barras","clusteredBarChart":"Barras agrupadas",
    "columnChart":"Columnas","clusteredColumnChart":"Columnas agrupadas",
    "stackedBarChart":"Barras apiladas","stackedColumnChart":"Columnas apiladas",
    "hundredPercentStackedBarChart":"Barras 100%","hundredPercentStackedColumnChart":"Columnas 100%",
    "lineChart":"Líneas","areaChart":"Área","stackedAreaChart":"Área apilada",
    "lineClusteredColumnComboChart":"Líneas+Col","ribbonChart":"Ribbon",
    "waterfallChart":"Cascada","scatterChart":"Dispersión",
    "pieChart":"Torta","donutChart":"Dona","treemap":"Mapa árbol",
    "card":"Tarjeta","multiRowCard":"Tarjetas múltiples",
    "tableEx":"Tabla","pivotTable":"Tabla dinámica","matrix":"Matriz",
    "map":"Mapa","filledMap":"Mapa relleno","azureMap":"Azure Map",
    "slicer":"Segmentación","textbox":"Texto","image":"Imagen",
    "shape":"Forma","basicShape":"Forma","actionButton":"Botón",
    "kpi":"KPI","gauge":"Medidor","decompositionTree":"Árbol",
    "group":"Grupo","smartNarrativeVisual":"Narración IA",
}
VISUAL_COLORS = {
    "barChart":"#2563EB","clusteredBarChart":"#2563EB","columnChart":"#2563EB","clusteredColumnChart":"#2563EB",
    "stackedBarChart":"#3B82F6","stackedColumnChart":"#3B82F6",
    "lineChart":"#059669","areaChart":"#059669","stackedAreaChart":"#10B981",
    "lineClusteredColumnComboChart":"#7C3AED","ribbonChart":"#6D28D9",
    "scatterChart":"#EA580C","waterfallChart":"#B45309",
    "pieChart":"#DC2626","donutChart":"#B91C1C","treemap":"#0F766E",
    "card":"#1D4ED8","multiRowCard":"#1D4ED8",
    "tableEx":"#475569","pivotTable":"#475569","matrix":"#334155",
    "map":"#0369A1","filledMap":"#0369A1","azureMap":"#0078D4",
    "slicer":"#7C3AED","textbox":"#94A3B8","image":"#D97706",
    "shape":"#CBD5E1","basicShape":"#CBD5E1","actionButton":"#1E293B",
    "kpi":"#DC2626","gauge":"#D97706","decompositionTree":"#0891B2",
    "group":"#6B7280","smartNarrativeVisual":"#7C3AED",
}
THEME_STD = ["#118DFF","#12239E","#E66C37","#6B007B","#E044A7",
             "#744EC2","#D9B300","#D64550","#197278","#1AAB40"]


# ════════════════════════════════════════════════════════
#  SQLITE — Historial de validaciones
# ════════════════════════════════════════════════════════

DB_PATH = BASE / "historial_pbix.db"

def _db():
    """Conexión SQLite con row_factory para dicts."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Crea las tablas si no existen."""
    with _db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS validaciones (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            archivo     TEXT    NOT NULL,
            fecha       TEXT    NOT NULL,
            timestamp   TEXT    NOT NULL,
            aprobado    INTEGER NOT NULL,
            errores     INTEGER NOT NULL,
            avisos      INTEGER NOT NULL,
            pasaron     INTEGER NOT NULL,
            total       INTEGER NOT NULL,
            mb          REAL,
            n_paginas   INTEGER,
            n_medidas   INTEGER,
            n_tablas    INTEGER,
            n_columnas  INTEGER,
            tema_nombre TEXT,
            tema_colores TEXT,
            tiene_rls   INTEGER,
            detalle_json TEXT
        );

        CREATE TABLE IF NOT EXISTS validacion_reglas (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            validacion_id   INTEGER NOT NULL REFERENCES validaciones(id) ON DELETE CASCADE,
            categoria       TEXT,
            regla           TEXT,
            estado          TEXT,
            mensaje         TEXT,
            detalle         TEXT,
            severidad       TEXT
        );

        CREATE TABLE IF NOT EXISTS validacion_paginas (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            validacion_id   INTEGER NOT NULL REFERENCES validaciones(id) ON DELETE CASCADE,
            nombre          TEXT,
            oculta          INTEGER,
            n_visuales      INTEGER,
            canvas_w        INTEGER,
            canvas_h        INTEGER,
            tipos_visuales  TEXT
        );

        CREATE TABLE IF NOT EXISTS validacion_medidas (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            validacion_id   INTEGER NOT NULL REFERENCES validaciones(id) ON DELETE CASCADE,
            tabla           TEXT,
            nombre          TEXT,
            expresion       TEXT,
            tiene_var       INTEGER,
            tiene_divide    INTEGER,
            expr_larga      INTEGER
        );

        CREATE TABLE IF NOT EXISTS deploy_versiones (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            tipo            TEXT NOT NULL,               -- 'KTR', 'JOB' o 'PY'
            nombre_proceso  TEXT NOT NULL,
            id_hu           TEXT,
            version         INTEGER NOT NULL,
            version_tag     TEXT,                        -- etiqueta visible: 'v3' por defecto, o la que edite el usuario
            archivo_nombre  TEXT NOT NULL,
            ruta_local      TEXT NOT NULL,
            destino_dir     TEXT,                         -- carpeta PROD elegida visualmente (absoluta)
            hash_sha256     TEXT,
            responsable     TEXT,
            fecha           TEXT NOT NULL,
            timestamp       TEXT NOT NULL,
            estado          TEXT DEFAULT 'borrador',     -- borrador | listo_prod | en_prod
            ruta_prod       TEXT,
            ruta_respaldo_original TEXT,                 -- dónde quedó el archivo que había ANTES en PROD, si había
            ruta_documentacion TEXT,                     -- ruta local del .md, aparte del entregable
            lider_proyecto  TEXT,                        -- guardado al momento de crear la version, desde Azure DevOps
            analista_asignado TEXT,
            fecha_implementacion TEXT
        );

        CREATE TABLE IF NOT EXISTS deploy_checklist (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            version_id      INTEGER NOT NULL REFERENCES deploy_versiones(id) ON DELETE CASCADE,
            criterio        TEXT NOT NULL,
            cumplido        INTEGER DEFAULT 0,
            marcado_por     TEXT,
            fecha           TEXT
        );

        CREATE TABLE IF NOT EXISTS deploy_historial_acciones (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            version_id      INTEGER NOT NULL REFERENCES deploy_versiones(id) ON DELETE CASCADE,
            accion          TEXT NOT NULL,   -- implementar | bajar
            usuario         TEXT,
            fecha           TEXT NOT NULL,
            resultado       TEXT,            -- ok | error
            detalle         TEXT,
            nota_manual     TEXT             -- comentario editable a mano, aparte del detalle automático
        );
        """)

def _migrar_columnas_deploy():
    """Agrega columnas nuevas a deploy_versiones si el .db ya existía sin ellas."""
    with _db() as conn:
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(deploy_versiones)").fetchall()}
        if "destino_dir" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN destino_dir TEXT")
        if "version_tag" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN version_tag TEXT")
        if "ruta_respaldo_original" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN ruta_respaldo_original TEXT")
        if "ruta_documentacion" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN ruta_documentacion TEXT")
        if "lider_proyecto" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN lider_proyecto TEXT")
        if "analista_asignado" not in cols:
            conn.execute("ALTER TABLE deploy_versiones ADD COLUMN analista_asignado TEXT")

        cols_acciones = {r["name"] for r in conn.execute("PRAGMA table_info(deploy_historial_acciones)").fetchall()}
        if "nota_manual" not in cols_acciones:
            conn.execute("ALTER TABLE deploy_historial_acciones ADD COLUMN nota_manual TEXT")
        conn.commit()

init_db()
_migrar_columnas_deploy()
init_auth_db()


def guardar_validacion(data: dict) -> int:
    """
    Persiste el resultado completo de una validación en SQLite.
    Retorna el id insertado.
    """
    ts   = data.get("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    fecha = ts[:10]

    # Métricas resumidas desde detalle_json
    colors = data.get("colors", {})
    pages  = data.get("pages",  [])

    # Detectar métricas desde categorías de resultados
    n_paginas  = len(pages)
    n_medidas  = 0
    n_tablas   = 0
    n_columnas = 0
    mb_val     = 0.0
    tiene_rls  = 0

    for r in data.get("resultados", []):
        msg = r.get("msg", "")
        if "Medidas:" in msg:
            try: n_medidas  = int(re.search(r"Medidas:\s*(\d+)", msg).group(1))
            except: pass
        if "Tablas:" in msg:
            try: n_tablas   = int(re.search(r"Tablas:\s*(\d+)",   msg).group(1))
            except: pass
        if "Columnas:" in msg:
            try: n_columnas = int(re.search(r"Columnas:\s*(\d+)", msg).group(1))
            except: pass
        if "Tamaño:" in msg:
            try: mb_val     = float(re.search(r"Tamaño:\s*([\d.]+)", msg).group(1))
            except: pass
        if "RLS configurado" in msg:
            tiene_rls = 1

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO validaciones
            (archivo, fecha, timestamp, aprobado, errores, avisos, pasaron, total,
             mb, n_paginas, n_medidas, n_tablas, n_columnas,
             tema_nombre, tema_colores, tiene_rls, detalle_json)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            data.get("archivo",""),
            fecha, ts,
            int(data.get("aprobado", False)),
            data.get("errores", 0),
            data.get("avisos",  0),
            data.get("pasaron", 0),
            data.get("total",   0),
            mb_val, n_paginas, n_medidas, n_tablas, n_columnas,
            colors.get("nombre",""),
            json.dumps(colors.get("colores", [])),
            tiene_rls,
            json.dumps(data, ensure_ascii=False),
        ))
        vid = cur.lastrowid

        # Guardar reglas detalle
        for r in data.get("resultados", []):
            conn.execute("""
                INSERT INTO validacion_reglas
                (validacion_id, categoria, regla, estado, mensaje, detalle, severidad)
                VALUES (?,?,?,?,?,?,?)
            """, (vid, r.get("cat",""), r.get("regla",""), r.get("estado",""),
                  r.get("msg",""), r.get("det",""), r.get("sev","")))

        # Guardar páginas
        for p in pages:
            tipos = json.dumps([v["type"] for v in p.get("visuals",[])])
            conn.execute("""
                INSERT INTO validacion_paginas
                (validacion_id, nombre, oculta, n_visuales, canvas_w, canvas_h, tipos_visuales)
                VALUES (?,?,?,?,?,?,?)
            """, (vid, p.get("name",""), int(p.get("hidden",False)),
                  p.get("n",0), p.get("cw",1280), p.get("ch",720), tipos))

        conn.commit()
    return vid


# ════════════════════════════════════════════════════════
#  SSH — Pentaho helpers
# ════════════════════════════════════════════════════════

def _ssh():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(_H, username=_U, password=_P, timeout=10)
    return c

def _run(cmd):
    try:
        ssh    = _ssh()
        escaped = cmd.replace('"', '\\"')
        full    = f'sudo -S -p "" bash -c "{escaped}"'
        stdin, stdout, stderr = ssh.exec_command(full, timeout=30)
        stdin.write(_P + "\n"); stdin.flush()
        out = stdout.read().decode("utf-8", errors="replace")
        ssh.close()
        lines = [l for l in out.splitlines()
                 if not l.startswith("[sudo]") and "password for" not in l.lower()]
        return "\n".join(lines), True
    except Exception as e:
        app.logger.error("SSH error: %s", e)
        return "", False

def _read_file(path, tail=None):
    cmd = f"tail -n {tail} {path}" if tail else f"cat {path}"
    return _run(cmd)

def _read_content(path):
    out, ok = _run(f"cat {path}")
    return out[:PREVIEW_MAX_CHARS] if (ok and out) else ""

def _sftp_put(local_path, remote_path):
    """
    Sube un archivo local al servidor Pentaho (para 'Implementar').
    El usuario SFTP (sysadmin) puede no tener permiso de escritura directo en
    la carpeta final de PROD (por eso el resto del portal usa sudo vía _run()).
    Como SFTP no pasa por sudo, subimos primero a un staging en /tmp (donde sí
    se puede escribir sin privilegios) y de ahí lo movemos con sudo.
    """
    staging = f"/tmp/deploy_stage_{uuid.uuid4().hex}"
    ssh = _ssh()
    try:
        sftp = ssh.open_sftp()
        sftp.put(str(local_path), staging)
        sftp.close()
    except Exception as e:
        app.logger.error("SFTP put (staging) error: %s", e)
        return False, f"No se pudo subir a la carpeta temporal: {e}"
    finally:
        ssh.close()

    remote_dir = posixpath.dirname(remote_path)
    cmd = f'mkdir -p "{remote_dir}" && mv "{staging}" "{remote_path}" && chmod 664 "{remote_path}"'
    out, ok = _run(cmd)
    if not ok:
        return False, f"Fallo moviendo el archivo a destino final (sudo mv): {out or 'sin detalle'}"
    return True, ""

def _sftp_get(remote_path, local_path):
    """
    Descarga un archivo del servidor Pentaho hacia una ruta local (para 'Bajar').
    Igual que en _sftp_put: el archivo real puede no ser legible directamente
    por el usuario SFTP, así que primero lo copiamos con sudo a un staging en
    /tmp con permisos abiertos, y de ahí sí lo bajamos por SFTP normal.
    """
    staging = f"/tmp/deploy_stage_{uuid.uuid4().hex}"
    out, ok = _run(f'cp "{remote_path}" "{staging}" && chmod 644 "{staging}"')
    if not ok:
        return False, f"Fallo preparando el archivo para descarga (sudo cp): {out or 'sin detalle'}"

    ssh = _ssh()
    try:
        sftp = ssh.open_sftp()
        sftp.get(staging, str(local_path))
        sftp.close()
        return True, ""
    except Exception as e:
        app.logger.error("SFTP get error: %s", e)
        return False, str(e)
    finally:
        ssh.close()
        _run(f'rm -f "{staging}"')

def _respaldar_original_si_existe(remote_path, tipo, version_tag):
    """
    Antes de reemplazar un archivo en PROD, si ya había uno con ese mismo
    nombre (subido por este portal o no), lo copia a la carpeta 'Versionado',
    espejando la misma estructura de carpetas relativa a la raíz del tipo,
    y renombrado con el tag de la versión que lo está reemplazando.
    Ej: .../OGD/Oracle/PROCESOS_1/JOB_PROCESOS_1.kjb
        -> Versionado/OGD/Oracle/PROCESOS_1/JOB_PROCESOS_1_v2.kjb
    Devuelve (ok, ruta_respaldo_o_None, error_o_None).
    """
    out, ok = _run(f'test -f "{remote_path}" && echo EXISTE || echo NOEXISTE')
    if not ok:
        return False, None, f"No se pudo verificar si ya existía un archivo en destino: {out}"
    if "EXISTE" not in out or "NOEXISTE" in out:
        return True, None, None  # no había nada que respaldar, se puede seguir

    root = PROD_ROOTS.get(tipo, "/pentaho/project/").rstrip("/")
    carpeta_remota = posixpath.dirname(remote_path)
    rel_dir = carpeta_remota[len(root):].strip("/") if carpeta_remota.startswith(root) else carpeta_remota.strip("/")

    nombre = posixpath.basename(remote_path)
    base, ext = posixpath.splitext(nombre)
    nombre_respaldo = f"{base}_{version_tag}{ext}"

    carpeta_respaldo = posixpath.join(VERSIONADO_ROOT, rel_dir) if rel_dir else VERSIONADO_ROOT
    ruta_respaldo = posixpath.join(carpeta_respaldo, nombre_respaldo)

    out2, ok2 = _run(f'mkdir -p "{carpeta_respaldo}" && cp -p "{remote_path}" "{ruta_respaldo}"')
    if not ok2:
        return False, None, f"No se pudo respaldar el archivo original antes de reemplazarlo: {out2 or 'sin detalle'}"
    return True, ruta_respaldo, None


def _file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# ════════════════════════════════════════════════════════
#  Árbol de carpetas
# ════════════════════════════════════════════════════════

def _tree_from_paths(paths, base):
    root_node  = {"name": os.path.basename(base), "type": "folder",
                  "path": base, "children": []}
    folder_map = {base: root_node}
    for fpath in sorted(paths):
        rel   = fpath.replace(base,"").lstrip("/")
        parts = rel.split("/")
        cur   = base; node = root_node
        for part in parts[:-1]:
            nxt = cur.rstrip("/") + "/" + part
            if nxt not in folder_map:
                f = {"name":part,"type":"folder","path":nxt,"children":[]}
                node["children"].append(f); folder_map[nxt] = f
            node = folder_map[nxt]; cur = nxt
        node["children"].append({"name":parts[-1],"type":"file","path":fpath,"remote":True})
    return root_node

def get_tree():
    cmd = (f'find {_PROOT} -type f '
           r'\( -name "*.ktr" -o -name "*.kjb" -o -name "*.py" \) '
           '2>/dev/null | sort')
    out, ok = _run(cmd)
    if not ok or not out.strip():
        return {"name":"project","type":"folder","path":_PROOT,"children":[]}
    paths = [p.strip() for p in out.splitlines() if p.strip()]
    return _tree_from_paths(paths, _PROOT)


# ════════════════════════════════════════════════════════
#  Búsqueda
# ════════════════════════════════════════════════════════

def search_ssh(text, types=None):
    text  = (text or "").strip()
    if len(text) < 2: return []
    types = [t.lower().strip(".") for t in (types or ["ktr","kjb","py"]) if t]
    name_f = " -o ".join(f'-name "*.{t}"' for t in types)
    safe   = text.replace('"','').replace("'","").replace("\\","")
    cmd    = (f'find {_PROOT} -type f \\( {name_f} \\) '
              f'-exec grep -liI -- "{safe}" {{}} \\; 2>/dev/null | head -{MAX_RESULTS}')
    out, ok = _run(cmd)
    if not ok or not out.strip(): return []
    results = []
    for fp in out.splitlines():
        fp = fp.strip()
        if not fp: continue
        fname  = os.path.basename(fp)
        folder = os.path.dirname(fp).replace(_PROOT,"").lstrip("/") or "."
        ext    = fname.rsplit(".",1)[-1].lower() if "." in fname else ""
        results.append({"archivo":fname,"ruta":folder,"path":fp,"tipo":ext,"remote":True})
    return results

def search_local(text, types=None):
    text  = (text or "").lower()
    types = [t.lower().strip(".") for t in (types or []) if t]
    out   = []
    if not os.path.isdir(LOCAL_PATH): return out
    for root, dirs, files in os.walk(LOCAL_PATH):
        dirs[:] = [d for d in dirs if d.lower() not in IGNORE_DIRS]
        for f in files:
            if not f.lower().endswith(ALLOWED_EXT): continue
            ext = f.lower().rsplit(".",1)[-1]
            if types and ext not in types: continue
            full = os.path.join(root, f)
            try:
                with open(full, encoding="utf8", errors="ignore") as fh:
                    if text in f.lower() or text in fh.read(65536).lower():
                        out.append({"archivo":f,
                                    "ruta":root.replace(LOCAL_PATH,"").lstrip("\\/") or ".",
                                    "path":full,"tipo":ext,"remote":False})
                        if len(out) >= MAX_RESULTS: return out
            except: pass
    return out


# ════════════════════════════════════════════════════════
#  Parseo ETL
# ════════════════════════════════════════════════════════

def _tables(sql):
    if not sql: return []
    tables = set()
    for pat in [r'\bfrom\s+([\w\.\"]+)', r'\bjoin\s+([\w\.\"]+)',
                r'\binto\s+([\w\.\"]+)', r'\bupdate\s+([\w\.\"]+)',
                r'\btruncate\s+table\s+([\w\.\"]+)',
                r'\bdelete\s+from\s+([\w\.\"]+)',
                r'\bmerge\s+into\s+([\w\.\"]+)']:
        for t in re.findall(pat, sql, re.IGNORECASE):
            t = t.replace('"','').strip()
            if t and re.search("[a-zA-Z]", t): tables.add(t)
    return sorted(tables)

def _cat(st):
    t = (st or "").lower()
    if "input"  in t: return "SOURCE"
    if "output" in t or "insert" in t or "update" in t: return "TARGET"
    if "join"   in t or "merge"  in t: return "JOIN"
    if "sort"   in t or "select" in t: return "TRANSFORM"
    return "PROCESS"

def _parse_ktr(root):
    steps, sources, targets, sqls = [], set(), set(), []
    for i, s in enumerate(root.iter("step"), 1):
        name  = s.findtext("name","-")
        stype = s.findtext("type","-")
        sql   = (s.findtext("sql") or s.findtext("lookup/sql")
                 or s.findtext("statement") or "").strip()
        dest  = (s.findtext("table") or s.findtext("tablename")
                 or s.findtext("lookup/table") or "-")
        tbls  = _tables(sql)
        for t in tbls: sources.add(t)
        if stype.lower() in {"insertupdate","tableoutput","delete","update",
                              "synchronizeaftermerge"} and dest != "-":
            targets.add(dest)
        if sql: sqls.append({"step":name,"sql":sql})
        steps.append({"nro":i,"step":name,"tipo":stype,
                      "origen":", ".join(tbls) or "-","destino":dest,
                      "categoria":_cat(stype),"sql":sql})
    n = len(steps)
    return {"steps":steps,"sql_blocks":sqls,
            "sources":sorted(sources),"targets":sorted(targets),"dependencies":[],
            "summary":{"total_steps":n,"sources":len(sources),"targets":len(targets),
                       "joins":0,"complexity":"HIGH" if n>12 else "MEDIUM" if n>5 else "LOW"}}

def _parse_kjb(root):
    entries, deps = [], []
    for i, e in enumerate(root.iter("entry"), 1):
        fn = e.findtext("filename","-")
        entries.append({"nro":i,"step":e.findtext("name","-"),
                        "tipo":e.findtext("type","-"),"origen":fn,
                        "destino":"-","categoria":"JOB","sql":""})
        if fn != "-": deps.append(fn)
    n = len(entries)
    return {"steps":entries,"sql_blocks":[],"sources":[],"targets":[],"dependencies":deps,
            "summary":{"total_steps":n,"sources":0,"targets":0,"joins":0,
                       "complexity":"HIGH" if n>12 else "MEDIUM" if n>5 else "LOW"}}

def _parse_py(path):
    data = {"functions":[],"classes":[],"imports":[],"rows":[],
            "sql_blocks":[],"sources":[],"targets":[],"dependencies":[],
            "summary":{"total_steps":0,"sources":0,"targets":0,"joins":0,"complexity":"LOW"}}
    try:
        with open(path, encoding="utf8", errors="ignore") as f: src = f.read()
        tree = pyast.parse(src)
        imp, fn, cl = set(), set(), set()
        for node in pyast.walk(tree):
            if   isinstance(node, pyast.Import):      [imp.add(n.name) for n in node.names]
            elif isinstance(node, pyast.ImportFrom):  imp.add(node.module or "")
            elif isinstance(node, (pyast.FunctionDef, pyast.AsyncFunctionDef)): fn.add(node.name)
            elif isinstance(node, pyast.ClassDef):    cl.add(node.name)
        imp = sorted(imp); fn = sorted(fn); cl = sorted(cl)
        rows = ([{"nro":i+1,"step":c,"tipo":"Class","origen":"-","destino":"-","categoria":"PROCESS","sql":""}
                 for i,c in enumerate(cl)] +
                [{"nro":len(cl)+i+1,"step":f,"tipo":"Function","origen":"-","destino":"-","categoria":"PROCESS","sql":""}
                 for i,f in enumerate(fn)])
        n = len(rows)
        data.update({"imports":imp,"functions":fn,"classes":cl,"rows":rows,
                     "summary":{"total_steps":n,"sources":len(imp),"targets":len(fn),
                                "joins":len(cl),"complexity":"HIGH" if n>20 else "MEDIUM" if n>8 else "LOW"}})
    except Exception as e:
        app.logger.error("parse_py: %s", e)
    return data

def parse_file(path, is_remote=False):
    ext   = os.path.splitext(path)[1].lower()
    empty = {"steps":[],"rows":[],"sql_blocks":[],"sources":[],"targets":[],
             "dependencies":[],"functions":[],"classes":[],"imports":[],
             "summary":{"total_steps":0,"sources":0,"targets":0,"joins":0,"complexity":"LOW"}}
    content = ""
    if is_remote:
        content = _read_content(path)
        if not content: return empty, ""
        if ext in (".ktr",".kjb"):
            try:
                root   = ET.fromstring(content)
                parsed = _parse_ktr(root) if ext==".ktr" else _parse_kjb(root)
                parsed["rows"] = parsed["steps"]
                parsed.setdefault("functions",[]); parsed.setdefault("classes",[]); parsed.setdefault("imports",[])
                return parsed, content
            except Exception as e:
                app.logger.error("XML remote parse: %s", e); return empty, content
        elif ext == ".py":
            with tempfile.NamedTemporaryFile(mode="w",suffix=".py",delete=False,encoding="utf8") as tmp:
                tmp.write(content); tp = tmp.name
            d = _parse_py(tp); os.unlink(tp); d["rows"] = d.get("rows",[]); return d, content
    else:
        if not os.path.exists(path): return empty, ""
        with open(path, encoding="utf8", errors="ignore") as f:
            content = f.read(PREVIEW_MAX_CHARS)
        if ext in (".ktr",".kjb"):
            try:
                root   = ET.parse(path).getroot()
                parsed = _parse_ktr(root) if ext==".ktr" else _parse_kjb(root)
                parsed["rows"] = parsed["steps"]
                parsed.setdefault("functions",[]); parsed.setdefault("classes",[]); parsed.setdefault("imports",[])
                return parsed, content
            except Exception as e:
                app.logger.error("XML local parse: %s", e); return empty, content
        elif ext == ".py":
            d = _parse_py(path); d["rows"] = d.get("rows",[]); return d, content
    return empty, content


# ════════════════════════════════════════════════════════
#  Comparador
# ════════════════════════════════════════════════════════

def _ext_diff(xml_str, ext):
    base = {"steps":[],"sources":[],"targets":[],"connections":[],"sql_blocks":[]}
    if not xml_str: return base
    try:
        root = ET.fromstring(xml_str)
        if ext == ".ktr":
            p = _parse_ktr(root)
            base.update({"steps":[s["step"] for s in p["steps"]],
                         "sources":p["sources"],"targets":p["targets"],
                         "sql_blocks":p["sql_blocks"]})
        else:
            p = _parse_kjb(root); base["steps"] = [s["step"] for s in p["steps"]]
        for c in root.iter("connection"):
            n = c.findtext("name","").strip(); t = c.findtext("type","").strip()
            if n: base["connections"].append(f"{n} [{t}]" if t else n)
    except Exception as e:
        app.logger.error("ext_diff: %s", e)
    return base

def _diff(a, b):
    sa, sb = set(a), set(b)
    return {"solo_servidor":sorted(sa-sb),"solo_local":sorted(sb-sa),
            "comunes":sorted(sa&sb),"total_srv":len(sa),"total_loc":len(sb)}

def _diff_sql(sa, sb):
    ma={s["step"]:s["sql"] for s in sa}; mb={s["step"]:s["sql"] for s in sb}
    ss, sl, df, eq = [], [], [], []
    for step in sorted(set(ma)|set(mb)):
        if   step in ma and step not in mb: ss.append({"step":step,"sql":ma[step]})
        elif step in mb and step not in ma: sl.append({"step":step,"sql":mb[step]})
        else:
            if " ".join(ma[step].split()).lower() != " ".join(mb[step].split()).lower():
                df.append({"step":step,"sql_a":ma[step],"sql_b":mb[step]})
            else: eq.append(step)
    return {"solo_servidor":ss,"solo_local":sl,"diferentes":df,"iguales":eq}


# ════════════════════════════════════════════════════════
#  Crontab
# ════════════════════════════════════════════════════════

def _cron_text(s):
    p = s.split()
    if len(p) != 5: return s
    m, h, d, mo, wd = p
    dias = {"0":"Dom","1":"Lun","2":"Mar","3":"Mié","4":"Jue","5":"Vie","6":"Sáb","7":"Dom"}
    if s == "* * * * *":    return "Cada minuto"
    if m.startswith("*/"):  return f"Cada {m[2:]} minutos"
    if h.startswith("*/"):  return f"Cada {h[2:]} horas"
    if wd == "*" and m.isdigit() and h.isdigit():
        return f"Todos los días {h.zfill(2)}:{m.zfill(2)}"
    if wd.isdigit():        return f"{dias.get(wd,wd)} {h.zfill(2)}:{m.zfill(2)}"
    return s


# ════════════════════════════════════════════════════════
#  Power BI — Extracción de páginas y colores
# ════════════════════════════════════════════════════════

def _jparse(val):
    if isinstance(val, dict): return val
    if isinstance(val, str):
        s = val.strip()
        if s.startswith("{") or s.startswith("["):
            try: return json.loads(s)
            except: pass
    return {}

def _f(v, d=0.0):
    try: return float(v) if v is not None else d
    except: return d

def _read_zip_component(z, name):
    if name not in z.namelist(): return None
    try:
        raw = z.read(name)
        for enc in ("utf-8-sig","utf-16","utf-8","latin-1"):
            try: return json.loads(raw.decode(enc))
            except: pass
    except: pass
    return None

def extraer_paginas(lay):
    if not lay: return []
    pages = []
    for sec in lay.get("sections", []):
        name   = (sec.get("displayName") or sec.get("name") or "Página").strip()
        hidden = sec.get("displayOption", 0) == 1
        cfg = _jparse(sec.get("config",""))
        try:    cw = max(200, int(cfg.get("defaultViewportWidth")  or 1280))
        except: cw = 1280
        try:    ch = max(200, int(cfg.get("defaultViewportHeight") or 720))
        except: ch = 720
        visuals = []
        for vc in (sec.get("visualContainers") or []):
            x = vc.get("x"); y = vc.get("y")
            w = vc.get("width"); h = vc.get("height")
            pos = vc.get("position")
            if isinstance(pos, dict):
                if x is None: x = pos.get("x")
                if y is None: y = pos.get("y")
                if w is None: w = pos.get("width")
                if h is None: h = pos.get("height")
            x = _f(x); y = _f(y)
            w = max(8.0, _f(w,120)); h = max(8.0, _f(h,80))
            vc_cfg = _jparse(vc.get("config",""))
            vtype  = ""
            sv = vc_cfg.get("singleVisual") or {}
            if sv: vtype = sv.get("visualType","")
            if not vtype and "singleVisualGroup" in vc_cfg: vtype = "group"
            if not vtype:
                raw_cfg = vc.get("config","")
                if isinstance(raw_cfg, str):
                    m = re.search(r'"visualType"\s*:\s*"([^"]+)"', raw_cfg)
                    if m: vtype = m.group(1)
            label = VISUAL_TYPES.get(vtype, vtype or "Visual")
            color = VISUAL_COLORS.get(vtype, "#94A3B8")
            visuals.append({"x":round(x,1),"y":round(y,1),"w":round(w,1),"h":round(h,1),
                            "type":vtype,"label":label,"color":color})
        visuals.sort(key=lambda v: (v["y"], v["x"]))
        pages.append({"name":name,"hidden":hidden,"cw":cw,"ch":ch,
                      "visuals":visuals,"n":len(visuals)})
    return pages

def extraer_colores(lay, z=None):
    out = {"nombre":"Sin tema","colores":[],"es_standard":False}
    if not lay: return out
    colores = []; nombre = ""
    try:
        raw_cfg = lay.get("config",""); cfg = _jparse(raw_cfg)
        tc = cfg.get("themeCollection") or {}
        if isinstance(tc, str): tc = _jparse(tc)
        theme = tc.get("theme") or tc or {}
        if isinstance(theme, str): theme = _jparse(theme)
        nombre = theme.get("name","") or cfg.get("themeName","")
        for key in ("dataColors","colors","foregroundColors","backgroundColors","colorPalette","palette","seriesColors"):
            v = theme.get(key)
            if isinstance(v, list):
                cands = [c for c in v if isinstance(c,str) and re.match(r'^#[0-9A-Fa-f]{6}$',c.strip())]
                if cands: colores = cands; break
        if not colores:
            for key in ("theme","activeTheme","reportTheme"):
                sub = cfg.get(key)
                if isinstance(sub, str): sub = _jparse(sub)
                if isinstance(sub, dict):
                    if not nombre: nombre = sub.get("name","")
                    for ck in ("dataColors","colors","palette"):
                        v = sub.get(ck)
                        if isinstance(v, list):
                            cands = [c for c in v if isinstance(c,str) and re.match(r'^#[0-9A-Fa-f]{6}$',c.strip())]
                            if cands: colores = cands; break
                    if colores: break
        if not colores and isinstance(raw_cfg, str):
            m = re.search(r'"(?:dataColors|colors|palette)"\s*:\s*\[([^\]]+)\]', raw_cfg)
            if m:
                cands = re.findall(r'#[0-9A-Fa-f]{6}', m.group(1))
                if cands: colores = cands
        if not colores:
            vis_colors = set()
            for sec in lay.get("sections",[])[:3]:
                for vc in (sec.get("visualContainers") or [])[:20]:
                    vc_str = vc.get("config","")
                    if isinstance(vc_str, str):
                        hexs = re.findall(r'"#([0-9A-Fa-f]{6})"', vc_str)
                        for h in hexs:
                            c = "#" + h.upper()
                            if c not in ("#FFFFFF","#000000","#FFFFFFFF"): vis_colors.add(c)
            if vis_colors: colores = sorted(vis_colors)[:12]
        if not colores:
            all_hex = re.findall(r'#[0-9A-Fa-f]{6}', json.dumps(lay))
            freq = {}
            for h in all_hex:
                h = h.upper()
                if h not in ("#FFFFFF","#000000","#FAFAFA","#F8F8F8","#EEEEEE"):
                    freq[h] = freq.get(h,0)+1
            colores = [c for c,_ in sorted(freq.items(),key=lambda x:-x[1])[:12]]
    except: pass
    seen = set(); uniq = []
    for c in colores:
        cu = c.upper()
        if cu not in seen: seen.add(cu); uniq.append(cu)
    colores = uniq[:12]
    return {"nombre":nombre or "Tema del reporte","colores":colores,
            "es_standard":colores[:len(THEME_STD)]==THEME_STD if colores else False}


# ════════════════════════════════════════════════════════
#  Power BI — Validación
# ════════════════════════════════════════════════════════

def validar_pbix(ruta):
    res = []
    def ok(cat,r,m,d=""): res.append({"cat":cat,"regla":r,"estado":"OK",  "msg":m,"det":d,"sev":"INFO"})
    def wn(cat,r,m,d=""): res.append({"cat":cat,"regla":r,"estado":"AVISO","msg":m,"det":d,"sev":"AVISO"})
    def er(cat,r,m,d=""): res.append({"cat":cat,"regla":r,"estado":"ERROR","msg":m,"det":d,"sev":"ERROR"})

    mb  = os.path.getsize(ruta)/1024/1024
    lim = REGLAS["max_mb"]
    (wn if mb>lim else ok)("Estructura","ESTR-01",f"Tamaño: {mb:.1f} MB (límite {lim} MB)")

    try: z = zipfile.ZipFile(ruta,"r")
    except:
        er("Estructura","ESTR-02","Archivo corrupto o no es ZIP válido")
        return _build_pbix(res,[],{},{})

    ok("Estructura","ESTR-02","Formato ZIP válido")
    comps = z.namelist()

    for c in ["DataModel","Report/Layout","Connections"]:
        (ok if c in comps else wn)("Estructura","ESTR-03",
            f"Componente {'presente' if c in comps else 'no encontrado'}: {c}")

    cd = _read_zip_component(z,"Connections")
    if cd is None:
        wn("Conexiones","CONN-01","No se pudo leer Connections")
    else:
        conns = cd.get("Connections",[])
        proh  = [f.lower() for f in REGLAS["fuentes_prohibidas"]]
        tipos = []
        for c in conns:
            kind = c.get("ConnectionType",c.get("Kind",""))
            path = c.get("ConnectionString",c.get("Path",""))
            tipos.append(kind)
            if any(p in kind.lower() for p in proh):
                er("Conexiones","CONN-02",f"Fuente prohibida: {kind}",path[:80])
            elif path and re.search(r"^[A-Za-z]:\\|\.xlsx?$|\.csv$|\.txt$",path,re.I):
                er("Conexiones","CONN-03",f"Ruta local: {path[:80]}")
            else:
                ok("Conexiones","CONN-04",f"Conexión OK: {kind}")
        ok("Conexiones","CONN-05",f"{len(conns)} conexión(es)",", ".join(sorted(set(tipos))))

    lay = _read_zip_component(z,"Report/Layout")
    if lay is None:
        wn("Layout","LAY-01","No se pudo leer Report/Layout")
    else:
        secs = lay.get("sections",[])
        n    = len(secs); lp = REGLAS["limite_paginas"]
        (wn if n>lp else ok)("Layout","LAY-02",f"Páginas: {n} (límite {lp})")
        gen = ["page","página","sheet","hoja","tab","pestaña"]
        for s in secs:
            nm = s.get("displayName",s.get("name",""))
            if any(nm.lower().startswith(g) for g in gen):
                wn("Layout","LAY-03",f"Nombre genérico: '{nm}'")
        occ = [s.get("displayName","") for s in secs if s.get("displayOption",0)==1]
        (wn if occ else ok)("Layout","LAY-04",
            f"Páginas ocultas: {len(occ)}" if occ else "Sin páginas ocultas",", ".join(occ))
        for s in secs:
            vis = len(s.get("visualContainers",[]))
            if vis > 30:
                wn("Layout","LAY-05",f"'{s.get('displayName','')}': {vis} visuales (máx recomendado 30)")

    # DAX schema — guardamos medidas para SQLite también
    schema    = _read_zip_component(z,"DataModelSchema")
    medidas_d = []   # para guardar en SQLite

    if schema is None:
        wn("Medidas DAX","DAX-01","DataModelSchema no disponible")
    else:
        tabs = schema.get("model",{}).get("tables",[])
        nt = len(tabs); nc = sum(len(t.get("columns",[])) for t in tabs)
        nm = sum(len(t.get("measures",[])) for t in tabs)
        for obj,val,lk in [("Tablas",nt,"limite_tablas"),
                            ("Columnas",nc,"limite_columnas"),
                            ("Medidas",nm,"limite_medidas")]:
            lv = REGLAS[lk]
            (wn if val>lv else ok)("Medidas DAX","DAX-02",f"{obj}: {val} (límite {lv})")
        for t in tabs:
            for m in t.get("measures",[]):
                expr = m.get("expression",""); nm2 = m.get("name","")
                tiene_var    = "VAR " in expr.upper()
                tiene_divide = "DIVIDE(" in expr.upper()
                expr_larga   = len(expr) > 200
                medidas_d.append({
                    "tabla":t.get("name",""), "nombre":nm2, "expresion":expr,
                    "tiene_var":tiene_var, "tiene_divide":tiene_divide,
                    "expr_larga":expr_larga,
                })
                if "/" in expr and not tiene_divide:
                    wn("Medidas DAX","DAX-10",f"'{nm2}': división sin DIVIDE()")
                if expr_larga and not tiene_var:
                    wn("Medidas DAX","DAX-11",f"'{nm2}': expresión larga sin VAR")

    sec_raw = None
    if "SecurityBindings" in comps:
        try: sec_raw = z.read("SecurityBindings")
        except: pass
    has_rls = bool(sec_raw and len(sec_raw) > 10)
    (ok if has_rls else wn)("Seguridad RLS","SEC-01",
        "RLS configurado" if has_rls else "Sin SecurityBindings")
    if schema:
        tnames = [t.get("name","").upper() for t in schema.get("model",{}).get("tables",[])]
        for tc in REGLAS["tablas_criticas_rls"]:
            if any(tc in n for n in tnames):
                (ok if has_rls else er)("Seguridad RLS","SEC-02",
                    f"Tabla '{tc}': {'RLS presente' if has_rls else 'sin RLS'}",
                    "" if has_rls else "Agregar roles antes de publicar")
        for t in schema.get("model",{}).get("tables",[]):
            for c in t.get("columns",[]):
                cn = c.get("name","").upper()
                for s in REGLAS["columnas_sensibles"]:
                    if s.upper() in cn and not c.get("isHidden",False):
                        wn("Seguridad RLS","SEC-03",
                           f"Columna sensible visible: {t.get('name','')}.{c.get('name','')}")

    meta = _read_zip_component(z,"Metadata")
    if meta:
        autor = meta.get("createdBy",meta.get("author",""))
        (ok if autor else wn)("Metadatos","META-01",
            f"Autor: {autor}" if autor else "Sin autor registrado")
        desc = meta.get("description","")
        (ok if desc else wn)("Metadatos","META-02",
            "Descripción presente" if desc else "Sin descripción del reporte")

    if lay:
        ls   = json.dumps(lay)
        imgs = ls.count('"base64"') + ls.count('"imageUrl"')
        (wn if imgs>10 else ok)("Performance","PERF-01",f"Imágenes embebidas: {imgs}")
        bm   = len(lay.get("bookmarks",[]))
        (wn if bm>30 else ok)("Performance","PERF-02",f"Bookmarks: {bm}")

    pages  = extraer_paginas(lay) if lay else []
    colors = extraer_colores(lay, z) if lay else {}

    if colors.get("colores"):
        (ok if colors["es_standard"] else wn)("Colores","COL-01",
            f"Tema: '{colors['nombre']}'" + (" — estándar corporativo" if colors["es_standard"]
            else " — verificar paleta corporativa"))
    else:
        wn("Colores","COL-01","Sin tema de color detectado — aplicar tema corporativo")

    z.close()
    return _build_pbix(res, pages, colors, medidas_d)

def _build_pbix(res, pages, colors, medidas_d=None):
    cats = {}
    for r in res: cats.setdefault(r["cat"],[]).append(r)
    er  = sum(1 for r in res if r["sev"]=="ERROR")
    av  = sum(1 for r in res if r["sev"]=="AVISO")
    ok_ = sum(1 for r in res if r["sev"]=="INFO")
    return {"resultados":res,"categorias":cats,
            "errores":er,"avisos":av,"pasaron":ok_,
            "total":len(res),"aprobado":er==0,
            "pages":pages,"colors":colors,
            "medidas_detalle": medidas_d or []}


# ════════════════════════════════════════════════════════
#  RUTAS FLASK — Autenticación
# ════════════════════════════════════════════════════════

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        usuario  = request.form.get("usuario", "").strip()
        password = request.form.get("password", "")
        with _db() as conn:
            row = conn.execute("SELECT * FROM usuarios WHERE usuario=?", (usuario,)).fetchone()
        if row and not row["activo"]:
            return render_template("login.html", error="Este usuario está desactivado. Consultá con un administrador.")
        if row and check_password_hash(row["password_hash"], password):
            session["usuario"]    = row["usuario"]
            session["usuario_id"] = row["id"]
            session["nombre"]     = row["nombre"] or row["usuario"]
            session["rol"]        = row["rol"]
            session["debe_cambiar_password"] = bool(row["debe_cambiar_password"])
            with _db() as conn:
                conn.execute("UPDATE usuarios SET ultimo_login=? WHERE id=?",
                             (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), row["id"]))
                conn.commit()
            if session["debe_cambiar_password"]:
                return redirect(url_for("usuarios_home"))
            destino = request.args.get("next") or url_for("home")
            return redirect(destino)
        return render_template("login.html", error="Usuario o contraseña incorrectos")
    return render_template("login.html", error=None)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ════════════════════════════════════════════════════════
#  USUARIOS — alta, activar/desactivar, permisos por pantalla, contraseña
# ════════════════════════════════════════════════════════

import secrets
import string as _string_mod

def _generar_password_temporal(n=12):
    alfabeto = _string_mod.ascii_letters + _string_mod.digits
    return "".join(secrets.choice(alfabeto) for _ in range(n))


@app.route("/usuarios")
@login_required
def usuarios_home():
    es_admin = session.get("rol") == "admin"
    usuarios_lista = []
    permisos_por_usuario = {}

    if es_admin:
        with _db() as conn:
            usuarios_lista = [dict(r) for r in conn.execute(
                "SELECT id, usuario, nombre, rol, activo, ultimo_login FROM usuarios ORDER BY usuario").fetchall()]
            for u in usuarios_lista:
                filas = conn.execute(
                    "SELECT pagina, permitido FROM usuario_permisos WHERE usuario_id=?", (u["id"],)).fetchall()
                permisos_por_usuario[u["id"]] = {r["pagina"]: bool(r["permitido"]) for r in filas}

    return render_template("usuarios.html", es_admin=es_admin, usuarios=usuarios_lista,
                            permisos_por_usuario=permisos_por_usuario, paginas=PAGINAS,
                            debe_cambiar_password=session.get("debe_cambiar_password", False))


@app.route("/api/usuarios/crear", methods=["POST"])
@admin_required
def api_usuarios_crear():
    data = request.get_json(force=True) or {}
    usuario = (data.get("usuario") or "").strip()
    nombre = (data.get("nombre") or "").strip()
    rol = data.get("rol") if data.get("rol") in ("admin", "usuario") else "usuario"
    if not usuario:
        return jsonify({"ok": False, "error": "Falta el nombre de usuario"}), 400

    password_temporal = _generar_password_temporal()
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with _db() as conn:
            cur = conn.execute("""
                INSERT INTO usuarios (usuario, password_hash, nombre, rol, activo, debe_cambiar_password, creado)
                VALUES (?,?,?,?,1,1,?)
            """, (usuario, generate_password_hash(password_temporal), nombre or usuario, rol, ts))
            uid = cur.lastrowid
            for clave in PAGINAS:
                conn.execute("""
                    INSERT INTO usuario_permisos (usuario_id, pagina, permitido) VALUES (?,?,0)
                """, (uid, clave))
            conn.commit()
    except sqlite3.IntegrityError:
        return jsonify({"ok": False, "error": "Ese usuario ya existe"}), 400

    return jsonify({"ok": True, "usuario_id": uid, "password_temporal": password_temporal})


@app.route("/api/usuarios/<int:uid>/eliminar", methods=["POST"])
@admin_required
def api_usuarios_eliminar(uid):
    if uid == session.get("usuario_id"):
        return jsonify({"ok": False, "error": "No podés eliminar tu propio usuario."}), 400
    with _db() as conn:
        row = conn.execute("SELECT usuario, rol FROM usuarios WHERE id=?", (uid,)).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "Usuario no encontrado"}), 404
        if row["rol"] == "admin":
            total_admins = conn.execute(
                "SELECT COUNT(*) c FROM usuarios WHERE rol='admin'").fetchone()["c"]
            if total_admins <= 1:
                return jsonify({"ok": False, "error": "No podés eliminar al único administrador que queda."}), 400
        conn.execute("DELETE FROM usuario_permisos WHERE usuario_id=?", (uid,))
        conn.execute("DELETE FROM usuarios WHERE id=?", (uid,))
        conn.commit()
    return jsonify({"ok": True})


@app.route("/api/usuarios/<int:uid>/activo", methods=["POST"])
@admin_required
def api_usuarios_toggle_activo(uid):
    data = request.get_json(force=True) or {}
    activo = int(bool(data.get("activo", True)))
    if uid == session.get("usuario_id") and not activo:
        return jsonify({"ok": False, "error": "No podés desactivar tu propio usuario."}), 400
    with _db() as conn:
        conn.execute("UPDATE usuarios SET activo=? WHERE id=?", (activo, uid))
        conn.commit()
    return jsonify({"ok": True})


@app.route("/api/usuarios/<int:uid>/permisos", methods=["POST"])
@admin_required
def api_usuarios_permisos(uid):
    """Body: {"pentaho": true, "deploy": false, ...}"""
    data = request.get_json(force=True) or {}
    with _db() as conn:
        for pagina, permitido in data.items():
            if pagina not in PAGINAS:
                continue
            conn.execute("""
                INSERT INTO usuario_permisos (usuario_id, pagina, permitido) VALUES (?,?,?)
                ON CONFLICT(usuario_id, pagina) DO UPDATE SET permitido=excluded.permitido
            """, (uid, pagina, int(bool(permitido))))
        conn.commit()
    return jsonify({"ok": True})


@app.route("/api/usuarios/<int:uid>/resetear_password", methods=["POST"])
@admin_required
def api_usuarios_resetear_password(uid):
    """Genera una contraseña temporal nueva para el usuario y la devuelve UNA vez, en claro."""
    nueva = _generar_password_temporal()
    with _db() as conn:
        row = conn.execute("SELECT usuario FROM usuarios WHERE id=?", (uid,)).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "Usuario no encontrado"}), 404
        conn.execute("UPDATE usuarios SET password_hash=?, debe_cambiar_password=1 WHERE id=?",
                     (generate_password_hash(nueva), uid))
        conn.commit()
    return jsonify({"ok": True, "usuario": row["usuario"], "password_temporal": nueva})


@app.route("/api/usuarios/cambiar_password", methods=["POST"])
@login_required
def api_usuarios_cambiar_password():
    """Cambio de contraseña propio — cualquier usuario logueado, sin necesitar rol admin."""
    data = request.get_json(force=True) or {}
    actual = data.get("password_actual", "")
    nueva = data.get("password_nueva", "")
    if not nueva or len(nueva) < 8:
        return jsonify({"ok": False, "error": "La nueva contraseña debe tener al menos 8 caracteres."}), 400

    with _db() as conn:
        row = conn.execute("SELECT password_hash FROM usuarios WHERE id=?",
                            (session.get("usuario_id"),)).fetchone()
        if not row or not check_password_hash(row["password_hash"], actual):
            return jsonify({"ok": False, "error": "La contraseña actual no es correcta."}), 400
        conn.execute("UPDATE usuarios SET password_hash=?, debe_cambiar_password=0 WHERE id=?",
                     (generate_password_hash(nueva), session.get("usuario_id")))
        conn.commit()
    session["debe_cambiar_password"] = False
    return jsonify({"ok": True})


# ════════════════════════════════════════════════════════
#  RUTAS FLASK — Pentaho Explorer
# ════════════════════════════════════════════════════════

@app.route("/")
@login_required
def home():
    return render_template("index.html")

@app.route("/api/tree")
@login_required
def api_tree():
    return jsonify(get_tree())

@app.route("/search")
@login_required
def search():
    q     = request.args.get("q","").strip()
    types = [t for t in request.args.get("types","").split(",") if t]
    start = time.time()
    res   = search_ssh(q, types) or search_local(q, types)
    return jsonify({"results":res,"count":len(res),
                    "elapsed_ms":round((time.time()-start)*1000,2)})

@app.route("/open")
@login_required
def open_file():
    path = request.args.get("path","")
    q    = request.args.get("q","")
    if not path: abort(404)
    is_remote = path.startswith("/")
    ext       = os.path.splitext(path)[1].lower()
    parsed, content = parse_file(path, is_remote=is_remote)
    return render_template("viewer.html",
        file=path, filename=os.path.basename(path), ext=ext,
        content=content, search=q,
        rows=parsed.get("rows",parsed.get("steps",[])),
        summary=parsed["summary"], sources=parsed["sources"],
        targets=parsed["targets"], dependencies=parsed["dependencies"],
        sql_blocks=parsed["sql_blocks"],
        functions=parsed.get("functions",[]),
        classes=parsed.get("classes",[]),
        imports=parsed.get("imports",[]))


@app.route("/api/descargar_local")
@login_required
def api_descargar_local():
    """Descarga un archivo que ya está en el disco local del servidor (LOCAL_PATH)."""
    path = request.args.get("path", "")
    local_root = os.path.normpath(LOCAL_PATH)
    candidato = os.path.normpath(path)
    if not path or not (candidato + os.sep).startswith(local_root + os.sep):
        abort(404)
    if not os.path.isfile(candidato):
        abort(404)
    return send_file(candidato, as_attachment=True, download_name=os.path.basename(candidato))


@app.route("/api/descargar_local_carpeta")
@login_required
def api_descargar_local_carpeta():
    """Comprime y descarga la carpeta local (dentro de LOCAL_PATH) que contiene un archivo."""
    path = request.args.get("path", "")
    carpeta_param = request.args.get("carpeta", "")
    local_root = os.path.normpath(LOCAL_PATH)

    carpeta = os.path.normpath(carpeta_param) if carpeta_param else os.path.dirname(os.path.normpath(path))
    if not (carpeta + os.sep).startswith(local_root + os.sep) or not os.path.isdir(carpeta):
        abort(404)

    nombre_zip = os.path.basename(carpeta.rstrip(os.sep)) or "carpeta"
    zip_base = Path(tempfile.mkdtemp()) / nombre_zip
    shutil.make_archive(str(zip_base), "zip", carpeta)
    return send_file(str(zip_base) + ".zip", as_attachment=True, download_name=f"{nombre_zip}.zip")


@app.route("/api/descargar_remoto")
@login_required
def api_descargar_remoto():
    """
    Descarga directa a tu máquina de cualquier archivo remoto que ya ves en
    el Explorador de Pentaho (KTR/KJB/PY), sin pasar por el flujo de versionado.
    """
    path = request.args.get("path", "")
    if not path or not path.startswith("/"):
        abort(404)
    nombre = posixpath.basename(path)
    tmp_local = Path(tempfile.mkdtemp()) / nombre
    ok, err = _sftp_get(path, tmp_local)
    if not ok:
        return jsonify({"ok": False, "error": f"Fallo el SFTP: {err}"}), 500
    return send_file(str(tmp_local), as_attachment=True, download_name=nombre)


def _zip_carpeta_remota(carpeta_remota, nombre_zip):
    """
    Trae TODOS los archivos de una carpeta remota (recursivo) y arma un .zip
    local con la misma estructura, para bajar la carpeta completa de una.
    Usa sudo (via _run) para empaquetar en el servidor con 'tar', porque el
    usuario SFTP puede no tener permiso de lectura directo sobre esos archivos,
    y así se trae un solo archivo en vez de uno por uno.
    Devuelve (ruta_zip, error).
    """
    staging_tar = f"/tmp/deploy_stage_{uuid.uuid4().hex}.tar.gz"
    cmd = f'tar -czf "{staging_tar}" -C "{carpeta_remota}" . && chmod 644 "{staging_tar}"'
    out, ok = _run(cmd)
    if not ok:
        return None, f"No se pudo preparar la carpeta en el servidor (sudo tar): {out or 'sin detalle'}"

    tmp_local_tar = Path(tempfile.mkdtemp()) / "carpeta.tar.gz"
    ssh = _ssh()
    try:
        sftp = ssh.open_sftp()
        sftp.get(staging_tar, str(tmp_local_tar))
        sftp.close()
    except Exception as e:
        return None, f"Fallo bajando el paquete comprimido: {e}"
    finally:
        ssh.close()
        _run(f'rm -f "{staging_tar}"')

    extract_dir = Path(tempfile.mkdtemp())
    try:
        with tarfile.open(tmp_local_tar) as tf:
            tf.extractall(extract_dir)
    except Exception as e:
        return None, f"El paquete bajado no se pudo abrir: {e}"

    zip_base = Path(tempfile.mkdtemp()) / nombre_zip
    shutil.make_archive(str(zip_base), "zip", str(extract_dir))
    return str(zip_base) + ".zip", None


@app.route("/api/descargar_remoto_carpeta")
@login_required
def api_descargar_remoto_carpeta():
    """
    Descarga, comprimida en .zip, TODA la carpeta que contiene un archivo
    remoto (o una carpeta indicada directamente), para bajar de una todo el
    proceso relacionado y no solo el archivo suelto.
      ?path=<archivo>   -> baja la carpeta que lo contiene
      ?carpeta=<dir>    -> baja esa carpeta directamente
    """
    path = request.args.get("path", "")
    carpeta = request.args.get("carpeta", "")
    if carpeta:
        carpeta_remota = carpeta
    elif path:
        carpeta_remota = posixpath.dirname(path)
    else:
        abort(404)

    nombre_zip = posixpath.basename(carpeta_remota.rstrip("/")) or "carpeta"
    zip_path, err = _zip_carpeta_remota(carpeta_remota, nombre_zip)
    if not zip_path:
        return jsonify({"ok": False, "error": err}), 500
    return send_file(zip_path, as_attachment=True, download_name=f"{nombre_zip}.zip")

@app.route("/catalog")
@login_required
def catalog():
    path = request.args.get("path","")
    if not path: abort(404)
    is_remote = path.startswith("/")
    ext       = os.path.splitext(path)[1].lower()
    parsed, _ = parse_file(path, is_remote=is_remote)
    return render_template("catalog.html",
        file=os.path.basename(path), ext=ext,
        summary=parsed["summary"], sources=parsed["sources"],
        targets=parsed["targets"], dependencies=parsed["dependencies"],
        sql_blocks=parsed["sql_blocks"],
        functions=parsed.get("functions",[]),
        classes=parsed.get("classes",[]),
        imports=parsed.get("imports",[]))

@app.route("/etl")
@login_required
def etl_dashboard():
    log, _ = _read_file(_LOG, tail=LOG_TAIL_LINES)
    lines  = log.splitlines() if log else []
    today  = time.strftime("%Y-%m-%d")
    all_rows = []
    for l in lines:
        l = l.strip()
        if not l: continue
        parts  = l.split()
        if len(parts) < 3: continue
        fecha   = parts[0] if len(parts[0])==10 and "-" in parts[0] else ""
        hora    = parts[1] if len(parts) > 1 and re.match(r'^\d{2}:\d{2}:\d{2}$', parts[1]) else ""
        proceso = parts[2] if len(parts)>2 else parts[-1]
        estado  = "ERROR" if "ERROR" in l.upper() else "OK"
        all_rows.append({"line":l,"estado":estado,"proceso":proceso,
                          "fecha":fecha,"hora":hora,"orden":f"{fecha} {hora}"})
    # Más reciente primero
    all_rows.sort(key=lambda r: r["orden"], reverse=True)
    fechas   = sorted({r["fecha"] for r in all_rows if r["fecha"]},reverse=True)
    hoy_rows = [r for r in all_rows if r["fecha"]==today]
    proc_hoy = {r["proceso"] for r in hoy_rows}
    err_hoy  = {r["proceso"] for r in hoy_rows if r["estado"]=="ERROR"}
    return render_template("etl_dashboard.html",
        all_rows=all_rows, rows=hoy_rows,
        total=len(proc_hoy), ok=len(proc_hoy)-len(err_hoy),
        error=len(err_hoy), today=today, fechas=fechas)

@app.route("/api/etl/log_detail")
@login_required
def api_etl_log_detail():
    """
    Log de detalle del servidor para un proceso puntual.
    Busca primero un archivo de log específico del proceso (ej. log_JOB_TICKETERA_20260703.log
    en /var/pentaho/logs); si no existe, hace fallback a las líneas del log general que
    mencionan ese proceso en esa fecha.
    """
    proceso = request.args.get("proceso", "").strip()
    fecha   = request.args.get("fecha", "").strip()
    if not proceso:
        return jsonify({"ok": False, "error": "Falta el nombre del proceso"}), 400

    safe_proc    = re.sub(r'[^A-Za-z0-9_\-]', '', proceso)
    fecha_compact = fecha.replace("-", "")

    archivos = []
    if safe_proc:
        if fecha_compact:
            cmd = (f'find /var/pentaho/logs -maxdepth 1 -iname "*{safe_proc}*{fecha_compact}*" '
                   f'2>/dev/null | sort')
        else:
            cmd = f'find /var/pentaho/logs -maxdepth 1 -iname "*{safe_proc}*" 2>/dev/null | sort'
        out, ok = _run(cmd)
        archivos = [l.strip() for l in out.splitlines() if l.strip()] if ok else []

    contenido = ""
    if archivos:
        partes = []
        for fp in archivos[:5]:
            txt, _ = _read_file(fp, tail=500)
            partes.append(f"===== {fp} =====\n{txt}")
        contenido = "\n\n".join(partes)
    else:
        grep_cmd = f'grep -i -- "{safe_proc}" {_LOG} 2>/dev/null'
        if fecha:
            grep_cmd += f' | grep -- "{fecha}"'
        contenido, _ = _run(grep_cmd)
        if contenido.strip():
            archivos = [_LOG]

    return jsonify({
        "ok": True, "proceso": proceso, "fecha": fecha,
        "archivos": archivos,
        "contenido": contenido.strip() or "No se encontraron registros de log para este proceso/fecha en el servidor."
    })

@app.route("/crontab")
@login_required
def crontab_view():
    data, _ = _read_file(_CRONTAB)
    rows = []
    for l in (data or "").splitlines():
        raw = l.strip()
        if not raw:
            continue
        activo  = not raw.startswith("#")
        limpio  = raw.lstrip("#").strip()
        p = limpio.split()
        if len(p) < 6:
            continue
        sched = " ".join(p[:5])
        rows.append({"raw":limpio,"schedule":sched,"schedule_text":_cron_text(sched),
                     "user":p[5],"command":" ".join(p[6:]),"activo":activo})
    return render_template("crontab.html", rows=rows)

@app.route("/api/crontab/toggle", methods=["POST"])
@login_required
def api_crontab_toggle():
    """
    Activa o desactiva (comenta con #) una línea del crontab del servidor.
    Se hace un backup de /etc/crontab antes de sobrescribirlo.
    """
    data  = request.get_json(force=True)
    linea = (data.get("linea") or "").strip()
    if not linea:
        return jsonify({"ok": False, "error": "Línea vacía"}), 400

    raw, ok = _read_file(_CRONTAB)
    if not ok or raw is None:
        return jsonify({"ok": False, "error": "No se pudo leer el crontab del servidor"}), 500

    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    _run(f"cp {_CRONTAB} {_CRONTAB}.bak_{ts}")

    nuevas = []
    encontrada = False
    activo_ahora = None
    for l in raw.splitlines():
        stripped = l.strip()
        comparador = stripped.lstrip("#").strip()
        if not encontrada and comparador == linea:
            encontrada = True
            if stripped.startswith("#"):
                nuevas.append(comparador)          # descomentar → activar
                activo_ahora = True
            else:
                nuevas.append("# " + stripped)     # comentar → desactivar
                activo_ahora = False
        else:
            nuevas.append(l)

    if not encontrada:
        return jsonify({"ok": False, "error": "No se encontró esa línea en el crontab actual"}), 404

    contenido_nuevo = "\n".join(nuevas) + "\n"
    try:
        ssh  = _ssh()
        sftp = ssh.open_sftp()
        tmp_remote = f"/tmp/crontab_edit_{ts}.txt"
        with sftp.open(tmp_remote, "w") as fh:
            fh.write(contenido_nuevo)
        sftp.close()
        _out, ok2 = _run(f"cp {tmp_remote} {_CRONTAB} && rm -f {tmp_remote}")
        ssh.close()
    except Exception as e:
        return jsonify({"ok": False, "error": f"No se pudo escribir el crontab: {e}"}), 500

    if not ok2:
        return jsonify({"ok": False, "error": "Falló la escritura del crontab en el servidor"}), 500

    return jsonify({"ok": True, "activo": activo_ahora})


# ════════════════════════════════════════════════════════
#  REPORTE DE ESTADOS — promedio de ejecuciones por proceso
# ════════════════════════════════════════════════════════

def _proximo_domingo(desde_dt):
    dias = (6 - desde_dt.weekday()) % 7   # weekday(): lunes=0 ... domingo=6
    return desde_dt + timedelta(days=dias)

def _veces_planificadas_en_rango(campos, d0, d1):
    """
    Estimación de cuántas veces debería haber corrido una tarea cron entre d0 y d1
    según sus campos (minuto hora dia_mes mes dia_semana). Soporta '*' y '*/N' en
    minuto/hora; NO soporta listas (1,3,5) ni rangos (1-5) — se cuenta como 1 vez/día
    en esos casos, así que es una aproximación, no un valor exacto.
    """
    try:
        minuto, hora, dom, mon, dow = campos
    except Exception:
        return 0
    veces_dia = 1
    if hora == "*" and minuto.startswith("*/"):
        try: veces_dia = max(1, (24*60)//int(minuto[2:]))
        except Exception: veces_dia = 1
    elif hora.startswith("*/"):
        try: veces_dia = max(1, 24//int(hora[2:]))
        except Exception: veces_dia = 1

    total = 0
    d = d0
    while d <= d1:
        dow_cron = str((d.isoweekday()) % 7)   # domingo=0 ... sábado=6 (estilo cron)
        dow_ok = dow in ("*", dow_cron, str(d.isoweekday()))
        dom_ok = dom in ("*", str(d.day))
        mon_ok = mon in ("*", str(d.month))
        if dow_ok and dom_ok and mon_ok:
            total += veces_dia
        d += timedelta(days=1)
    return total

@app.route("/reporte")
@login_required
def reporte_estados():
    return render_template("reporte_estados.html")

@app.route("/api/reporte/estados")
@login_required
def api_reporte_estados():
    hoy = datetime.now()
    desde = request.args.get("desde", "").strip()
    hasta = request.args.get("hasta", "").strip()
    if not desde:
        desde = hoy.strftime("%Y-%m-%d")
    if not hasta:
        hasta = _proximo_domingo(hoy).strftime("%Y-%m-%d")

    try:
        d0 = datetime.strptime(desde, "%Y-%m-%d")
        d1 = datetime.strptime(hasta, "%Y-%m-%d")
    except Exception:
        return jsonify({"ok": False, "error": "Fechas inválidas, usar formato YYYY-MM-DD"}), 400

    log, _ = _read_file(_LOG, tail=LOG_TAIL_LINES)
    lines  = log.splitlines() if log else []
    por_proceso = defaultdict(lambda: {"ok":0, "error":0, "fechas":set()})
    for l in lines:
        l = l.strip()
        if not l: continue
        parts = l.split()
        if len(parts) < 3: continue
        fecha = parts[0] if len(parts[0])==10 and "-" in parts[0] else ""
        if not fecha or fecha < desde or fecha > hasta:
            continue
        proceso = parts[2] if len(parts)>2 else parts[-1]
        estado  = "ERROR" if "ERROR" in l.upper() else "OK"
        por_proceso[proceso]["fechas"].add(fecha)
        por_proceso[proceso]["error" if estado=="ERROR" else "ok"] += 1

    cron_raw, _ = _read_file(_CRONTAB)
    planificado = {}
    for l in (cron_raw or "").splitlines():
        s = l.strip()
        if not s or s.startswith("#"): continue
        p = s.split()
        if len(p) < 6: continue
        cmd = " ".join(p[6:])
        m = re.search(r'([A-Za-z0-9_\-]+)\.(sh|py|kjb|ktr)', cmd)
        if not m: continue
        nombre = m.group(1).upper()
        veces  = _veces_planificadas_en_rango(p[:5], d0, d1)
        planificado[nombre] = planificado.get(nombre, 0) + veces

    filas = []
    for proc in sorted(set(list(por_proceso.keys()) + list(planificado.keys()))):
        datos  = por_proceso.get(proc, {"ok":0,"error":0,"fechas":set()})
        total  = datos["ok"] + datos["error"]
        planif = planificado.get(proc)
        pct_exito = round(datos["ok"]/total*100, 1) if total else 0.0
        cumplimiento = round(total/planif*100, 1) if planif else None
        filas.append({
            "proceso": proc, "ok": datos["ok"], "error": datos["error"],
            "total_ejecuciones": total, "dias_con_registro": len(datos["fechas"]),
            "pct_exito": pct_exito, "planificado": planif,
            "cumplimiento_pct": cumplimiento,
        })

    return jsonify({"ok": True, "desde": desde, "hasta": hasta, "filas": filas})


# ════════════════════════════════════════════════════════
#  AUDITORÍA DEL SERVIDOR — sesiones y cambios de archivos
# ════════════════════════════════════════════════════════

@app.route("/auditoria")
@login_required
def auditoria_servidor():
    return render_template("auditoria.html")

@app.route("/api/auditoria/sesiones")
@login_required
def api_auditoria_sesiones():
    """
    Sesiones recientes contra el servidor Pentaho, incluyendo la IP/host de origen.
    Como todas las conexiones usan el mismo usuario de sistema (sysadmin), esto NO
    identifica a la persona — solo desde qué IP se conectó alguien y cuándo. Para
    saber quién fue hay que cruzarlo con quién tenía esa IP asignada en ese momento
    (VPN, DHCP, etc.), algo que este portal no puede resolver por sí solo.
    """
    out, ok = _run("last -F -n 40 2>/dev/null")
    sesiones = [l.strip() for l in (out or "").splitlines()
                if l.strip() and not l.strip().startswith(("wtmp", "reboot"))]
    return jsonify({"ok": ok, "sesiones": sesiones})

@app.route("/api/auditoria/cambios")
@login_required
def api_auditoria_cambios():
    """
    Archivos creados o modificados recientemente en el proyecto Pentaho y en los logs.
    Incluye fecha de modificación y usuario propietario del archivo — NO incluye la IP
    de origen, porque el sistema de archivos de Linux no la registra. Para acercarse a
    "quién lo cambió y desde dónde", hay que cruzar la hora de este listado con
    /api/auditoria/sesiones (misma ventana de tiempo).
    """
    try:
        horas = float(request.args.get("horas", "48"))
    except Exception:
        horas = 48.0
    minutos = max(1, int(horas * 60))
    cmd = (f'find {_PROOT} /var/pentaho/logs -maxdepth 3 -type f -mmin -{minutos} '
           r'-printf "%TY-%Tm-%Td %TH:%TM|%u|%s|%p\n" 2>/dev/null | sort -r | head -150')
    out, ok = _run(cmd)
    cambios = []
    for l in (out or "").splitlines():
        p = l.split("|")
        if len(p) == 4:
            cambios.append({"fecha_mod": p[0], "usuario": p[1], "bytes": p[2], "path": p[3]})
    return jsonify({"ok": ok, "cambios": cambios})

@app.route("/compare", methods=["GET","POST"])
@login_required
def compare():
    if request.method == "GET":
        q = request.args.get("q","")
        return render_template("compare.html", q=q, results=[], diff=None, error=None)
    remote_path = request.form.get("remote_path","").strip()
    uploaded    = request.files.get("archivo_local")
    if not remote_path or not uploaded:
        return render_template("compare.html", q="", results=[], diff=None,
                               error="Seleccioná un archivo del servidor y subí el archivo local.")
    ext = os.path.splitext(remote_path)[1].lower()
    if ext not in (".ktr",".kjb"):
        return render_template("compare.html", q="", results=[], diff=None,
                               error="Solo se soportan .ktr y .kjb")
    srv_content = _read_content(remote_path)
    if not srv_content:
        return render_template("compare.html", q="", results=[], diff=None,
                               error="No se pudo leer el archivo del servidor.")
    try:
        loc_content = uploaded.read().decode("utf-8", errors="replace")
    except Exception as e:
        return render_template("compare.html", q="", results=[], diff=None,
                               error=f"Error leyendo archivo local: {e}")
    srv  = _ext_diff(srv_content, ext); loc = _ext_diff(loc_content, ext)
    diffs = {"steps":_diff(srv["steps"],loc["steps"]),
             "sources":_diff(srv["sources"],loc["sources"]),
             "targets":_diff(srv["targets"],loc["targets"]),
             "connections":_diff(srv["connections"],loc["connections"])}
    sql_diff = _diff_sql(srv["sql_blocks"],loc["sql_blocks"]) if ext==".ktr" else None
    total = sum(len(d["solo_servidor"])+len(d["solo_local"]) for d in diffs.values())
    if sql_diff:
        total += len(sql_diff["diferentes"])+len(sql_diff["solo_servidor"])+len(sql_diff["solo_local"])
    return render_template("compare.html", q="", results=[], diff={
        "remote_name":os.path.basename(remote_path),
        "local_file":uploaded.filename,
        "ext":ext,"diffs":diffs,"sql_diff":sql_diff,
        "total_diferencias":total,"identicos":total==0,
    }, error=None)

@app.route("/api/status")
@login_required
def api_status():
    _, ok = _run("echo ok")
    return jsonify({"status":"ok" if ok else "error"})


# ════════════════════════════════════════════════════════
#  RUTAS FLASK — Power BI
# ════════════════════════════════════════════════════════

@app.route("/powerbi")
@login_required
def powerbi_home():
    return render_template("powerbi.html", tiene_reglas=_rp.exists())

@app.route("/powerbi/validar", methods=["POST"])
@login_required
def powerbi_validar():
    archivo = request.files.get("pbix_file")
    if not archivo or not archivo.filename:
        return jsonify({"error":"No se recibió archivo"})
    if not archivo.filename.lower().endswith(".pbix"):
        return jsonify({"error":"Solo se aceptan archivos .pbix"})
    tmp = tempfile.mkdtemp()
    try:
        ruta = os.path.join(tmp, archivo.filename)
        archivo.save(ruta)
        data = validar_pbix(ruta)
        data["archivo"]   = archivo.filename
        data["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # Guardar en SQLite
        vid = guardar_validacion(data)
        data["validacion_id"] = vid
        # No enviar medidas detalle al frontend (puede ser pesado)
        data.pop("medidas_detalle", None)
        return jsonify(data)
    except Exception as e:
        app.logger.error(traceback.format_exc())
        return jsonify({"error":f"{type(e).__name__}: {e}"})
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

@app.route("/powerbi/historial")
@login_required
def powerbi_historial():
    """Página de historial de validaciones."""
    q      = request.args.get("q","").strip()
    fecha  = request.args.get("fecha","").strip()
    estado = request.args.get("estado","").strip()

    sql    = "SELECT * FROM validaciones WHERE 1=1"
    params = []
    if q:
        sql += " AND archivo LIKE ?"
        params.append(f"%{q}%")
    if fecha:
        sql += " AND fecha = ?"
        params.append(fecha)
    if estado == "aprobado":
        sql += " AND aprobado = 1"
    elif estado == "rechazado":
        sql += " AND aprobado = 0"

    sql += " ORDER BY id DESC LIMIT 200"

    with _db() as conn:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
        fechas_disp = [r["fecha"] for r in
                       conn.execute("SELECT DISTINCT fecha FROM validaciones ORDER BY fecha DESC").fetchall()]

    return render_template("powerbi_historial.html",
        validaciones=rows, q=q, fecha=fecha, estado=estado,
        fechas_disponibles=fechas_disp)

@app.route("/powerbi/historial/<int:vid>")
@login_required
def powerbi_detalle(vid):
    """Detalle completo de una validación guardada."""
    with _db() as conn:
        v = conn.execute("SELECT * FROM validaciones WHERE id=?", (vid,)).fetchone()
        if not v: abort(404)
        v = dict(v)
        reglas  = [dict(r) for r in conn.execute(
            "SELECT * FROM validacion_reglas WHERE validacion_id=? ORDER BY id", (vid,)).fetchall()]
        paginas = [dict(r) for r in conn.execute(
            "SELECT * FROM validacion_paginas WHERE validacion_id=? ORDER BY id", (vid,)).fetchall()]

    # Reconstruir datos del JSON completo
    full = {}
    try: full = json.loads(v.get("detalle_json","{}"))
    except: pass

    colores_list = []
    try: colores_list = json.loads(v.get("tema_colores","[]"))
    except: pass

    return render_template("powerbi_detalle.html",
        v=v, reglas=reglas, paginas=paginas,
        full=full, colores_list=colores_list)

@app.route("/powerbi/pdf", methods=["POST"])
@login_required
def powerbi_pdf():
    try:
        data = request.get_json(force=True)
        if not data: return jsonify({"error":"Sin datos"}),400
        html = render_template("reporte_pdf.html", d=data)
        try:
            from weasyprint import HTML as WP
            buf  = io.BytesIO(WP(string=html, base_url=str(BASE)).write_pdf())
            name = f"QA_PBIX_{data.get('archivo','reporte').replace('.pbix','')}.pdf"
            return send_file(buf, mimetype="application/pdf",
                             as_attachment=True, download_name=name)
        except ImportError:
            return html, 200, {"Content-Type":"text/html;charset=utf-8","X-PDF-Fallback":"true"}
    except Exception as e:
        return jsonify({"error":str(e)}),500

@app.route("/powerbi/reglas")
@login_required
def powerbi_reglas():
    reglas_data = [
        ({"icono":"🚫","titulo":"Fuentes prohibidas","descripcion":"No permitidas en el banco","tipo":"tags","color":"red"},
         REGLAS["fuentes_prohibidas"]),
        ({"icono":"✅","titulo":"Fuentes autorizadas","descripcion":"Conexiones permitidas","tipo":"tags","color":"green"},
         REGLAS["fuentes_permitidas"]),
        ({"icono":"🔒","titulo":"Tablas críticas RLS","descripcion":"Requieren Row Level Security","tipo":"tags","color":"red"},
         REGLAS["tablas_criticas_rls"]),
        ({"icono":"🔐","titulo":"Columnas sensibles","descripcion":"Deben estar ocultas o con RLS","tipo":"tags","color":"red"},
         REGLAS["columnas_sensibles"]),
        ({"icono":"📏","titulo":"Límites","descripcion":"Cantidades máximas recomendadas","tipo":"limite","color":"blue"},
         [{"label":"Tablas","valor":REGLAS["limite_tablas"]},
          {"label":"Columnas","valor":REGLAS["limite_columnas"]},
          {"label":"Medidas","valor":REGLAS["limite_medidas"]},
          {"label":"Páginas","valor":REGLAS["limite_paginas"]},
          {"label":"Tamaño MB","valor":REGLAS["max_mb"]}]),
    ]
    return render_template("powerbi_reglas.html", tiene_reglas=_rp.exists(), reglas_data=reglas_data)

@app.route("/api/powerbi/reglas", methods=["GET"])
@login_required
def get_powerbi_reglas():
    return jsonify({"reglas":REGLAS,"tiene_archivo":_rp.exists()})

@app.route("/api/powerbi/reglas", methods=["POST"])
@login_required
def save_powerbi_reglas():
    try:
        data  = request.get_json(force=True)
        clean = {k:v for k,v in (data or {}).items() if k in REGLAS_DEFAULT}
        if not clean: return jsonify({"ok":False,"error":"Sin claves válidas"}),400
        _rp.write_text(json.dumps(clean,ensure_ascii=False,indent=2),encoding="utf-8")
        REGLAS.update(clean)
        return jsonify({"ok":True})
    except Exception as e:
        return jsonify({"ok":False,"error":str(e)}),500

@app.route("/api/powerbi/reglas/reset", methods=["POST"])
@login_required
def reset_powerbi_reglas():
    if _rp.exists(): _rp.unlink()
    return jsonify({"ok":True})

@app.route("/api/powerbi/historial")
@login_required
def api_historial():
    """API JSON para consultas externas."""
    q     = request.args.get("q","").strip()
    fecha = request.args.get("fecha","").strip()
    sql   = "SELECT id,archivo,fecha,timestamp,aprobado,errores,avisos,pasaron,total,mb,n_paginas,n_medidas,n_tablas,n_columnas,tema_nombre FROM validaciones WHERE 1=1"
    params = []
    if q:
        sql += " AND archivo LIKE ?"; params.append(f"%{q}%")
    if fecha:
        sql += " AND fecha = ?"; params.append(fecha)
    sql += " ORDER BY id DESC LIMIT 100"
    with _db() as conn:
        rows = [dict(r) for r in conn.execute(sql,params).fetchall()]
    return jsonify({"count":len(rows),"validaciones":rows})


# ════════════════════════════════════════════════════════
#  PYTHON & ML — Ejecución y Análisis
# ════════════════════════════════════════════════════════

SCRIPTS_DIR = BASE / "scripts_python"
SCRIPTS_DIR.mkdir(exist_ok=True)
RESULTS_DIR = BASE / "resultados_python"
RESULTS_DIR.mkdir(exist_ok=True)

# Almacén de ejecuciones en memoria
_executions = {}

def init_python_db():
    with _db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS python_scripts (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre      TEXT NOT NULL,
            tipo        TEXT DEFAULT 'script',
            fecha       TEXT NOT NULL,
            timestamp   TEXT NOT NULL,
            codigo      TEXT,
            archivo     TEXT,
            analisis    TEXT,
            score       INTEGER DEFAULT 0,
            tags        TEXT DEFAULT '[]'
        );
        CREATE TABLE IF NOT EXISTS python_ejecuciones (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            script_id   INTEGER,
            fecha       TEXT NOT NULL,
            timestamp   TEXT NOT NULL,
            duracion_ms REAL DEFAULT 0,
            estado      TEXT DEFAULT 'pending',
            salida      TEXT,
            errores     TEXT,
            metricas    TEXT DEFAULT '{}',
            FOREIGN KEY (script_id) REFERENCES python_scripts(id)
        );
        """)

init_python_db()


def analizar_python(codigo):
    """Analiza un script Python para buenas prácticas y patrones ML."""
    resultado = {
        "tipo": "script",
        "imports": [],
        "funciones": [],
        "clases": [],
        "buenas_practicas": [],
        "problemas": [],
        "ml_info": None,
        "score": 0,
        "lineas": len(codigo.splitlines()),
        "tags": [],
    }

    # Parse AST
    try:
        tree = pyast.parse(codigo)
    except SyntaxError as e:
        resultado["problemas"].append({
            "sev": "ERROR", "regla": "SYN-01",
            "msg": f"Error de sintaxis línea {e.lineno}: {e.msg}",
        })
        resultado["score"] = 0
        return resultado

    # Collect imports, functions, classes
    imports_set = set()
    funciones = []
    clases = []
    for node in pyast.walk(tree):
        if isinstance(node, pyast.Import):
            for n in node.names:
                imports_set.add(n.name.split(".")[0])
        elif isinstance(node, pyast.ImportFrom):
            if node.module:
                imports_set.add(node.module.split(".")[0])
        elif isinstance(node, (pyast.FunctionDef, pyast.AsyncFunctionDef)):
            has_doc = (isinstance(node.body[0], pyast.Expr) and
                       isinstance(node.body[0].value, (pyast.Constant, pyast.Str))
                       if node.body else False)
            funciones.append({
                "nombre": node.name,
                "args": len(node.args.args),
                "linea": node.lineno,
                "tiene_docstring": has_doc,
                "decoradores": [d.id if isinstance(d, pyast.Name) else
                               getattr(d, 'attr', '?') for d in node.decorator_list],
            })
        elif isinstance(node, pyast.ClassDef):
            clases.append({"nombre": node.name, "linea": node.lineno})

    resultado["imports"] = sorted(imports_set)
    resultado["funciones"] = funciones
    resultado["clases"] = clases

    # ── Detect ML type ──
    ml_libs = {"sklearn", "xgboost", "lightgbm", "catboost", "tensorflow",
               "keras", "torch", "pytorch", "statsmodels", "prophet"}
    data_libs = {"pandas", "numpy", "scipy", "polars"}
    found_ml = ml_libs & imports_set
    found_data = data_libs & imports_set

    if found_ml:
        resultado["tipo"] = "ml_model"
        resultado["tags"].append("ML")
        resultado["ml_info"] = {
            "frameworks": sorted(found_ml),
            "data_libs": sorted(found_data),
            "tiene_train_test_split": "train_test_split" in codigo,
            "tiene_cross_validation": any(k in codigo for k in ["cross_val_score", "cross_validate", "KFold", "StratifiedKFold"]),
            "tiene_pipeline": "Pipeline" in codigo,
            "tiene_grid_search": any(k in codigo for k in ["GridSearchCV", "RandomizedSearchCV", "BayesSearchCV"]),
            "tiene_metricas": any(k in codigo for k in ["accuracy_score", "f1_score", "roc_auc", "mean_squared_error",
                                                         "classification_report", "confusion_matrix", "r2_score"]),
            "tiene_pickle_joblib": any(k in codigo for k in ["joblib", "pickle", "save_model", "dump("]),
            "tiene_feature_importance": any(k in codigo for k in ["feature_importances_", "shap", "SHAP", "permutation_importance"]),
            "tiene_logging": "logging" in imports_set or "logger" in codigo.lower(),
            "tiene_mlflow": "mlflow" in imports_set,
            "tiene_early_stopping": "early_stopping" in codigo.lower(),
            "tiene_scaler": any(k in codigo for k in ["StandardScaler", "MinMaxScaler", "RobustScaler", "normalize"]),
        }
        for fw in found_ml:
            resultado["tags"].append(fw)
    elif found_data:
        resultado["tipo"] = "data_processing"
        resultado["tags"].append("Data")

    if "cx_Oracle" in imports_set or "oracledb" in imports_set:
        resultado["tags"].append("Oracle")
    if "flask" in imports_set or "Flask" in codigo:
        resultado["tags"].append("Flask")
    if "airflow" in imports_set:
        resultado["tags"].append("Airflow")

    # ── Best practices checks ──
    score = 100
    checks = []

    # BP-01: Docstrings
    fns_sin_doc = [f["nombre"] for f in funciones if not f["tiene_docstring"]]
    if funciones:
        pct = len([f for f in funciones if f["tiene_docstring"]]) / len(funciones) * 100
        if pct >= 80:
            checks.append({"sev": "OK", "regla": "BP-01", "msg": f"Docstrings: {pct:.0f}% de funciones documentadas"})
        elif pct >= 40:
            checks.append({"sev": "AVISO", "regla": "BP-01", "msg": f"Docstrings: solo {pct:.0f}% documentadas", "det": ", ".join(fns_sin_doc[:5])})
            score -= 10
        else:
            checks.append({"sev": "ERROR", "regla": "BP-01", "msg": f"Docstrings: {pct:.0f}% — falta documentación", "det": ", ".join(fns_sin_doc[:5])})
            score -= 20

    # BP-02: Hardcoded credentials
    cred_patterns = [
        (r'(?:password|passwd|pwd)\s*=\s*["\'][^"\']+["\']', "password hardcoded"),
        (r'(?:user|usuario)\s*=\s*["\'][^"\']+["\']', "usuario hardcoded"),
        (r'\b(?:10\.\d+\.\d+\.\d+)\b', "IP privada hardcoded"),
    ]
    for pat, desc in cred_patterns:
        if re.search(pat, codigo, re.IGNORECASE):
            checks.append({"sev": "ERROR", "regla": "BP-02", "msg": f"Credencial: {desc}"})
            score -= 15

    # BP-03: Exception handling
    bare_except = len(re.findall(r'except\s*:', codigo))
    if bare_except > 0:
        checks.append({"sev": "AVISO", "regla": "BP-03", "msg": f"except: genérico ({bare_except} ocurrencias) — capturar excepciones específicas"})
        score -= 5 * min(bare_except, 4)
    else:
        checks.append({"sev": "OK", "regla": "BP-03", "msg": "Manejo de excepciones correcto"})

    # BP-04: Logging
    has_logging = "logging" in imports_set or "logger" in codigo.lower()
    has_print = len(re.findall(r'\bprint\s*\(', codigo))
    if has_logging:
        checks.append({"sev": "OK", "regla": "BP-04", "msg": "Usa logging estructurado"})
    elif has_print > 5:
        checks.append({"sev": "AVISO", "regla": "BP-04", "msg": f"{has_print} print() — considerar logging module"})
        score -= 10
    elif has_print > 0:
        checks.append({"sev": "OK", "regla": "BP-04", "msg": f"{has_print} print() detectados"})

    # BP-05: Environment variables
    has_env = "os.environ" in codigo or "os.getenv" in codigo or "dotenv" in codigo
    if has_env:
        checks.append({"sev": "OK", "regla": "BP-05", "msg": "Usa variables de entorno"})
    else:
        checks.append({"sev": "AVISO", "regla": "BP-05", "msg": "Sin variables de entorno — considerar os.getenv o python-dotenv"})
        score -= 5

    # BP-06: Type hints
    typed_funcs = sum(1 for f in funciones
                      if any(True for node in pyast.walk(tree)
                             if isinstance(node, (pyast.FunctionDef, pyast.AsyncFunctionDef))
                             and node.name == f["nombre"] and node.returns))
    if funciones:
        pct_typed = typed_funcs / len(funciones) * 100
        if pct_typed >= 50:
            checks.append({"sev": "OK", "regla": "BP-06", "msg": f"Type hints: {pct_typed:.0f}% de funciones tipadas"})
        else:
            checks.append({"sev": "AVISO", "regla": "BP-06", "msg": f"Type hints: solo {pct_typed:.0f}% — mejorar tipado"})
            score -= 5

    # BP-07: Code length
    n_lines = len(codigo.splitlines())
    if n_lines > 500:
        checks.append({"sev": "AVISO", "regla": "BP-07", "msg": f"Script largo: {n_lines} líneas — considerar modularizar"})
        score -= 10
    elif n_lines > 200:
        checks.append({"sev": "OK", "regla": "BP-07", "msg": f"Tamaño: {n_lines} líneas"})
    else:
        checks.append({"sev": "OK", "regla": "BP-07", "msg": f"Script compacto: {n_lines} líneas"})

    # ── ML-specific checks ──
    if resultado["ml_info"]:
        ml = resultado["ml_info"]

        if ml["tiene_train_test_split"]:
            checks.append({"sev": "OK", "regla": "ML-01", "msg": "Separación train/test detectada"})
        else:
            checks.append({"sev": "ERROR", "regla": "ML-01", "msg": "Sin train_test_split — riesgo de data leakage"})
            score -= 20

        if ml["tiene_cross_validation"]:
            checks.append({"sev": "OK", "regla": "ML-02", "msg": "Cross-validation implementada"})
        else:
            checks.append({"sev": "AVISO", "regla": "ML-02", "msg": "Sin cross-validation — agregar para estabilidad"})
            score -= 10

        if ml["tiene_pipeline"]:
            checks.append({"sev": "OK", "regla": "ML-03", "msg": "Usa Pipeline de sklearn"})
        else:
            checks.append({"sev": "AVISO", "regla": "ML-03", "msg": "Sin Pipeline — riesgo de data leakage en preprocesamiento"})
            score -= 10

        if ml["tiene_metricas"]:
            checks.append({"sev": "OK", "regla": "ML-04", "msg": "Métricas de evaluación presentes"})
        else:
            checks.append({"sev": "ERROR", "regla": "ML-04", "msg": "Sin métricas — agregar evaluación del modelo"})
            score -= 15

        if ml["tiene_scaler"]:
            checks.append({"sev": "OK", "regla": "ML-05", "msg": "Normalización/escalado de features"})
        else:
            checks.append({"sev": "AVISO", "regla": "ML-05", "msg": "Sin scaler — verificar si los features necesitan normalización"})
            score -= 5

        if ml["tiene_pickle_joblib"]:
            checks.append({"sev": "OK", "regla": "ML-06", "msg": "Serialización del modelo (joblib/pickle)"})
        else:
            checks.append({"sev": "AVISO", "regla": "ML-06", "msg": "Sin serialización — agregar joblib.dump para producción"})
            score -= 5

        if ml["tiene_feature_importance"]:
            checks.append({"sev": "OK", "regla": "ML-07", "msg": "Interpretabilidad (feature importance/SHAP)"})

        if ml["tiene_logging"] or ml["tiene_mlflow"]:
            checks.append({"sev": "OK", "regla": "ML-08", "msg": "Tracking de experimentos detectado"})
        else:
            checks.append({"sev": "AVISO", "regla": "ML-08", "msg": "Sin tracking — considerar MLflow o logging estructurado"})
            score -= 5

        if ml["tiene_grid_search"]:
            checks.append({"sev": "OK", "regla": "ML-09", "msg": "Optimización de hiperparámetros detectada"})

        if ml["tiene_early_stopping"]:
            checks.append({"sev": "OK", "regla": "ML-10", "msg": "Early stopping configurado"})

    resultado["buenas_practicas"] = checks
    resultado["score"] = max(0, min(100, score))
    return resultado


def ejecutar_python(codigo, timeout=120, args=""):
    """Ejecuta código Python en subprocess y retorna métricas."""
    exec_id = str(uuid.uuid4())[:8]
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Write script to temp
    script_path = RESULTS_DIR / f"exec_{exec_id}.py"
    script_path.write_text(codigo, encoding="utf-8")

    result = {
        "exec_id": exec_id,
        "timestamp": ts,
        "estado": "running",
        "salida": "",
        "errores": "",
        "duracion_ms": 0,
        "codigo_retorno": None,
        "metricas": {},
    }

    _executions[exec_id] = result

    start = time.time()
    try:
        cmd = ["python3", str(script_path)]
        if args.strip():
            cmd.extend(args.strip().split())

        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(RESULTS_DIR),
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )
        elapsed = (time.time() - start) * 1000

        result.update({
            "estado": "ok" if proc.returncode == 0 else "error",
            "salida": proc.stdout[-50000:] if proc.stdout else "",
            "errores": proc.stderr[-10000:] if proc.stderr else "",
            "duracion_ms": round(elapsed, 2),
            "codigo_retorno": proc.returncode,
            "metricas": {
                "duracion_s": round(elapsed / 1000, 3),
                "stdout_lines": len(proc.stdout.splitlines()) if proc.stdout else 0,
                "stderr_lines": len(proc.stderr.splitlines()) if proc.stderr else 0,
            },
        })
    except subprocess.TimeoutExpired:
        elapsed = (time.time() - start) * 1000
        result.update({
            "estado": "timeout",
            "errores": f"Tiempo excedido ({timeout}s)",
            "duracion_ms": round(elapsed, 2),
        })
    except Exception as e:
        elapsed = (time.time() - start) * 1000
        result.update({
            "estado": "error",
            "errores": str(e),
            "duracion_ms": round(elapsed, 2),
        })
    finally:
        # Clean up temp script
        try:
            script_path.unlink(missing_ok=True)
        except:
            pass

    # Save to DB
    try:
        with _db() as conn:
            conn.execute("""
                INSERT INTO python_ejecuciones
                (script_id, fecha, timestamp, duracion_ms, estado, salida, errores, metricas)
                VALUES (?,?,?,?,?,?,?,?)
            """, (None, ts[:10], ts, result["duracion_ms"], result["estado"],
                  result["salida"][:50000], result["errores"][:10000],
                  json.dumps(result["metricas"])))
            conn.commit()
    except:
        pass

    return result


# ── Rutas Flask — Python & ML ──

@app.route("/python")
@login_required
def python_home():
    # Load saved scripts
    with _db() as conn:
        scripts = [dict(r) for r in conn.execute(
            "SELECT * FROM python_scripts ORDER BY id DESC LIMIT 50").fetchall()]
        ejecuciones = [dict(r) for r in conn.execute(
            "SELECT * FROM python_ejecuciones ORDER BY id DESC LIMIT 30").fetchall()]
    return render_template("python_ml.html", scripts=scripts, ejecuciones=ejecuciones)


@app.route("/api/python/tree")
@login_required
def api_python_tree():
    """Árbol de directorios del servidor Pentaho — solo archivos .py, excluye venv/__pycache__/.git."""
    prune = " -o ".join(f'-name "{d}" -prune' for d in IGNORE_DIRS)
    cmd = (f'find {_PROOT} \\( {prune} \\) -prune -o -type f -name "*.py" -print '
           '2>/dev/null | sort')
    out, ok = _run(cmd)
    if not ok or not out.strip():
        return jsonify({"name":"project","type":"folder","path":_PROOT,"children":[]})
    paths = [p.strip() for p in out.splitlines() if p.strip()]
    return jsonify(_tree_from_paths(paths, _PROOT))


@app.route("/api/python/load_remote")
@login_required
def api_python_load_remote():
    """Lee un archivo .py remoto del servidor Pentaho."""
    path = request.args.get("path","").strip()
    if not path:
        return jsonify({"error":"Sin ruta"}), 400
    if not path.endswith(".py"):
        return jsonify({"error":"Solo archivos .py"}), 400
    # Security: must be under _PROOT
    if not path.startswith(_PROOT):
        return jsonify({"error":"Ruta fuera del directorio permitido"}), 403
    content = _read_content(path)
    if not content:
        return jsonify({"error":"No se pudo leer el archivo"}), 404
    return jsonify({
        "path": path,
        "nombre": os.path.basename(path),
        "carpeta": os.path.dirname(path).replace(_PROOT,"").lstrip("/") or ".",
        "codigo": content,
        "lineas": len(content.splitlines()),
    })


@app.route("/api/python/analyze", methods=["POST"])
@login_required
def api_python_analyze():
    """Analiza código Python sin ejecutarlo."""
    data = request.get_json(force=True)
    codigo = data.get("codigo", "")
    if not codigo.strip():
        return jsonify({"error": "Sin código para analizar"}), 400
    try:
        analisis = analizar_python(codigo)
        return jsonify(analisis)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/python/run", methods=["POST"])
@login_required
def api_python_run():
    """Ejecuta código Python y retorna resultado."""
    data = request.get_json(force=True)
    codigo = data.get("codigo", "")
    timeout = min(int(data.get("timeout", 120)), 300)
    args = data.get("args", "")
    if not codigo.strip():
        return jsonify({"error": "Sin código para ejecutar"}), 400
    try:
        result = ejecutar_python(codigo, timeout=timeout, args=args)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/python/save", methods=["POST"])
@login_required
def api_python_save():
    """Guarda un script en la biblioteca."""
    data = request.get_json(force=True)
    nombre = data.get("nombre", "sin_nombre.py")
    codigo = data.get("codigo", "")
    if not codigo.strip():
        return jsonify({"error": "Sin código"}), 400

    analisis = analizar_python(codigo)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO python_scripts
            (nombre, tipo, fecha, timestamp, codigo, analisis, score, tags)
            VALUES (?,?,?,?,?,?,?,?)
        """, (nombre, analisis["tipo"], ts[:10], ts, codigo,
              json.dumps(analisis, ensure_ascii=False),
              analisis["score"], json.dumps(analisis["tags"])))
        conn.commit()
        sid = cur.lastrowid

    # Also save to filesystem
    safe_name = re.sub(r'[^\w\-\.]', '_', nombre)
    fpath = SCRIPTS_DIR / safe_name
    fpath.write_text(codigo, encoding="utf-8")

    return jsonify({"ok": True, "id": sid, "analisis": analisis})


@app.route("/api/python/upload", methods=["POST"])
@login_required
def api_python_upload():
    """Sube un archivo .py."""
    archivo = request.files.get("archivo")
    if not archivo or not archivo.filename:
        return jsonify({"error": "No se recibió archivo"}), 400
    if not archivo.filename.lower().endswith(".py"):
        return jsonify({"error": "Solo archivos .py"}), 400

    codigo = archivo.read().decode("utf-8", errors="replace")
    analisis = analizar_python(codigo)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO python_scripts
            (nombre, tipo, fecha, timestamp, codigo, archivo, analisis, score, tags)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (archivo.filename, analisis["tipo"], ts[:10], ts, codigo,
              archivo.filename, json.dumps(analisis, ensure_ascii=False),
              analisis["score"], json.dumps(analisis["tags"])))
        conn.commit()
        sid = cur.lastrowid

    # Save to filesystem
    safe_name = re.sub(r'[^\w\-\.]', '_', archivo.filename)
    (SCRIPTS_DIR / safe_name).write_text(codigo, encoding="utf-8")

    return jsonify({"ok": True, "id": sid, "nombre": archivo.filename,
                    "codigo": codigo, "analisis": analisis})


@app.route("/api/python/script/<int:sid>")
@login_required
def api_python_script(sid):
    """Retorna un script guardado."""
    with _db() as conn:
        row = conn.execute("SELECT * FROM python_scripts WHERE id=?", (sid,)).fetchone()
        if not row:
            return jsonify({"error": "Script no encontrado"}), 404
        return jsonify(dict(row))


@app.route("/api/python/download/<int:sid>")
@login_required
def api_python_download(sid):
    """Descarga un script como .py."""
    with _db() as conn:
        row = conn.execute("SELECT nombre, codigo FROM python_scripts WHERE id=?", (sid,)).fetchone()
        if not row:
            abort(404)
    buf = io.BytesIO(row["codigo"].encode("utf-8"))
    return send_file(buf, mimetype="text/x-python",
                     as_attachment=True, download_name=row["nombre"])


@app.route("/api/python/historial")
@login_required
def api_python_historial():
    """Historial de ejecuciones."""
    with _db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM python_ejecuciones ORDER BY id DESC LIMIT 100").fetchall()]
    return jsonify({"count": len(rows), "ejecuciones": rows})


@app.route("/api/python/delete/<int:sid>", methods=["POST"])
@login_required
def api_python_delete(sid):
    with _db() as conn:
        conn.execute("DELETE FROM python_scripts WHERE id=?", (sid,))
        conn.commit()
    return jsonify({"ok": True})


@app.route("/api/python/enviar_a_deploy/<int:sid>", methods=["POST"])
@login_required
def api_python_enviar_a_deploy(sid):
    """
    Toma un script ya guardado en la biblioteca y lo empaqueta como .zip
    (script + requirements.txt si existe) para entrar al mismo flujo de
    versionado/checklist/implementar que KTR y JOB, usando la misma raíz
    configurable (PENTAHO_PROD_PY_PATH / PENTAHO_PROD_KTR_PATH).
    Body JSON: {"nombre_proceso":"...", "id_hu":"...", "destino_dir":"..."}
    """
    data = request.get_json(force=True) or {}
    nombre_proceso = (data.get("nombre_proceso") or "").strip()
    id_hu = (data.get("id_hu") or "").strip()
    if not nombre_proceso:
        return jsonify({"ok": False, "error": "Falta nombre_proceso"}), 400

    with _db() as conn:
        row = conn.execute("SELECT * FROM python_scripts WHERE id=?", (sid,)).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "Script no encontrado"}), 404

    version = _siguiente_version("PY", nombre_proceso)
    version_tag = (data.get("version_tag") or "").strip() or f"v{version}"
    destino_dir = _normalizar_bajo_root("PY", data.get("destino_dir", ""))

    folder = _deploy_folder("PY", nombre_proceso, version)
    zip_name = f"{re.sub(r'[^\\w\\-\\.]', '_', nombre_proceso)}_{version_tag}.zip"
    zip_path = folder / zip_name
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(row["nombre"] or "script.py", row["codigo"] or "")
        zf.writestr("requirements.txt", "")  # completar con las dependencias reales
        zf.writestr(f"{nombre_proceso}.md",
                    f"# {nombre_proceso}\n\nNecesidad que cubre: <completar>\n\nResponsable: {session.get('usuario','')}\n")

    file_hash = _file_hash(zip_path)
    responsable = session.get("usuario", "desconocido")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO deploy_versiones
            (tipo, nombre_proceso, id_hu, version, version_tag, archivo_nombre,
             ruta_local, destino_dir, hash_sha256, responsable, fecha, timestamp, estado)
            VALUES ('PY',?,?,?,?,?,?,?,?,?,?,?,'borrador')
        """, (nombre_proceso, id_hu, version, version_tag, zip_name,
              str(zip_path), destino_dir, file_hash, responsable, ts[:10], ts))
        vid = cur.lastrowid
        for criterio, _desc in CHECKLIST_ITEMS["PY"]:
            conn.execute("""
                INSERT INTO deploy_checklist (version_id, criterio, cumplido)
                VALUES (?,?,0)
            """, (vid, criterio))
        conn.commit()

    return jsonify({"ok": True, "version_id": vid, "version": version, "version_tag": version_tag})


# ════════════════════════════════════════════════════════
#  VERSIONADO — Implementar (subir a PROD) / Bajar (descargar de PROD)
# ════════════════════════════════════════════════════════

def _deploy_folder(tipo, nombre_proceso, version):
    safe_nombre = re.sub(r'[^\w\-\.]', '_', nombre_proceso)
    folder = DEPLOY_DIR / tipo / safe_nombre / f"v{version}"
    folder.mkdir(parents=True, exist_ok=True)
    return folder

def _siguiente_version(tipo, nombre_proceso):
    with _db() as conn:
        row = conn.execute("""
            SELECT MAX(version) mx FROM deploy_versiones
            WHERE tipo=? AND nombre_proceso=?
        """, (tipo, nombre_proceso)).fetchone()
        return (row["mx"] or 0) + 1

def _normalizar_bajo_root(tipo, subpath):
    """
    Resuelve subpath (relativo, elegido en el explorador visual) contra la
    raíz configurada para ese tipo, e impide escapar de esa raíz (../../etc).
    Usa posixpath SIEMPRE, porque el servidor Pentaho remoto es Linux
    independientemente del sistema operativo donde corra este portal.
    """
    root = PROD_ROOTS.get(tipo, "/pentaho/project/")
    root = root.replace("\\", "/")
    root = root if root.endswith("/") else root + "/"
    subpath = (subpath or "").strip().strip("/").replace("\\", "/")
    candidato = posixpath.normpath(posixpath.join(root, subpath))
    root_norm = posixpath.normpath(root)
    if not (candidato + "/").startswith(root_norm + "/"):
        candidato = root_norm
    return candidato


@app.route("/deploy")
@login_required
def deploy_home():
    with _db() as conn:
        versiones = [dict(r) for r in conn.execute(
            "SELECT * FROM deploy_versiones ORDER BY id DESC").fetchall()]
        for v in versiones:
            fila = conn.execute("""
                SELECT COUNT(*) total, SUM(cumplido) hechos
                FROM deploy_checklist WHERE version_id=?
            """, (v["id"],)).fetchone()
            total = fila["total"] or 0
            hechos = fila["hechos"] or 0
            v["checklist_total"] = total
            v["checklist_hechos"] = hechos
            v["checklist_pct"] = round(100 * hechos / total) if total else 0
    return render_template("deploy.html", versiones=versiones,
                            prod_roots=PROD_ROOTS)


@app.route("/api/deploy/browse")
@login_required
def api_deploy_browse():
    """
    Explorador visual de carpetas remotas en PROD. Devuelve las subcarpetas
    de <root_del_tipo>/<path> para que el usuario elija dónde implementar,
    sin tener que escribir el path completo a mano.
    """
    tipo = (request.args.get("tipo") or "KTR").upper()
    subpath = request.args.get("path", "")
    root = PROD_ROOTS.get(tipo, "/pentaho/project/")
    actual = _normalizar_bajo_root(tipo, subpath)

    cmd = f'find "{actual}" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort'
    out, ok = _run(cmd)
    carpetas = []
    if ok and out.strip():
        carpetas = [posixpath.basename(p.strip()) for p in out.splitlines() if p.strip()]

    relativo = actual[len(posixpath.normpath(root)):].strip("/")
    return jsonify({"ok": True, "root": root, "actual": actual,
                     "relativo": relativo, "carpetas": carpetas})


@app.route("/api/deploy/check_existente")
@login_required
def api_deploy_check_existente():
    """
    Antes de subir: si ya existe el proceso, avisa (en vez de preguntar si se
    quiere sobreescribir) y sugiere un nombre de versión estándar, editable.
    """
    tipo = (request.args.get("tipo") or "").upper()
    nombre_proceso = (request.args.get("nombre_proceso") or "").strip()
    if tipo not in CHECKLIST_ITEMS or not nombre_proceso:
        return jsonify({"ok": True, "existe": False, "sugerido": "v1"})

    with _db() as conn:
        row = conn.execute("""
            SELECT MAX(version) mx, COUNT(*) c FROM deploy_versiones
            WHERE tipo=? AND nombre_proceso=?
        """, (tipo, nombre_proceso)).fetchone()

    ultima = row["mx"] or 0
    existe = (row["c"] or 0) > 0
    sugerido = f"v{ultima + 1}"
    return jsonify({"ok": True, "existe": existe, "ultima_version": ultima,
                     "sugerido": sugerido})


@app.route("/api/deploy/check_destino")
@login_required
def api_deploy_check_destino():
    """
    Verifica si YA existe, en la carpeta de PROD elegida, un archivo con el
    mismo nombre que el que se va a subir. Si existe, ese archivo (no el
    nombre_proceso que se escribió) es el que define la próxima versión,
    porque es a ese archivo al que se va a reemplazar.
    """
    tipo = (request.args.get("tipo") or "").upper()
    destino_dir = request.args.get("destino_dir", "")
    archivo_nombre = (request.args.get("archivo_nombre") or "").strip()
    if not destino_dir or not archivo_nombre:
        return jsonify({"ok": True, "existe_en_prod": False, "sugerido": "v1"})

    destino_dir = _normalizar_bajo_root(tipo or "KTR", destino_dir) if not destino_dir.startswith("/") else destino_dir
    ruta_prod = f"{destino_dir.rstrip('/')}/{archivo_nombre}"

    out, ok = _run(f'test -f "{ruta_prod}" && echo EXISTE || echo NOEXISTE')
    existe_en_prod = ok and "EXISTE" in out and "NOEXISTE" not in out

    with _db() as conn:
        row = conn.execute("""
            SELECT MAX(version) mx, COUNT(*) c FROM deploy_versiones
            WHERE destino_dir=? AND archivo_nombre=?
        """, (destino_dir, archivo_nombre)).fetchone()
    ultima_local = row["mx"] or 0
    tiene_historial_local = (row["c"] or 0) > 0

    if tiene_historial_local:
        sugerido = f"v{ultima_local + 1}"
    elif existe_en_prod:
        # Ya hay un archivo con ese nombre en PROD, pero no versionado por este portal.
        sugerido = "v2"
    else:
        sugerido = "v1"

    return jsonify({"ok": True, "existe_en_prod": existe_en_prod, "ruta_prod": ruta_prod,
                     "ultima_version_local": ultima_local, "sugerido": sugerido})


def _chequear_md_completo(ruta_doc):
    """
    Control básico de calidad del .md subido — no bloquea la subida, pero
    devuelve tips si detecta que probablemente quedó a medio completar.
    """
    tips = []
    try:
        contenido = Path(ruta_doc).read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ["No se pudo leer el .md para revisarlo."]

    texto = contenido.strip()
    if len(texto) < 150:
        tips.append("El .md parece muy corto — revisá que esté completo, no solo el título.")

    # Restos típicos de la plantilla sin completar
    if re.search(r'\[Nombre del proceso\]', contenido, re.IGNORECASE):
        tips.append("El título todavía dice '[Nombre del proceso]' — falta completarlo.")
    placeholders = re.findall(r'\*\([^)]{0,80}\)\*', contenido)
    if placeholders:
        tips.append(f"Quedan {len(placeholders)} sección(es) con el instructivo entre *(paréntesis)* sin completar.")
    if re.search(r'\|\s*\|\s*\|', contenido):
        tips.append("Hay filas de alguna tabla que parecen vacías (sin completar).")

    secciones_clave = ["Necesidad que cubre", "Responsable"]
    for sec in secciones_clave:
        if sec.lower() not in contenido.lower():
            tips.append(f"No se encontró la sección \"{sec}\" — revisá que esté en el .md.")

    return tips


@app.route("/api/deploy/documentacion/<int:vid>")
@login_required
def api_deploy_ver_documentacion(vid):
    """Sirve el .md de documentación de una versión, para verlo o descargarlo."""
    with _db() as conn:
        v = conn.execute("SELECT ruta_documentacion, nombre_proceso, version_tag FROM deploy_versiones WHERE id=?",
                          (vid,)).fetchone()
    if not v or not v["ruta_documentacion"] or not os.path.isfile(v["ruta_documentacion"]):
        abort(404)
    nombre_descarga = f"{v['nombre_proceso']}_{v['version_tag']}.md"
    return send_file(v["ruta_documentacion"], mimetype="text/markdown",
                      as_attachment=False, download_name=nombre_descarga)


@app.route("/api/deploy/nueva_version", methods=["POST"])
@login_required
def api_deploy_nueva_version():
    """
    Sube una nueva versión (KTR, JOB o PY) al portal. Espera multipart/form-data:
      tipo            'KTR' | 'JOB' | 'PY'
      nombre_proceso  nombre lógico del proceso (ej. 'carga_segmentacion_cliente')
      id_hu           ID de la HU en Azure DevOps
      destino_dir     subcarpeta elegida en el explorador visual (relativa a la raíz del tipo)
      version_tag     opcional — si no se edita, se usa el estándar 'v{n}'
      archivo         uno o más archivos (o una carpeta completa, con rutas
                       relativas en el nombre). Si es un único .zip, se usa tal
                       cual; si son varios archivos o una carpeta, se empaquetan
                       automáticamente en un .zip nuevo.
      documentacion   opcional — el .md de documentación, SEPARADO del entregable.
                       Se guarda en una carpeta propia (DOCUMENTACION_DIR), que
                       espeja tipo/nombre_proceso/version, en vez de vivir
                       adentro del mismo .zip que se implementa.
    """
    tipo = (request.form.get("tipo") or "").upper().strip()
    if tipo not in CHECKLIST_ITEMS:
        return jsonify({"ok": False, "error": "tipo debe ser KTR, JOB o PY"}), 400

    nombre_proceso = (request.form.get("nombre_proceso") or "").strip()
    id_hu = (request.form.get("id_hu") or "").strip()
    if not nombre_proceso:
        return jsonify({"ok": False, "error": "Falta nombre_proceso"}), 400

    archivos = [f for f in request.files.getlist("archivo") if f and f.filename]
    if not archivos:
        return jsonify({"ok": False, "error": "No se recibió ningún archivo"}), 400

    version = _siguiente_version(tipo, nombre_proceso)
    version_tag = (request.form.get("version_tag") or "").strip() or f"v{version}"
    destino_dir = _normalizar_bajo_root(tipo, request.form.get("destino_dir", ""))
    folder = _deploy_folder(tipo, nombre_proceso, version)

    if len(archivos) == 1 and archivos[0].filename.lower().endswith(
            (".zip", ".ktr", ".kjb", ".py")):
        # Un solo archivo suelto (o ya viene como .zip armado): se guarda tal cual.
        archivo = archivos[0]
        archivo_nombre = os.path.basename(archivo.filename.replace("\\", "/"))
        ruta_local = folder / archivo_nombre
        archivo.save(str(ruta_local))
    else:
        # Varios archivos o una carpeta completa (rutas relativas en el nombre):
        # se empaquetan en un único .zip nuevo, preservando la estructura.
        safe_proc = re.sub(r'[^\w\-\.]', '_', nombre_proceso)
        archivo_nombre = f"{safe_proc}_{version_tag}.zip"
        ruta_local = folder / archivo_nombre
        with zipfile.ZipFile(ruta_local, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in archivos:
                rel = f.filename.replace("\\", "/").lstrip("/")
                zf.writestr(rel, f.read())

    file_hash = _file_hash(ruta_local)

    # El .md va a una carpeta APARTE, que espeja tipo/nombre_proceso/version,
    # en vez de ir adentro del mismo .zip que se sube a PROD.
    ruta_documentacion = None
    tips_md = []
    doc_file = request.files.get("documentacion")
    if doc_file and doc_file.filename:
        safe_proc = re.sub(r'[^\w\-\.]', '_', nombre_proceso)
        carpeta_doc = DOCUMENTACION_DIR / tipo / safe_proc
        carpeta_doc.mkdir(parents=True, exist_ok=True)
        nombre_doc = f"{version_tag}.md"
        ruta_doc = carpeta_doc / nombre_doc
        doc_file.save(str(ruta_doc))
        ruta_documentacion = str(ruta_doc)
        tips_md = _chequear_md_completo(ruta_doc)

    # Líder de proyecto y analista/desarrollador asignado, tomados de Azure
    # DevOps al momento de crear la versión (no solo mostrados en pantalla:
    # quedan guardados junto con la versión para consultar más adelante).
    lider_proyecto = None
    analista_asignado = None
    if id_hu:
        try:
            resumen_azure = _azure_resumen_item(id_hu)
            if resumen_azure.get("ok"):
                res = resumen_azure["resumen"]
                lider_proyecto = res.get("lider_proyecto") or None
                analista_asignado = res.get("desarrollador_asignado") or None
                # Si es una Tarea sin esos datos propios, usa los de la HU padre.
                if res.get("hu_padre"):
                    lider_proyecto = lider_proyecto or res["hu_padre"].get("lider_proyecto")
                    analista_asignado = analista_asignado or res["hu_padre"].get("desarrollador_asignado")
        except Exception as e:
            app.logger.warning("No se pudo traer líder/analista de Azure DevOps para %s: %s", id_hu, e)

    responsable = session.get("usuario", "desconocido")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with _db() as conn:
        cur = conn.execute("""
            INSERT INTO deploy_versiones
            (tipo, nombre_proceso, id_hu, version, version_tag, archivo_nombre,
             ruta_local, destino_dir, hash_sha256, responsable, fecha, timestamp,
             estado, ruta_documentacion, lider_proyecto, analista_asignado)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'borrador',?,?,?)
        """, (tipo, nombre_proceso, id_hu, version, version_tag, archivo_nombre,
              str(ruta_local), destino_dir, file_hash, responsable, ts[:10], ts,
              ruta_documentacion, lider_proyecto, analista_asignado))
        vid = cur.lastrowid
        # Inicializa el checklist correspondiente. Si ya se adjuntó el .md acá
        # mismo, el ítem "md_creado" se marca solo (no hace falta tildarlo a
        # mano en el checklist después).
        for criterio, _desc in CHECKLIST_ITEMS[tipo]:
            cumplido = 1 if (criterio == "md_creado" and ruta_documentacion) else 0
            conn.execute("""
                INSERT INTO deploy_checklist (version_id, criterio, cumplido, marcado_por, fecha)
                VALUES (?,?,?,?,?)
            """, (vid, criterio, cumplido,
                  responsable if cumplido else None, ts if cumplido else None))
        conn.commit()

    return jsonify({"ok": True, "version_id": vid, "version": version,
                     "version_tag": version_tag, "destino_dir": destino_dir,
                     "ruta_documentacion": ruta_documentacion, "tips_md": tips_md,
                     "lider_proyecto": lider_proyecto, "analista_asignado": analista_asignado})


@app.route("/api/deploy/checklist/<int:vid>", methods=["GET"])
@login_required
def api_deploy_checklist_get(vid):
    with _db() as conn:
        v = conn.execute("SELECT * FROM deploy_versiones WHERE id=?", (vid,)).fetchone()
        if not v:
            return jsonify({"ok": False, "error": "Versión no encontrada"}), 404
        items = [dict(r) for r in conn.execute(
            "SELECT * FROM deploy_checklist WHERE version_id=?", (vid,)).fetchall()]
    descripciones = dict(CHECKLIST_ITEMS[v["tipo"]])
    for it in items:
        it["descripcion"] = descripciones.get(it["criterio"], it["criterio"])
    return jsonify({"ok": True, "version": dict(v), "checklist": items})


@app.route("/api/deploy/checklist/<int:vid>", methods=["POST"])
@login_required
def api_deploy_checklist_post(vid):
    """Guarda las marcas del checklist. Body: {"criterio1": true, "criterio2": false, ...}"""
    data = request.get_json(force=True) or {}
    usuario = session.get("usuario", "desconocido")
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with _db() as conn:
        for criterio, cumplido in data.items():
            conn.execute("""
                UPDATE deploy_checklist SET cumplido=?, marcado_por=?, fecha=?
                WHERE version_id=? AND criterio=?
            """, (int(bool(cumplido)), usuario, ts, vid, criterio))
        conn.commit()
        pendientes = conn.execute("""
            SELECT COUNT(*) c FROM deploy_checklist WHERE version_id=? AND cumplido=0
        """, (vid,)).fetchone()["c"]
        if pendientes == 0:
            conn.execute("UPDATE deploy_versiones SET estado='listo_prod' WHERE id=? AND estado='borrador'", (vid,))
            conn.commit()
    return jsonify({"ok": True, "pendientes": pendientes})


def _checklist_completo(vid):
    with _db() as conn:
        pendientes = conn.execute("""
            SELECT COUNT(*) c FROM deploy_checklist WHERE version_id=? AND cumplido=0
        """, (vid,)).fetchone()["c"]
    return pendientes == 0


@app.route("/api/deploy/implementar/<int:vid>", methods=["POST"])
@login_required
def api_deploy_implementar(vid):
    """
    Sube la versión a PROD por SFTP, a la carpeta elegida visualmente
    (destino_dir), pero SOLO si:
      1. El checklist técnico está 100% cumplido.
      2. La HU en Azure DevOps tiene el OK del Scrum Master y la autorización del PO.
    Si falta algo, rechaza y devuelve el detalle (no se implementa hasta la próxima HU).
    """
    with _db() as conn:
        v = conn.execute("SELECT * FROM deploy_versiones WHERE id=?", (vid,)).fetchone()
        if not v:
            return jsonify({"ok": False, "error": "Versión no encontrada"}), 404
        v = dict(v)

    motivos = []

    if not _checklist_completo(vid):
        motivos.append("Checklist técnico incompleto: quedan criterios sin marcar.")

    gate = {"ok": False}
    if v.get("id_hu"):
        gate = _azure_gate(v["id_hu"])
        if not gate.get("ok"):
            motivos.append(gate.get("motivo", "No se pudo validar la HU en Azure DevOps."))
    else:
        motivos.append("La versión no tiene un ID de HU asociado.")

    if motivos:
        return jsonify({"ok": False, "rechazado": True, "motivos": motivos,
                         "nota": "El incumplimiento de cualquier criterio implica el rechazo "
                                 "de la puesta en producción hasta la próxima HU."}), 409

    destino_dir = v.get("destino_dir") or PROD_ROOTS.get(v["tipo"], "/pentaho/project/")
    remote_path = f"{destino_dir.rstrip('/')}/{v['archivo_nombre']}"

    version_tag = v.get("version_tag") or f"v{v['version']}"
    resp_ok, ruta_respaldo, resp_err = _respaldar_original_si_existe(remote_path, v["tipo"], version_tag)
    if not resp_ok:
        return jsonify({"ok": False, "error": resp_err}), 500

    ok, err = _sftp_put(v["ruta_local"], remote_path)

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    usuario = session.get("usuario", "desconocido")
    with _db() as conn:
        detalle_accion = err
        if ruta_respaldo:
            detalle_accion = f"Original respaldado en: {ruta_respaldo}" + (f" | {err}" if err else "")
        conn.execute("""
            INSERT INTO deploy_historial_acciones (version_id, accion, usuario, fecha, resultado, detalle)
            VALUES (?, 'implementar', ?, ?, ?, ?)
        """, (vid, usuario, ts, "ok" if ok else "error", detalle_accion))
        if ok:
            conn.execute("""
                UPDATE deploy_versiones
                SET estado='en_prod', ruta_prod=?, fecha_implementacion=?, ruta_respaldo_original=?
                WHERE id=?
            """, (remote_path, ts, ruta_respaldo, vid))
        conn.commit()

    if not ok:
        return jsonify({"ok": False, "error": f"Fallo el SFTP hacia PROD: {err}"}), 500

    return jsonify({"ok": True, "ruta_prod": remote_path, "ruta_respaldo_original": ruta_respaldo, "azure_gate": gate})


@app.route("/api/deploy/bajar/<int:vid>", methods=["GET"])
@login_required
def api_deploy_bajar(vid):
    """
    Descarga desde PROD hacia la máquina local del usuario, vía el navegador.
      ?modo=archivo (default) -> baja solo el archivo implementado.
      ?modo=carpeta           -> baja TODA la carpeta destino en PROD, comprimida en .zip.
    """
    modo = (request.args.get("modo") or "archivo").lower()

    with _db() as conn:
        v = conn.execute("SELECT * FROM deploy_versiones WHERE id=?", (vid,)).fetchone()
        if not v:
            return jsonify({"ok": False, "error": "Versión no encontrada"}), 404
        v = dict(v)

    if not v.get("ruta_prod"):
        return jsonify({"ok": False, "error": "Esta versión todavía no fue implementada en PROD."}), 400

    safe_nombre = re.sub(r'[^\w\-\.]', '_', v["nombre_proceso"])
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    usuario = session.get("usuario", "desconocido")

    if modo == "carpeta":
        carpeta_remota = v.get("destino_dir") or posixpath.dirname(v["ruta_prod"])
        nombre_zip = f"{safe_nombre}_v{v['version']}"
        zip_path, error_detalle = _zip_carpeta_remota(carpeta_remota, nombre_zip)

        with _db() as conn:
            conn.execute("""
                INSERT INTO deploy_historial_acciones (version_id, accion, usuario, fecha, resultado, detalle)
                VALUES (?, 'bajar_carpeta', ?, ?, ?, ?)
            """, (vid, usuario, ts, "ok" if zip_path else "error", error_detalle or ""))
            conn.commit()

        if not zip_path:
            return jsonify({"ok": False, "error": f"Fallo al bajar la carpeta desde PROD: {error_detalle}"}), 500

        return send_file(zip_path, as_attachment=True, download_name=f"{nombre_zip}.zip")

    # modo == "archivo": solo el archivo implementado
    destino_local = DESCARGAS_DIR / v["tipo"] / safe_nombre
    destino_local.mkdir(parents=True, exist_ok=True)
    local_file = destino_local / v["archivo_nombre"]

    ok, err = _sftp_get(v["ruta_prod"], local_file)

    with _db() as conn:
        conn.execute("""
            INSERT INTO deploy_historial_acciones (version_id, accion, usuario, fecha, resultado, detalle)
            VALUES (?, 'bajar', ?, ?, ?, ?)
        """, (vid, usuario, ts, "ok" if ok else "error", err))
        conn.commit()

    if not ok:
        return jsonify({"ok": False, "error": f"Fallo el SFTP desde PROD: {err}"}), 500

    return send_file(str(local_file), as_attachment=True, download_name=v["archivo_nombre"])


@app.route("/api/deploy/historial")
@login_required
def api_deploy_historial():
    with _db() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM deploy_versiones ORDER BY id DESC LIMIT 200").fetchall()]
    return jsonify({"ok": True, "versiones": rows})


def _query_historial_acciones(desde=None, hasta=None, q=None, limit=500):
    sql = """
        SELECT ha.id, ha.accion, ha.usuario, ha.fecha, ha.resultado, ha.detalle, ha.nota_manual,
               v.tipo, v.nombre_proceso, v.version_tag, v.id_hu, v.destino_dir, v.ruta_prod,
               v.ruta_documentacion
        FROM deploy_historial_acciones ha
        JOIN deploy_versiones v ON v.id = ha.version_id
        WHERE 1=1
    """
    params = []
    if desde:
        sql += " AND ha.fecha >= ?"
        params.append(f"{desde} 00:00:00")
    if hasta:
        sql += " AND ha.fecha <= ?"
        params.append(f"{hasta} 23:59:59")
    if q:
        sql += """ AND (ha.usuario LIKE ? OR v.nombre_proceso LIKE ? OR v.tipo LIKE ?
                        OR v.id_hu LIKE ? OR ha.detalle LIKE ? OR ha.nota_manual LIKE ?)"""
        like = f"%{q}%"
        params += [like, like, like, like, like, like]
    sql += " ORDER BY ha.id DESC LIMIT ?"
    params.append(limit)
    with _db() as conn:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]


@app.route("/api/deploy/historial_acciones")
@login_required
def api_deploy_historial_acciones():
    """
    Historial completo de implementaciones y descargas (quién, cuándo, qué
    resultado), guardado en el mismo historial_pbix.db que el resto del portal.
    Soporta filtros: ?desde=YYYY-MM-DD&hasta=YYYY-MM-DD&q=texto
    """
    desde = request.args.get("desde", "").strip()
    hasta = request.args.get("hasta", "").strip()
    q = request.args.get("q", "").strip()
    rows = _query_historial_acciones(desde or None, hasta or None, q or None)
    return jsonify({"ok": True, "acciones": rows})


@app.route("/api/deploy/historial_acciones/<int:aid>/nota", methods=["POST"])
@login_required
def api_deploy_historial_nota(aid):
    """Guarda un comentario/detalle manual sobre una acción del historial."""
    data = request.get_json(force=True) or {}
    nota = (data.get("nota") or "").strip()
    with _db() as conn:
        cur = conn.execute("UPDATE deploy_historial_acciones SET nota_manual=? WHERE id=?", (nota, aid))
        conn.commit()
        if cur.rowcount == 0:
            return jsonify({"ok": False, "error": "No se encontró ese registro"}), 404
    return jsonify({"ok": True})


@app.route("/api/deploy/historial_acciones/export_pdf")
@login_required
def api_deploy_historial_export_pdf():
    """Exporta a PDF el historial de implementaciones: documento profesional
    y auditable, con metadata de generación, filtros aplicados, y pie de
    página con numeración y autoría en cada hoja."""
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.units import cm
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.pdfgen import canvas as _canvas_mod
    except ImportError:
        return jsonify({"ok": False, "error": "Falta instalar 'reportlab' en el servidor. "
                         "Corré: pip install -r requirements.txt --break-system-packages "
                         "y reiniciá el servicio."}), 500

    desde = request.args.get("desde", "").strip()
    hasta = request.args.get("hasta", "").strip()
    q = request.args.get("q", "").strip()
    rows = _query_historial_acciones(desde or None, hasta or None, q or None, limit=2000)

    try:
        styles = getSampleStyleSheet()
        celda_style = ParagraphStyle("celda", parent=styles["Normal"], fontSize=7.5, leading=9.5)
        celda_bold = ParagraphStyle("celda_bold", parent=celda_style, fontName="Helvetica-Bold")
        meta_label = ParagraphStyle("meta_label", parent=styles["Normal"], fontSize=8.5,
                                     textColor=colors.HexColor("#475467"))
        meta_valor = ParagraphStyle("meta_valor", parent=styles["Normal"], fontSize=8.5,
                                     fontName="Helvetica-Bold", textColor=colors.HexColor("#1e3a5f"))

        ahora = datetime.now()
        usuario_actual = session.get("nombre") or session.get("usuario") or "desconocido"
        id_reporte = f"RPT-{ahora.strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6].upper()}"

        rango = f"{desde or 'sin límite'} a {hasta or 'sin límite'}" if (desde or hasta) else "todas las fechas"
        filtro_texto = q if q else "sin filtro de texto"

        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=landscape(A4),
                                 leftMargin=1.3*cm, rightMargin=1.3*cm, topMargin=1.3*cm, bottomMargin=1.6*cm,
                                 title="Historial de implementaciones — ETL Governance Portal",
                                 author="Willian Arce — Gobierno de Datos, Banco Continental")

        # ── Encabezado del documento ──────────────────────────────
        elementos = [
            Paragraph("ETL Governance Portal — Banco Continental", styles["Normal"]),
            Paragraph("Historial de Implementaciones", styles["Title"]),
            Spacer(1, 4),
        ]

        meta_tabla = Table([
            [Paragraph("ID de reporte:", meta_label), Paragraph(id_reporte, meta_valor),
             Paragraph("Generado por:", meta_label), Paragraph(str(usuario_actual), meta_valor)],
            [Paragraph("Fecha y hora de generación:", meta_label), Paragraph(ahora.strftime('%Y-%m-%d %H:%M:%S'), meta_valor),
             Paragraph("Total de registros:", meta_label), Paragraph(str(len(rows)), meta_valor)],
            [Paragraph("Rango de fechas filtrado:", meta_label), Paragraph(rango, meta_valor),
             Paragraph("Filtro de texto:", meta_label), Paragraph(filtro_texto, meta_valor)],
        ], colWidths=[4.2*cm, 5*cm, 3.8*cm, 5*cm])
        meta_tabla.setStyle(TableStyle([
            ("BOX", (0, 0), (-1, -1), 0.75, colors.HexColor("#d0d5dd")),
            ("INNERGRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#eaecf0")),
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f9fafb")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ]))
        elementos += [meta_tabla, Spacer(1, 14)]

        encabezado = ["Fecha", "Acción", "Usuario", "Tipo", "Proceso", "Versión", "HU", "Resultado", ".md", "Detalle / Nota"]
        data_tabla = [[Paragraph(h, celda_bold) for h in encabezado]]

        for r in rows:
            detalle_completo = " | ".join(filter(None, [r.get("detalle"), r.get("nota_manual")]))
            fecha_dos_lineas = (r["fecha"] or "").replace(" ", "<br/>")
            tiene_md = bool(r.get("ruta_documentacion"))
            doc_txt = "✔" if tiene_md else "✗ sin .md"
            doc_estilo = celda_style if tiene_md else ParagraphStyle(
                "sin_md", parent=celda_style, textColor=colors.HexColor("#b3492f"))

            data_tabla.append([
                Paragraph(fecha_dos_lineas, celda_style),
                Paragraph(r["accion"] or "", celda_style),
                Paragraph(r["usuario"] or "", celda_style),
                Paragraph(r["tipo"] or "", celda_style),
                Paragraph(r["nombre_proceso"] or "", celda_style),
                Paragraph(r.get("version_tag") or "", celda_style),
                Paragraph(r.get("id_hu") or "", celda_style),
                Paragraph(r["resultado"] or "", celda_style),
                Paragraph(doc_txt, doc_estilo),
                Paragraph((detalle_completo or "")[:300], celda_style),
            ])

        tabla = Table(data_tabla, repeatRows=1,
                       colWidths=[1.9*cm, 1.9*cm, 2.1*cm, 1.4*cm, 3.4*cm, 1.5*cm, 1.5*cm, 2.1*cm, 1.7*cm, 6.1*cm])
        tabla.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e3a5f")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f7fa")]),
        ]))
        elementos.append(tabla)

        if not rows:
            elementos.append(Spacer(1, 10))
            elementos.append(Paragraph("No se encontraron registros para los filtros aplicados.", styles["Normal"]))

        # ── Pie de página en cada hoja: autoría + numeración ──────
        class _CanvasConPie(_canvas_mod.Canvas):
            def __init__(self, *args, **kwargs):
                _canvas_mod.Canvas.__init__(self, *args, **kwargs)
                self._paginas = []

            def showPage(self):
                self._paginas.append(dict(self.__dict__))
                self._startPage()

            def save(self):
                total = len(self._paginas)
                for estado in self._paginas:
                    self.__dict__.update(estado)
                    self._dibujar_pie(total)
                    _canvas_mod.Canvas.showPage(self)
                _canvas_mod.Canvas.save(self)

            def _dibujar_pie(self, total_paginas):
                self.setFont("Helvetica", 7.5)
                self.setFillColor(colors.HexColor("#767676"))
                ancho_pagina = landscape(A4)[0]
                self.drawString(1.3*cm, 0.9*cm, "Desarrollado por Willian Arce — © " + str(ahora.year))
                self.drawCentredString(ancho_pagina/2, 0.9*cm,
                                       f"ETL Governance Portal — Banco Continental — {id_reporte}")
                self.drawRightString(ancho_pagina - 1.3*cm, 0.9*cm,
                                      f"Página {self._pageNumber} de {total_paginas}")

        doc.build(elementos, canvasmaker=_CanvasConPie)
        buf.seek(0)
    except Exception as e:
        app.logger.error("Error generando PDF: %s", e)
        return jsonify({"ok": False, "error": f"Error generando el PDF: {e}"}), 500

    nombre = f"historial_implementaciones_{datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    return send_file(buf, mimetype="application/pdf", as_attachment=True, download_name=nombre)


# ════════════════════════════════════════════════════════
#  AZURE DEVOPS — User Stories Gobierno de Datos
# ════════════════════════════════════════════════════════

def _ora():
    """Conexión Oracle para consultar Azure DevOps HUs."""
    import oracledb
    return oracledb.connect(user="DASHBOARD", password="DASHBOARD", dsn="10.1.1.2:1521/DWHPROD")


def _azure_get(url):
    resp = requests.get(url, auth=("", AZURE_PAT), timeout=15)
    resp.raise_for_status()
    return resp.json()


def _azure_project_encoded():
    """Codifica el nombre del proyecto (puede tener espacios) para usarlo en la URL."""
    from urllib.parse import quote
    return quote(AZURE_PROJECT, safe="")


def _azure_info_basica(id_hu):
    """Trae solo título y estado de una HU — no depende de los campos de aprobación."""
    if not (AZURE_ORG and AZURE_PROJECT and AZURE_PAT):
        return {"ok": False, "error": "Azure DevOps no está configurado (falta ORG/PROJECT/PAT)."}
    try:
        url = (f"https://dev.azure.com/{AZURE_ORG}/{_azure_project_encoded()}/_apis/wit/workitems/"
               f"{id_hu}?fields=System.Title,System.State&api-version=7.1")
        data = _azure_get(url)
        f = data.get("fields", {})
        return {"ok": True, "titulo": f.get("System.Title", ""), "estado": f.get("System.State", "")}
    except Exception as e:
        return {"ok": False, "error": f"No se encontró la HU o falló la consulta: {e}"}


def _azure_display_name(valor):
    """Los campos de identidad de Azure DevOps a veces vienen como dict
    ({'displayName':..., 'uniqueName':...}) y a veces como texto plano,
    según el tipo de campo. Normaliza a un string simple."""
    if isinstance(valor, dict):
        return valor.get("displayName", "") or valor.get("uniqueName", "")
    return valor or ""


def _azure_desarrollador_por_tipo(campos, tipo_work_item):
    """Misma lógica condicional que ya usás en el notebook de reporte:
    el campo de 'desarrollador/analista asignado' cambia según el tipo de work item."""
    if tipo_work_item == "User Story Desarrollo":
        return _azure_display_name(campos.get(AZURE_FIELD_DESARROLLADOR_HU))
    elif tipo_work_item == "Bug":
        return _azure_display_name(campos.get(AZURE_FIELD_DESARROLLADOR_BUG))
    elif tipo_work_item == "User Story Datos":
        return _azure_display_name(campos.get(AZURE_FIELD_ANALISTA_DATOS))
    else:
        return _azure_display_name(campos.get(AZURE_FIELD_DESARROLLADOR_OTRO))


def _azure_obtener_workitem(id_hu, con_relaciones=False):
    """Trae un work item completo (todos sus campos). Si con_relaciones=True,
    incluye también sus relaciones (necesario para poder encontrar el padre)."""
    expand = "&$expand=relations" if con_relaciones else ""
    url = (f"https://dev.azure.com/{AZURE_ORG}/{_azure_project_encoded()}/_apis/wit/workitems/"
           f"{id_hu}?api-version=7.1{expand}")
    return _azure_get(url)


def _azure_resumen_item(id_hu, con_padre=True):
    """
    Devuelve un resumen de una HU/Tarea/Bug: tipo de work item, título, estado,
    líder de proyecto y desarrollador asignado (con la lógica condicional según
    el tipo). Si es una Tarea y con_padre=True, además resuelve y agrega el
    resumen de la HU padre (porque una Tarea no siempre tiene cargados los
    mismos campos que sí tiene la HU madre).
    """
    if not (AZURE_ORG and AZURE_PROJECT and AZURE_PAT):
        return {"ok": False, "error": "Azure DevOps no está configurado (falta ORG/PROJECT/PAT)."}
    try:
        data = _azure_obtener_workitem(id_hu, con_relaciones=con_padre)
    except Exception as e:
        return {"ok": False, "error": f"No se encontró el ítem {id_hu} o falló la consulta: {e}"}

    f = data.get("fields", {})
    tipo = f.get("System.WorkItemType", "")
    resumen = {
        "id": str(id_hu),
        "titulo": f.get("System.Title", ""),
        "estado": f.get("System.State", ""),
        "tipo": tipo,
        "lider_proyecto": _azure_display_name(f.get(AZURE_FIELD_LIDER_PROYECTO)),
        "desarrollador_asignado": _azure_desarrollador_por_tipo(f, tipo),
        "hu_padre": None,
    }

    es_tarea = tipo.strip().lower() in ("task", "tarea")
    if con_padre and es_tarea:
        parent_id = None
        for rel in data.get("relations", []) or []:
            if rel.get("rel") == "System.LinkTypes.Hierarchy-Reverse":
                parent_id = rel["url"].rstrip("/").split("/")[-1]
                break
        if parent_id:
            padre = _azure_resumen_item(parent_id, con_padre=False)
            if padre.get("ok"):
                resumen["hu_padre"] = padre["resumen"]

    return {"ok": True, "resumen": resumen}


@app.route("/api/azure/resumen/<id_hu>")
@login_required
def api_azure_resumen(id_hu):
    """
    Resumen completo de una HU/Tarea/Bug para mostrar en el formulario de
    Deploy: tipo de work item, líder de proyecto, desarrollador asignado, y
    si es una Tarea, también el resumen de la HU padre.
    """
    return jsonify(_azure_resumen_item(id_hu))


def _azure_gate(id_hu):
    """
    Valida en vivo contra la API de Azure DevOps que la HU (o, si el ítem es
    una Tarea, su HU padre — porque los campos de aprobación viven ahí, no en
    la Tarea) tenga:
      - Comentario de Aprobación del Scrum Master (no vacío)
      - Autorización del Product Owner (no vacía)
    Devuelve {"ok": bool, "motivo": str, "detalle": {...}} sin bloquear si
    AZURE_PAT / AZURE_ORG no están configurados: en ese caso avisa en vez de fallar en falso.
    """
    if not (AZURE_ORG and AZURE_PROJECT and AZURE_PAT):
        return {"ok": False, "motivo": "Azure DevOps no está configurado (falta ORG/PROJECT/PAT)."}

    if not (AZURE_FIELD_SCRUM and AZURE_FIELD_PO):
        basica = _azure_info_basica(id_hu)
        motivo = ("Faltan configurar los reference names de los campos de aprobación "
                   "(correr /api/azure/discover_fields).")
        if basica.get("ok"):
            return {"ok": False, "motivo": motivo,
                    "detalle": {"titulo": basica["titulo"], "estado": basica["estado"]}}
        return {"ok": False, "motivo": basica.get("error", motivo)}

    try:
        data = _azure_obtener_workitem(id_hu, con_relaciones=True)
    except Exception as e:
        return {"ok": False, "motivo": f"Error consultando Azure DevOps: {e}"}

    f = data.get("fields", {})
    tipo = f.get("System.WorkItemType", "")
    titulo = f.get("System.Title", "")
    estado = f.get("System.State", "")
    es_tarea = tipo.strip().lower() in ("task", "tarea")

    # Por default, se valida sobre el mismo ítem consultado.
    campos_aprobacion = f
    validado_via_padre = None

    if es_tarea:
        parent_id = None
        for rel in data.get("relations", []) or []:
            if rel.get("rel") == "System.LinkTypes.Hierarchy-Reverse":
                parent_id = rel["url"].rstrip("/").split("/")[-1]
                break
        if not parent_id:
            return {"ok": False, "motivo": "Es una Tarea sin HU padre vinculada — no se puede validar la aprobación.",
                     "detalle": {"titulo": titulo, "estado": estado, "tipo": tipo}}
        try:
            data_padre = _azure_obtener_workitem(parent_id)
        except Exception as e:
            return {"ok": False, "motivo": f"No se pudo consultar la HU padre ({parent_id}): {e}",
                     "detalle": {"titulo": titulo, "estado": estado, "tipo": tipo}}
        campos_aprobacion = data_padre.get("fields", {})
        validado_via_padre = parent_id

    scrum_ok = bool((campos_aprobacion.get(AZURE_FIELD_SCRUM) or "").strip())
    po_ok    = bool((campos_aprobacion.get(AZURE_FIELD_PO) or "").strip())
    detalle  = {
        "titulo": titulo, "estado": estado, "tipo": tipo,
        "comentario_scrum": campos_aprobacion.get(AZURE_FIELD_SCRUM),
        "autorizacion_po": campos_aprobacion.get(AZURE_FIELD_PO),
        "validado_via_hu_padre": validado_via_padre,
    }

    faltantes = []
    if not scrum_ok:
        faltantes.append("el Comentario de Aprobación del Scrum Master")
    if not po_ok:
        faltantes.append("la Autorización del Product Owner")

    sujeto = f"en la HU padre ({validado_via_padre})" if validado_via_padre else "en la HU"
    if faltantes:
        motivo = "Falta " + " y falta ".join(faltantes) + f" {sujeto}."
        return {"ok": False, "motivo": motivo, "detalle": detalle}

    ok_msg = None
    if validado_via_padre:
        ok_msg = f"Aprobado vía HU padre {validado_via_padre}."
    return {"ok": True, "detalle": detalle, "motivo": ok_msg}


@app.route("/api/azure/info/<id_hu>")
@login_required
def api_azure_info(id_hu):
    """Título y estado de una HU — para mostrar en vivo mientras se escribe el ID."""
    return jsonify(_azure_info_basica(id_hu))


@app.route("/api/azure/detalle/<id_hu>")
@login_required
def api_azure_detalle(id_hu):
    """Trae título, estado y el estado de las dos aprobaciones para una HU puntual."""
    gate = _azure_gate(id_hu)
    return jsonify(gate)


@app.route("/api/azure/discover_fields")
@login_required
def api_azure_discover_fields():
    """
    Ayuda de una sola vez: lista los campos de Azure DevOps cuyo nombre visible
    contenga 'Aprobaci' o 'Autorizaci', para identificar el referenceName real
    y cargarlo en AZURE_FIELD_SCRUM / AZURE_FIELD_PO (variables de entorno).
    """
    if not (AZURE_ORG and AZURE_PAT):
        return jsonify({"ok": False, "error": "Falta configurar AZURE_DEVOPS_ORG / AZURE_DEVOPS_PAT"}), 400
    try:
        url = f"https://dev.azure.com/{AZURE_ORG}/_apis/wit/fields?api-version=7.1"
        data = _azure_get(url)
        matches = [f for f in data.get("value", [])
                   if "aprobaci" in f.get("name", "").lower()
                   or "autorizaci" in f.get("name", "").lower()]
        return jsonify({"ok": True, "matches": matches})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/azure")
@login_required
def azure_hus():
    return render_template("azure_hus.html")

@app.route("/api/azure/hus")
@login_required
def api_azure_hus():
    """Retorna las HUs de Gobierno de Datos desde DASHBOARD.AZURE_CABECERA."""
    try:
        conn = _ora()
        cur = conn.cursor()
        cur.execute("""
            SELECT
                ac.ID_HU,
                ac.TITULO,
                ac.DESCRIPCION,
                ac.ESTADO,
                ac.RAZON,
                ac.AREA,
                ac.TEAM_PROJECT,
                ac.SPRING,
                ac.TIPO,
                ac.ASIGNADO_A,
                ac.CREADO_POR,
                ac.CAMBIADO_POR,
                ac.FECHA_CREACION,
                ac.FECHA_CAMBIO,
                ac.FECHA_CIERRE,
                ac.FECHA_CAMBIO_ESTADO,
                ac.FECHA_NEW,
                ac.FECHA_ACTIVE,
                ac.FECHA_CLOSED,
                ac.FECHA_POSTPRODUCCION,
                ac.FECHAESTIMATIVA,
                ac.TAGS,
                ac.ACTIVITY,
                ac.DESARROLLADORASIGNADO,
                ac.LIDERTECNICO,
                ac.LIDER_PROYECTO,
                ac.ESTADO_PRUEBA_ACEPTACION,
                ac.GRADO_DE_CONFORMIDAD,
                ac.NRO_SERVICE_DESK,
                ac.COMENTARIO
            FROM DASHBOARD.AZURE_CABECERA ac
            WHERE UPPER(ac.AREA) LIKE '%GOBIERNO%DATO%'
               OR UPPER(ac.AREA) LIKE '%LABORATORIO%DATO%'
               OR UPPER(ac.AREA) LIKE '%GOBERNANZA%'
            ORDER BY ac.ID_HU DESC
        """)
        cols = [d[0] for d in cur.description]
        rows = []
        date_cols = ('FECHA_CREACION','FECHA_CAMBIO','FECHA_CIERRE',
                     'FECHA_CAMBIO_ESTADO','FECHA_NEW','FECHA_ACTIVE',
                     'FECHA_CLOSED','FECHA_POSTPRODUCCION','FECHAESTIMATIVA',
                     'FECHA_INSERT')
        for r in cur.fetchall():
            row = dict(zip(cols, r))
            # Convertir LOBs (CLOB/BLOB) a string
            for k, v in row.items():
                if hasattr(v, 'read'):
                    row[k] = v.read()
            for k in date_cols:
                if row.get(k):
                    row[k] = row[k].isoformat() if hasattr(row[k], 'isoformat') else str(row[k])
            rows.append(row)
        cur.close()
        conn.close()
        return jsonify({"ok": True, "data": rows, "count": len(rows)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e), "data": []})


if __name__ == "__main__":
    print("\n  ETL Governance Portal — Banco Continental")
    print("  http://localhost:5000\n")
    app.run(host="0.0.0.0", port=5000, debug=False)
